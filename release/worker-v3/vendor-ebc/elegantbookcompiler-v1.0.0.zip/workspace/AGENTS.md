# ElegantBookCompiler Agent Rules

状态：`Approved Baseline v0.3`

确认日期：`2026-07-18`

本文件是 `/Users/concm/prod_workspace/ElegantbookCompiler` 的最高本地工作契约。
它用于约束后续代理、代码、技能、提示词、测试和验收，不是某一本教材的临时操作说明。

如果本文件与旧技能、旧脚本、旧报告或历史聊天结论冲突，以本文件及其下列规范基线为准。

## 0. 合同体系、优先级与共同硬原则

### 0.1 规范文件与强制阅读顺序

任何在本工作区执行分析、设计、实现、验收或技能重构的代理，必须依次完整阅读：

1. 本 [AGENTS.md](AGENTS.md)；
2. [01 输入与事实来源规范](specs/01-input-and-provenance-spec.md)；
3. [02 正文范围与阅读顺序规范](specs/02-body-scope-and-reading-order-spec.md)；
4. [03 内容完整性及唯一证据账本规范](specs/03-content-evidence-ledger-spec.md)；
5. [04 教学语义与 ElegantBook 映射规范](specs/04-semantic-elegantbook-mapping-spec.md)；
6. [05 模板冻结与编译规范](specs/05-template-freeze-and-compile-spec.md)；
7. [06 最终逐页验收及产品通过规范](specs/06-final-page-review-and-acceptance-spec.md)。

本文件规定根本目标、工作边界和治理原则；六份规范把这些原则展开为可执行的输入、产物、硬门禁、
人工决策和阶段交接合同。六份规范不是参考建议，而是当前产品标准的规范性组成部分。

### 0.2 冲突优先级与变更控制

冲突按以下优先级处理：

1. 用户基于完整事实作出的最新明确决定；
2. 本 `AGENTS.md`；
3. 六份规范中与当前阶段对应的具体合同；
4. 经批准的 schema、profile、单书配置和验收矩阵；
5. 技能说明、代码、提示词、测试和运行报告；
6. 旧文档、旧产物和历史聊天结论。

低优先级材料不得放宽高优先级硬门禁。规范之间疑似冲突时必须停止受影响的通过判定，记录冲突并回到
本文件和来源证据裁决；不得自行选择更容易通过的一条。

任何硬门禁、事实来源优先级、模板冻结边界、最终接受条件或六份规范职责边界的实质变化，都必须经用户明确确认。
实现细节和非实质性澄清可以按事实更新，但必须保留版本和变更记录。

### 0.3 统一规范状态

六份规范的 `spec_status` 只允许使用：

- `blocked`：必要输入、权限、前置状态或可验证证据不足，尚不能执行或判定；
- `failed`：证据足以判定至少一个硬门禁违反；
- `needs_review`：存在必须由人工裁决且尚未关闭的事项；
- `passed`：全部硬门禁通过，全部人工决策项关闭，且产物与证据绑定一致。

不存在 `passed_with_unresolved_review` 或“带条件通过”。`diagnostic_only` 是运行能力或模式，
`ready_for_user_acceptance`、`human_accepted` 等是产品接受状态，都不得冒充 `spec_status=passed`。

规范 03 是贯穿全链路的账本规范，其 `spec_status` 必须同时声明 `ledger_checkpoint`；
较早检查点的 `passed` 只允许交接到指定下游，不得冒充较晚检查点已经成立。

### 0.4 六份规范共同硬原则

以下三条同时约束六份规范，任何下位实现不得放宽：

1. **原 PDF 最终核验门禁**：原 PDF 不可访问时可以执行不依赖最终视觉真值的受限诊断，
   但相应正式链路必须保持 `blocked`，不得取得 `source_fidelity_pass` 或最终产品通过；
2. **人工决策闭环门禁**：任何未解决的人工判断、语义争议或 review queue 项都阻止相应规范进入 `passed`；
3. **全页、人工与用户三层验收**：最终 PDF 每一页都必须完成自动渲染和检查；高风险页、异常页和语义争议
   必须由人工闭环；黄金样本还必须由用户明确接受，才可以成为正式黄金基线。

规范 01–05 的局部 `passed` 只代表该阶段合同成立，不代表全产品通过，也不能替代规范 06 的最终验收。

## 1. 根本目标

当前工作区的首要交付物不是“修好一本书”，也不是“改好五个技能”，而是：

> 以代表性教育材料为黄金样本，建立一套经得起逐项核验的产品标准；
> 用合格样书证明标准能够落地；再把经过验证的方法推广为可复用、可回归、可持续演进的能力。

当前《新教材全解 五上 数学》是第一个黄金样本，而不是唯一适配对象。
`2025教材模版新版.zip` 是本工作区所有样本唯一允许使用的目标模板，不是“第一个候选模板”，
也不存在按材料类型改用其他模板的选择。跨样本兼容性只验证不同教育材料能否在这同一冻结模板合同下正确表达，
不以跨模板兼容为本工作区目标。

长期能力应覆盖多种教育类材料，包括但不限于：

- 教材、课本、教辅和教师用书；
- 讲义、课程包和复习资料；
- 试卷、测评、练习册和工作簿；
- 数学、语言、科学、人文等不同学科；
- 中文、英文、双语及后续明确纳入测试的其他语言。

“具备兼容性”不等于在未经测试时宣称全部支持。尚未验证的材料类型、语言或复杂结构必须明确标记为
`unsupported`、`needs_review` 或实验性能力，不能假装通过。

## 2. 两条最高工作规定

### 2.1 独立判断，不迎合方案

用户在讨论中提出的想法、建议和方案可能正确，也可能不正确。代理不得因为它们来自用户就直接接受，
也不得用空泛的赞同代替分析。

讨论计划、架构、规则或验收方案时，代理必须：

1. 区分事实、假设、偏好、建议、约束和已确认决定；
2. 回到本项目根本目标判断方案是否真正有利于产品质量和可复用能力；
3. 查验当前文件、代码、产物、日志、渲染结果和其他一手证据；
4. 结合可靠的工程原则与行业最佳实践分析收益、风险和隐含成本；
5. 指出与已知事实冲突、可能过拟合或会造成责任错位的部分；
6. 给出替代方案、取舍和明确建议，而不是只复述用户意见；
7. 对无法证明的判断标注不确定性，并说明需要什么证据才能确认。

用户在充分讨论后作出的明确决定，应当作为项目约束执行；但如果新证据表明该决定会破坏根本目标，
代理仍有责任及时指出，而不是静默照做后再报告失败。

### 2.2 鲁棒、兼容、拒绝硬编码和过拟合

所有技能、代码和提示词必须以跨样本、跨材料类型、跨学科和跨语言复用为设计目标。

禁止通过以下信息触发产品逻辑：

- 书名、文件名、目录名或固定路径；
- `material_id`、任务 ID、样本 ID 或已知哈希；
- 某一本书的固定页码、图片名或题号；
- 为使单个样本通过而添加的无解释字符串替换；
- 只对当前渲染结果有效、无法说明语义依据的坐标或尺寸魔数；
- 在通用内核里堆叠某一种语言或出版社的栏目名称。

允许且鼓励使用分层、显式、可审计的配置：

1. **通用内核**：处理来源追溯、块顺序、语法、结构不变量、模板约束和验收协议；
2. **材料类型/学科/语言 profile**：描述教材、试卷、练习册等类型的结构惯例和语义标签；
3. **单书配置**：只记录经来源证据确认的别名、正文边界和特殊约定，不得写入教材正文或猜测内容。

拒绝硬编码不等于拒绝配置。把所有差异塞进一套“万能正则”同样是不可维护的隐性过拟合。

任何拟推广的规则都必须记录：

- 它解决的通用问题是什么；
- 哪些证据支持该规则；
- 应归属于通用内核、profile 还是单书配置；
- 哪些材料类型可能受到副作用；
- 哪些既有黄金样本完成了回归；
- 规则不适用时如何安全降级。

## 3. 事实来源与证据优先级

所有判断必须证据优先。对于以 PDF 为原始来源的正式流程，事实来源按以下优先级解释：

1. 原始 PDF 的可见内容、页面和布局证据；
2. PDF 对应的 MinerU/OCR、bbox、内容块、公式、表格和图片证据；
3. MinerU-Popo 的后处理块、结构、顺序、关系和 manifest 证据；
4. 经核验的正文主文件和来源账本；
5. 经核验的语义标注；
6. 生成的 LaTeX 和编译 PDF；
7. 技能说明、脚本报告、历史文档和聊天记忆。

MinerU 与 MinerU-Popo 承担不同证据角色：前者更接近基础提取，后者是正式流程入口和后处理结果；
两者发生冲突时必须回到原 PDF 核验，不能按节点先后自动认定 Popo 一定正确。

这里必须区分“处理起点”和“事实来源”：正式转换从 MinerU+Popo 已完成的输出物开始，
但原始 PDF 仍然是内容、页面、阅读关系和视觉语义的最高核验来源。

下游产物不得反向覆盖上游事实。样本中已有的 LaTeX ZIP 是可选的待修复基线，不是正式流程的必需输入，
也不是内容真值；
编译成功也不能证明文字、结构、公式、表格、图片或阅读顺序正确。

对于未来非 PDF 来源，应由任务契约明确指定权威源文件；同样遵守“原始来源高于派生产物”的原则。

任何自动修复都必须能够指向来源证据。证据不足时，优先保留原内容并进入 review queue，
不得用常识、语言模型流畅度或“看起来合理”代替来源。

## 4. 正式流程入口、输入模型与工作区边界

### 4.1 正式流程入口

本项目正式生产流程的起点是：一个样本已经完成 MinerU 和 MinerU-Popo 处理，并形成可追溯、可物化的
MinerU+Popo 输出任务包。

本项目默认不负责 PDF 上传、GPU MinerU 推理或 MinerU-Popo 上游生产；这些属于更早的节点。
如果上游输出缺失或不符合合同，应当阻断并退回上游，而不是在本项目中伪造缺失证据。

每个正式样本任务应包含或可解析到以下逻辑输入：

- **原始来源引用**：原 PDF、来源 ID、哈希、页数及对象位置，用于内容忠实和最终核验；
- **MinerU 证据**：内容块、页码、bbox、公式、表格、图片及相关结构化产物；
- **MinerU-Popo 证据**：正式转换入口的后处理块、结构、顺序、关系、manifest 和上游血缘；
- **固定目标模板输入与变更约束**：每次输出都必须绑定工作区根目录的 `2025教材模版新版.zip`，
  当前批准哈希为 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`；
  其他模板不是候选输入。模板 intake 同时记录用户声明的禁止项和候选允许项；
  规范 05 负责从该输入生成唯一权威的机器可校验 `template_contract.json`；
- **可选基线**：已有 Markdown、语义资产、LaTeX ZIP 或编译 PDF，仅用于修复、比较或回归，不能覆盖来源事实。

Popo 输出是正式处理起点；原 PDF 是通过完整来源忠实验收所必需的核验证据。
如果只能取得 Popo 输出而无法访问原 PDF，可以进行受限诊断或中间产物构建，但不得取得
`source_fidelity_pass` 或最终产品通过状态。

这些输入可以来自：

- 当前工作区中的本地样本组；
- 用户后续提供的其他本地样本组；
- MinIO 中分别存放原 PDF、MinerU 和 MinerU-Popo 产物的逻辑节点或 bucket；
- 经用户确认的其他只读来源。

bucket 名称、对象前缀、任务 ID 和运行 ID 必须通过配置和 manifest/血缘解析获得，不能写死在通用产品逻辑中。
正式运行应先把所选任务物化到隔离的本地运行目录；上游 PDF、MinerU、Popo 对象始终作为只读证据。

### 4.2 第一组黄金样本

当前本地文件只是第一组样本，而不是项目全部输入合同：

- `新教材全解 五上 数学.pdf`：第一组样本的原始来源；
- `新教材全解 五上 数学.zip`：第一组样本已有但可能遗漏、错序或错误的可选 LaTeX 基线；
- `2025教材模版新版.zip`：本工作区全部样本必须遵守的唯一目标模板实物及冻结依据。

后续样本不要求拥有与第一组相同的文件组合，也不得因为第一组存在现成 LaTeX ZIP，
就把“已有 LaTeX”误设为正式生产流程的前置条件。

### 4.3 当前执行边界

当前阶段默认只做本地分析、规范制定、样本构建和验证。后续读取、物化和处理 MinIO 样本属于本项目预期范围，
但应在产品标准、任务选择、运行目录和只读边界明确后执行。

未经用户明确批准，不得：

- 修改全局 `/Users/concm/.codex/skills/` 下的五个共享技能；
- 写入或发布到 MinIO、LuceonWeb 或其他生产系统；
- 覆盖原始 PDF、原始 ZIP、历史验收产物或基线；
- 批量调用付费模型；
- 扩大到新的样本批次；
- 删除尚未完成来源闭环的图片或中间证据。

六份产品规范落地后，仍须先建立当前黄金样本验收矩阵和来源账本，再依据缺陷证据评估五个技能；
不得仅凭规范文字或当前样本的表面现象提前反向修改五个技能。

## 5. 产品标准的核心原则

### 5.1 来源忠实

- 不得编造原始来源不存在的正文、标题、例题、答案、说明、图注或公式。
- 不得为了语言流畅、排版美观或编译通过而改变教材含义。
- 不得静默删除难以识别的内容。
- 不得把未经来源确认的 OCR 猜测包装成确定内容。
- 确有歧义时保留证据、置信度和人工复核状态。

### 5.2 正文范围

当前产品只重建来源正文：

- 排除原书封面、版权页、原目录、广告、空白页和后封底；
- 保留正文内真实存在的目标、概念、例题、练习、知识导图、复习、测评和源可见答案；
- 模板生成的新封面和新目录属于输出框架，不视为重新收入原书前置材料；
- 对答案、附录、词汇表等边界内容，必须依据具体产品契约和来源位置作显式决定，不能只靠标题关键词截断。

### 5.3 流水阅读顺序

LaTeX 不要求复制 PDF 的二维几何布局，但必须还原可连续阅读的语义顺序。

- 多栏、边栏、跨页表格和图文混排必须根据 bbox、栏结构、语义依赖和来源视觉共同确定顺序；
- 题干、选项、配图、解答和注释不得被错误拆散或重排；
- 表格、公式和图片必须放在其语义锚点附近；
- 脚注、图注和局部说明不得无依据地统一移动到全书末尾；
- 不能仅信任 OCR 或 flat content list 的数组顺序而不做验证。

### 5.4 结构与语义

- 章节层级必须来自目录、正文标题、编号、版式和内容关系的综合证据；
- 视觉字号不等于语义级别；
- “学习目标”“知识点”“方法提示”等局部教学栏目不能污染书级目录；
- 同一栏目名称在不同上下文中可能承担不同角色，不能只凭字符串决定样式；
- 语义标注必须真正被渲染器消费，不能成为旁路报告。

### 5.5 ElegantBook 使用原则

充分使用 ElegantBook 不等于使用所有盒子。

- 先判断内容语义，再选择模板现有的章节、环境、命令或 tcolorbox style；
- 只使用与内容真实角色相符的构件；
- 与当前材料无关的盒子可以不使用；
- 不得为了“丰富样式”把普通正文、长表格、复杂公式或整组练习强行装盒；
- 原生 `definition`、`theorem`、`example`、`exercise`、`problem`、`note`、`solution` 等环境只有在语义真正匹配时才可使用；
- 源可见答案不得错误放入默认隐藏的环境；
- 映射规则应数据化、可解释、可回归，而不是散落在多个脚本中的字符串判断。

### 5.6 编译与视觉质量

- 编译无致命错误是必要条件，不是充分条件；
- 不得以 fallback、占位图、demo image 或隐藏内容制造虚假编译通过；
- 必须检查未定义命令、缺失文件、未解析引用、字体回退和严重版面 warning；
- 最终验收必须查看渲染页面，而不是只看退出码、文件存在或 PDF 页数；
- 真正交付前必须逐页检查，不得只检查封面、前三页、中间页和末页。

## 6. 模板冻结契约

工作区根目录的 `2025教材模版新版.zip` 必须作为所有正式样本的唯一目标模板输入，
而不是由转换器重新生成、按样本替换或从其他模板推断。当前批准模板 ZIP SHA-256 为
`ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`；哈希不符必须阻断，
不得自动切换到另一模板。

冻结范围至少包括：

- `elegantbook.cls` 的字节内容；
- `main.tex` 导言区；
- 已有宏包集合和设置；
- 已有颜色、tcolorbox styles、自定义环境和自定义命令；
- 模板规定的正文插入边界。

只允许修改经过白名单确认的配置值，例如：

- `\title`、`\subtitle`；
- `\author`、`\institute`、`\date`；
- `\extrainfo`；
- `\logo`、`\cover`；
- 经用户明确允许的封面配置项；
- 正文插入区域。

不得：

- 新增或删除自定义环境、命令和 style；
- 在生成正文中定义或调用模板局部自定义命令、模板局部自定义环境；模板原有定义只作为冻结字节保留；
- 把模板已有 tcolorbox style key 伪装成自定义环境。确有语义依据需要盒子时，只允许通过标准
  `tcolorbox` 环境调用冻结模板已有 style key；
- 修改 `documentclass` 选项；
- 注入额外排版宏包或“安全修复”命令；
- 使用任何不同于 `2025教材模版新版.zip` 的模板或 class；
- 用另一份 `elegantbook.cls` 覆盖模板版本；
- 为压缩页数而重定义 `\clearpage`、`\cleardoublepage` 或破坏章节语义。

编译所需但模板遗漏的旁路依赖，只允许是冻结模板已经引用且经严格类型白名单批准的静态数据或资源文件；
不得补入 `.tex`、`.sty`、`.cls`、`.cfg`、`.def`、脚本或其他可定义/改变 TeX 行为的文件。
每个旁路依赖必须记录来源、用途和哈希，并对最终工程的传递加载图及 TeX API 库存作机械复核。
每次构建都必须输出模板完整性报告，验证冻结区和 class 哈希未变。

## 7. 唯一证据账本与数据流

全链路应围绕一个版本化、可追溯的 canonical block ledger 工作，而不是在每个阶段重新猜测结构。

最小块记录应包括：

- `block_id`；
- 来源文件、页码和 bbox；
- 页内、跨栏和跨页阅读顺序；
- 原始文字、公式、表格或图片引用；
- 上游 MinerU/Popo/OCR 引用及置信度；
- 正文范围状态；
- 语义角色与层级；
- 输出位置和内容哈希；
- 排除、修复或人工复核理由。

每个来源原子内容必须先由正文范围账本明确纳入、排除或复核。规范 02 已确认纳入的正文块，
在最终正文中必须恰好形成一次逻辑输出；任何后续阶段都不得另立排除理由绕过该范围决定。

禁止出现无记录丢失、重复输出、跨章节错挂或无法追溯的内容。

`clean.md`、语义 JSON、CleanLaTeX、ElegantBook LaTeX 和最终 PDF 都应是同一账本的不同视图或派生产物，
不得彼此独立重建语义。

canonical ledger 采用不可变快照：任何追加、修正或状态更新都必须创建带 `parent_ledger_hash` 的新版本，
不得原地修改已经计算哈希或交给下游的文件。所有阶段输入、人工决定、构建和验收必须绑定精确的
`ledger_snapshot_id`、版本和哈希。

全链路人工决定由版本化的 `canonical_decision_index.json` 统一索引。各阶段可以保存自己的追加式决定事件文件，
但每个事件必须有唯一 `decision_id`、状态、证据、作用对象、适用产物哈希和失效关系，并登记到不可变索引快照。
任何开放、过期或失效但未重审的决定都阻止相应规范通过；黄金样本接受必须绑定最终决定索引哈希。

账本、决定索引和提交清单的哈希关系必须是有向无环图，统一提交顺序为：

1. 决定事件只引用其裁决时已经存在的不可变证据、父账本或构建产物；
2. 冻结决定索引快照 `D`，`D` 不得引用随后才生成的子账本；
3. 生成绑定 `D` 的新账本/阶段产物快照 `L`；
4. 如需同时承诺 `D` 与 `L`，由独立 stage/acceptance commit manifest `M` 绑定二者。

严禁 `D` 与其后代 `L` 相互引用，也不得要求较早的上游证据反向记录未来 ledger、build 或最终产物哈希。

## 8. 鲁棒性与兼容性设计

### 8.1 适配器、内核、profile、渲染器分离

- 输入适配器负责不同 PDF/OCR/MinerU/Popo/LaTeX 形态；
- 通用内核负责证据、顺序、完整性和状态；
- profile 负责材料类型、学科和语言惯例；
- 语义映射层负责把已确认语义确定性绑定为冻结 `render_plan`；
- 规范 05 的渲染执行器只负责按冻结计划进行合法转义、序列化和正文插入，不得重新选择语义、构件或布局；
- 验收器负责独立验证，不负责静默修复内容。

### 8.2 安全降级

- 不确定时不得强行分类；
- 复杂表格无法可靠恢复时保留图像或来源证据并进入复核；
- 公式语义不确定时不得补造运算符、分母或答案；
- 阅读顺序存在冲突时必须生成候选和可视证据；
- profile 不匹配时退回通用结构和 review queue，而不是套用最近似的教材规则。

### 8.3 可维护性

- 数据 schema 必须版本化；
- 转换应尽量确定、幂等，并可从中断点续跑；
- 相同输入、配置和版本应产生可复现结果；
- 应缓存不变的解析、图片信息和页面渲染，避免重复全量 I/O 和模型调用；
- 同一安全修复不得在不同阶段反复执行；
- 巨型正则修补器应拆分为可测试、归属清晰的规则模块；
- 规则顺序和冲突解决必须显式，不得依靠偶然调用顺序。

### 8.4 多语言

- 通用内核必须使用 Unicode 安全处理，不假定内容仅为 ASCII、英文或中文；
- 语言识别与栏目别名属于 profile，不属于通用内核；
- 不得用空格、大小写或拉丁标点假设破坏 CJK、双语或其他文字；
- 尚未测试的 RTL、复杂文字塑形或特殊音标应明确标记能力状态，不得虚假兼容。

## 9. 技能、代码和提示词的质量要求

### 9.1 技能不是只有脚本

一个可复用技能至少包含三个一致的层面：

1. `SKILL.md` 中的边界、证据规则和工作契约；
2. `scripts/` 中可重复执行、可测试的确定性能力；
3. 模型/Codex 对歧义判断、工具编排和人工复核的职责。

只把脚本串起来不等于具备完整能力；只写长篇技能说明而没有可执行门禁也不等于完成。

### 9.2 代码

- 输入、输出和失败状态必须有明确 schema；
- 关键转换必须保存 before/after 和来源证据；
- 不得吞掉异常后继续报告成功；
- `warning`、`needs_review` 和未闭环内容必须能阻断相应验收级别；
- 必须同时支持当前约定的单体和拆分式 LaTeX 工程，或明确声明不支持；
- 共享技能修改必须有单元测试、黄金样本测试和跨类型回归证据；
- 运行环境、依赖版本和编译器必须固定或显式探测，不能依赖碰巧存在的解释器。

### 9.3 提示词与模型调用

- 模型负责判断歧义，不负责自由改写教材；
- 提示词必须提供有限、可引用的证据范围；
- 输出应结构化，并引用 `block_id`、页码或具体证据；
- 不得把整本书交给模型后要求“自动整理正确”；
- 模型建议必须经过确定性校验才能写入产物；
- 模型失败、截断、JSON 解析失败或置信度不足不得降级为静默通过；
- 模型、用途、输入证据、重试、成本和结果必须可追踪。

## 10. 多样本能力建立方法

本项目采用“逐本建立产品，跨本提炼能力”的方式演进。

每个新样本必须经历：

1. 明确权威来源、正文范围、目标模板和产品类型；
2. 建立来源范围、结构、块、图片、表格、公式和答案账本；
3. 产出并验收该书的合格产品；
4. 将发现的问题归类为通用内核、profile、单书配置或暂不支持；
5. 只把有一般性依据的规则提升为共享能力；
6. 为新规则增加回归测试；
7. 重跑相关既有黄金样本，检查是否产生退化；
8. 记录能力矩阵和仍未覆盖的材料类型。

单一样本通过只能证明该样本产品成立，不能证明技能成熟。

项目成熟必须有跨类型、跨版式、跨语言的代表性样本，并且同时证明：

- 没有样本标识硬编码；
- 已通过历史黄金样本回归；
- 高风险页面完成视觉复核；
- 失败能够正确路由而不是被下游掩盖；
- 新样本接入主要通过适配器/profile/配置，而不是修改通用内核。

## 11. 验收证据

黄金样本至少应产生以下可审查证据：

- `source_scope_ledger`：来源页及正文包含/排除决定；
- `source_outline_ledger`：来源目录项和正文结构映射；
- `block_coverage_ledger`：每个来源块的输出或排除状态；
- `reading_order_ledger`：复杂页面的流水顺序；
- `media_ledger`：图片、表格、公式和图注闭环；
- `semantic_mapping_ledger`：教学角色到 ElegantBook 构件的映射理由；
- `template_integrity_report`：冻结区、class 和允许配置项差异；
- `compile_report`：编译器、退出状态、错误和 warning；
- `page_review`：绑定最终 PDF 哈希与页数的逐页验收；
- `canonical_decision_index`：统一索引各阶段人工决定、不确定项、退回、失效关系和规则提升候选。

规范性文件名、最小字段职责和阶段交接由六份产品规范确定；机器可校验的 JSON Schema、枚举和版本迁移规则
将在实现相应验证器时补齐，但不得改变已经确定的证据职责和硬门禁。

## 12. 验收级别

不得把不同级别压缩成一个“通过”。至少区分：

- `standard_drafted`：产品标准已起草；
- `standard_approved`：用户确认产品标准；
- `mechanical_pass`：结构、引用、文件和确定性检查通过；
- `source_fidelity_pass`：正文范围、块覆盖和阅读顺序与来源闭环；
- `semantic_mapping_pass`：结构和 ElegantBook 映射经核验；
- `template_integrity_pass`：模板冻结区未被修改；
- `compile_pass`：目标 ElegantBook 工程成功编译；
- `full_page_review_pass`：最终 PDF 逐页验收通过；
- `human_accepted`：用户接受黄金样本产品；
- `reusable_capability_validated`：跨样本回归证明能力可复用；
- `project_mature`：覆盖目标材料类型和语言，且无未解决的硬门禁。

任何更高层级都必须建立在相应低层证据上。脚本退出码为 0 只能证明其自身运行完成。

## 13. 失败归属与修复边界

缺陷必须路由到真正拥有证据和责任的阶段：

- 来源物缺失、OCR 空洞、正文范围和阅读顺序：证据重建阶段；
- 章节、教学栏目、答案和媒体关系：语义阶段；
- 模板构件选择、字符转义和合法 LaTeX：渲染阶段；
- 编译环境、引用和版面机械问题：编译/版面阶段；
- 完整性与最终视觉缺陷：最终验收阶段发现并退回拥有阶段。

禁止在下游通过删内容、改公式、换图片、隐藏 warning 或新增宏来掩盖上游缺陷。

## 14. 修改与回归规则

对代码、技能、profile 或提示词作实质修改前，必须：

1. 用具体样本和证据复现问题；
2. 确认缺陷所属阶段；
3. 提出方案、风险和回归范围，与用户讨论重要取舍；
4. 优先作最小但通用的修改；
5. 运行聚焦测试；
6. 重跑暴露问题的样本；
7. 重跑可能受影响的黄金样本；
8. 更新能力矩阵、决策记录和必要文档。

如果一个修复只能解释“为什么这一本书现在通过”，却不能说明一般适用条件，则不得进入共享内核。

## 15. 当前阶段的工作顺序

当前工作必须按以下顺序推进：

1. `[已完成]` 确认本 `AGENTS.md` 的根本原则；
2. `[已完成]` 将六份产品规范落成当前规范基线；
3. `[已完成]` 建立当前黄金样本验收矩阵、输入合同和唯一证据账本；
4. `[已完成第一组样本闭环]` 按六份规范审计、修复、编译并完成逐页验收；当前产品已由用户审阅，已知瑕疵另入账本；
5. `[已完成]` 形成 `known_defects_v1` 和 `five_skills_gap_matrix_v1`，不把旧技能输出反向当成标准；
6. `[已完成第一轮决策]` 确定先重构中间合同与渲染边界，暂不全面重写上游清理能力；
7. `[已完成第一轮实现与回归]` 固化 canonical ledger、decision index、render plan、template contract，替换正式生成器核心，并把精修技能收缩为只读诊断；
8. `[已完成第二轮最小切片]` 建立统一媒体来源表示、原生 Spec 03 媒体生产器和独立 promotion gate；第一黄金样本完成不可变迁移构建回归，AMC8 不同材料样本完成媒体范围的 formal-native 生产与提升验证；
9. `[已完成真实第二样本原生链验证]` 英文教材 Reading Explorer 1 已从只读正式 MinerU+Popo 产物建立 native Spec 01/02、关闭的 `source_reconciled` canonical ledger，并原样通过现有 native Spec 03 与 promotion gate；该结论只覆盖来源范围/顺序账本和媒体合同，不代表该书 Spec 04–06 或全产品通过；
10. `[已完成第三轮最小切片]` 将标准 ledger identity、累计 decision inheritance、一对多媒体 fragment 精确分组和 actionable source-order review queue 固化为 schema、生产器校验及 formal-native promotion 硬门禁；第一黄金样本保持迁移兼容且交付哈希不变，Reading Explorer 以 `formal_full_source` 回归，AMC8 以 `bounded_media_regression` 回归；
11. `[已完成第四轮最小切片]` 建立执行血缘与能力快照合同：formal-native producer 在 D 前冻结技能、脚本闭包、schema/profile/config、脱敏调用和运行环境证据 E，promotion 现场重算 producer 并独立绑定 evaluator；Reading Explorer 与 AMC8 生成新的 live-bound promotion，第一黄金样本保持 `historical_unbound` migration compatibility 且 accepted ZIP 哈希不变；
12. `[已完成第五轮最小切片]` 建立原生 Spec 04-A“来源目录—正文层级—最终目录”精确结构合同：第一黄金样本与 Reading Explorer 分别形成最终 v3 不可变快照并通过 10/10 promotion，完整 title candidate 被精确划分为结构证据或局部标题；AMC8 的媒体 fixture 因不足以证明全书结构而被硬拒绝，活动选择固化于 `promotions/registry-v7.json`，accepted ZIP 哈希不变；该结论只覆盖 Spec 04-A，完整 Spec 04 仍为 `not_evaluated`；
13. `[已完成第六轮最小切片]` 建立原生 Spec 04-B“来源支持的语义 span 与教学栏目分组”合同：完整语义阶段强制消费活动 Spec 04-A promotion 及其精确 ledger、decision index、source outline 和 final TOC；第一黄金样本形成 5067 个 included source atom 的唯一 span 分区、239 个有正文教学栏目组和 70 个独立语义标签，Reading Explorer 形成 3461 个原子的唯一分区及 28 个逐页核验栏目组；两组最终 v3 快照均通过 10/10 promotion，活动选择固化于 `promotions/registry-v9.json`，accepted ZIP 哈希不变。通用门禁禁止空组、成员重叠、脆弱媒体入组、非活动 04-A 父项和任何盒子/render plan/LaTeX 决定；`text` 类型的视觉栏目标签只有在精确页面证据和关闭评审支持且不与 04-A 结构节点冲突时才可作为标记。该结论只覆盖 Spec 04-B，完整 Spec 04 仍为 `not_evaluated`；
14. `[已完成第七轮最小切片并补齐能力清单]` 建立原生 Spec 04-C“模板能力原生提取与教学语义构件绑定”合同：完整构件阶段强制消费活动 Spec 04-B promotion，从精确模板 ZIP 与 intake 原生生成 `template_capability_manifest.json`，并把第一黄金样本 239 个非空教学组绑定到模板既有 `featurebox/notebox`、70 个无已确认正文的独立标签安全绑定为 `subsubsection*`，把 Reading Explorer 16 个 Word Link 组绑定到 `vocabbox`、12 个 Did You Know 组绑定到 `featurebox`。为服务后续 04-D，能力清单 v2 又原生补齐了普通段落、陈列公式和 graphicx 图片序列化能力，两组 04-C v2 不可变快照均重新通过 10/10 promotion，活动选择固化于 `promotions/registry-v11.json`；accepted ZIP 哈希仍为 `4296f7122f50d6024e85f6c0d7c442264ceb708e1ab7b674f1af799cef00cfef`。通用门禁禁止字符串/样本标识驱动构件选择、空盒、未存在 style、开放评审、render node/payload/render plan/LaTeX 及公式表格重建；具体角色映射暂留 book config，未凭单一样本提升为共享 profile。该结论只覆盖 Spec 04-C，完整 Spec 04 仍为 `not_evaluated`；
15. `[已完成第八轮最小切片]` 建立原生 Spec 04-D“完整 render plan 冻结”合同：生产器同时消费活动 Spec 04-C、04-A 与 Spec 03 promotion，机械生成结构、普通正文、教学盒子、媒体、来源顺序、精确 payload、媒体 binding 与输出锚点，不读取历史 render plan，不重选语义/构件/媒体。Reading Explorer 的 3461 个 included source atom 被精确划分到 3388 个 render node，包含 50 个结构节点、458 个局部标题、28 个继承教学盒子、219 个媒体节点、2517 个普通正文和 116 个文字注释；2 组一对多媒体 fragment 保持同节点，4 个结构证据与媒体重合项采用来源支持的虚拟结构节点且媒体原子只输出一次。最终 v2 不可变快照通过 10/10 formal-native promotion，`ledger_checkpoint=semantic_frozen`、`full_spec04_status=passed`，活动选择固化于 `promotions/registry-v13.json`。第一黄金样本没有被伪造为通过：04-D preflight 精确拦截第 30/38/39/124 页 4 个无正式表示的 chart 原子和第 134 页 2 个无正式表示的 equation 原子；因此其完整 Spec 04 仍为 `blocked`。该结论不包含 LaTeX、Spec 05 编译或 Spec 06 验收，accepted ZIP 哈希未变；
16. `[已完成第九轮最小切片]` 第一黄金样本的 6 个 Spec 03 阻断原子已在来源协调边界闭环：第 30/38/39/124 页 4 个 MinerU chart 原子分别是既有 Popo 主原子的重复来源 fragment，均并入原有 source-asset media atom；第 134 页两个同页同序 equation 原子与已有公式主原子 bbox 高重合且原 PDF 只显示一次，三者并入同一个已核验 PDF source-region media atom，没有重建公式，也没有新增逻辑输出。新的 `source-media-v3` 保持 1184 个媒体原子，将 fragment 覆盖从 1184 提升到 1190，形成 5 个一对多组，04-D preflight 的未表示脆弱原子由 6 降为 0。随后机械重放第一黄金样本 Spec 04-A v4、04-B v5、04-C v3、04-D v1，各自 promotion 均为 10/10，活动选择固化于 `promotions/registry-v18.json`；最终 5067 个 included source atom 被划分到 4682 个 render node，`ledger_checkpoint=semantic_frozen`、`full_spec04_status=passed`、review queue 为 0。该链仍明确属于 `migration_compatibility`，因为除本轮重绑的 5 个媒体组外，其余 1179 个历史媒体合同尚未整体重建为 formal-native 来源生产，不能冒充跨样本原生能力通过；本轮没有进入 Spec 05，accepted ZIP 哈希仍为 `4296f7122f50d6024e85f6c0d7c442264ceb708e1ab7b674f1af799cef00cfef`；
17. `[已完成第十轮执行验证]` 经用户批准，Spec 05 机械消费第一黄金样本活动的 `migration_compatibility` Spec 04-D v1，生成 `compile-v9-migration`：模板冻结与编译门禁 30/30 通过，产出 287 页 PDF；新 Spec 03 `render-coverage-v6-migration` 以 5067/5067 included atom、4682/4682 render node 通过 18/18 门禁。完整 Spec 06 已完成 287/287 页、112 个风险页和来源映射审查，人工队列关闭为 0，但确认两个来源要求的 level-2 课时目录项缺失，因此 `final-review-failed-v3-migration` 为 `failed/not_ready`，未创建 `final_verified` 或 acceptance commit；旧 accepted ZIP 哈希保持不变。缺陷证据表明渲染器已写 subsection 目录项，而冻结 class 设置 `tocdepth=1`，归属 Spec 04-C/04-D 模板能力边界，不得在 Spec 05 改模板或扁平化目录层级掩盖；
18. `[已完成第十一轮最小切片及跨样本回归]` 建立 `SM-H19 toc_representation_renderable` 硬门禁：Spec 04-C 从精确模板实物提取有效 `tocdepth=1`、entry type/depth 映射、原生可见层级和不修改模板 API 的 `localized_depth_override` 标准序列化能力；Spec 04-D 将来源语义层级、正文构件、TOC entry type、模板深度证据和序列化策略绑定进冻结计划，禁止二级标题伪装为一级、删除条目或修改 class/导言区。第一黄金样本最终活动 Spec 04-C v5 与 04-D v3 均通过 11/11 promotion；50 个 TOC 节点中 48 个走 `native`，仅 `sublesson-04-03-01` 与 `sublesson-04-03-02` 保持 `subsection` entry type 并采用单条目局部深度 override，完整计划覆盖 5067 个 source atom/4682 个 render node。Reading Explorer 以 formal-native Spec 04-C v3/04-D v3 回归相同门禁，其模板同样明确 `tocdepth=1`，来源要求的 50 个 TOC 节点全部属于原生可见层级，故 50 个走 `native`、0 个局部 override，两阶段各通过 11/11 promotion。最终活动选择固化于 `promotions/registry-v24.json`；第一黄金样本中间 C v4/D v2 是技能文本更新前的不可变非活动尝试，不得作为当前 live-bound 结论。该结论只重新关闭 Spec 04-C/04-D，不包含新的 Spec 05、render coverage 或 Spec 06，未扩大到其余媒体 formal-native、公式/表格重建或上游清理链；
19. `[已完成第十二轮最终产品重放]` 经用户批准，Spec 05 已机械消费第一黄金样本活动 Spec 04-D v3，生成不可变 `compile-v10-toc`：模板与编译门禁通过，正式 ZIP 哈希为 `946c10f84e0f17934d84a1261aa9629ece96aa4cce307d6933692296346d65b6`，287 页 PDF 哈希为 `fd7c9c1e4c188c62aec4fa69cb3f4063ada4084151e97bf54e865b70bd3299f0`；新的 `render-coverage-v7-toc` 以 5067/5067 included atom、4682/4682 render node 通过 18/18 门禁。完整 `final-review-passed-v3-toc` 覆盖 287/287 页、112/112 高风险页和 116/116 人工队列项，目录及 PDF outline 50/50 通过，两个来源要求的 level-2 课时条目均以合法 `subsection` 表示和局部深度策略实际呈现，因此原目录缺陷已在最终产品层关闭。Spec 06 的 21/21 硬门禁、独立 23/23 复核和跨阶段 22/22 一致性检查全部通过，并已按 D→L→M 创建 `final_verified` 子账本与接受提交；当前状态严格为 `ready_for_user_acceptance`、`human_accepted=false`。仍保留第 29 页局部标题落在页底而正文续至下一页这一非阻断 V3 排页瑕疵；本轮不提升其余媒体合同为 formal-native，也未扩大到公式/表格重建或上游清理链；
20. `[已完成黄金基线用户接受]` 用户已明确接受本轮产品，并确认第 29 页 V3 排页瑕疵不应单独触发共享能力重构。接受决定以新不可变 `human-acceptance-v1-toc` 记录为父 M 的子版本，绑定原 PDF、最终 PDF、正式 ZIP、模板合同与完整性报告、最终 decision index D、`final_verified` ledger L、最终页账本和 render manifest 的精确哈希；9/9 独立校验通过。第一黄金样本当前正式达到 `spec_status=passed`、`acceptance_status=human_accepted`，其接受 ZIP 哈希为 `946c10f84e0f17934d84a1261aa9629ece96aa4cce307d6933692296346d65b6`，PDF 哈希为 `fd7c9c1e4c188c62aec4fa69cb3f4063ada4084151e97bf54e865b70bd3299f0`。旧 `ready_for_user_acceptance` M 未被覆盖；
21. `[已完成第十三轮跨样本再排序]` 基于活动 `promotions/registry-v24.json`、第一黄金样本的哈希绑定用户接受、Reading Explorer 的 formal-native Spec 04-D v3 和 AMC8 的 bounded-media Spec 03 v3，形成 `refactor/next-slice-decision-v2/cross_sample_defect_ranking_v2` 与 `five_skills_gap_matrix_delta_v9`。排序严格区分三类事实：第一黄金样本是唯一完成 Spec 05/06 并达到 `human_accepted` 的 migration 产品证据；Reading Explorer 是完整来源链到 `full_spec04_status=passed` 的 formal-native 正样本，但尚未产生正式 LaTeX/PDF，不能把未执行 Spec 05/06 写成成书缺陷；AMC8 v3 是冻结时 13/13 通过的 bounded media 历史证据，但以当前技能字节现场重评会因 producer `SKILL.md`/entrypoint 漂移而在 `PG-H12` 正确失效为 12/13，因此当前只能作为必须被完整阶段准确拒绝的负向范围样本，不能称为 live-valid 正证据。当前 61/61 技能与工作区回归通过，Reading Spec 04-D 现场重评仍为 11/11。第 29 页 `V3-PAGINATION-001` 保持为单样本、非阻断 V3，不触发共享重构；KD-008–KD-011 等已关闭问题只保留回归义务，不重新列为开放缺陷；
22. `[已完成第十四轮最小切片]` `SPEC05-NATIVE-EXECUTION-V1` 已建立并通过：`cleanlatex-to-elegantbook` 新增 formal-native Spec 05 生产器，机械消费活动完整 Spec 04-D，依次冻结模板合同、执行冻结计划、先封装最终 ZIP、从其全新解包目录编译并生成绑定最终 PDF 的全页 raster pack；`luceon-popo-to-refined-elegantbook` 新增活动父项资格预检和独立 Spec 05 promotion evaluator。Reading Explorer 最终不可变 `spec05-native-v5` 精确执行 3388/3388 render node、复制 219 个来源资产，模板 13/13、编译 17/17 门禁通过，185 页正式 ZIP 哈希为 `fffcbe2d8d77071f32f0b2bcf43ac061fd17497955f85cf1c8ace401927ee751`，PDF 哈希为 `08dd2c11d1e4db511de505db950cee116d4712ef7eba03c2b814de01a56d32fd`；三条冻结模板字体提示已按精确指纹和第 1/5/46 页证据关闭，C0/C1/C2-open 均为 0。Spec 05 promotion v6 通过 12/12，producer/evaluator 均 live rehash，E→build evidence B→decision index D→build/stage M 无环，活动选择固化于 `promotions/registry-v25.json`。第一黄金样本接受 ZIP/PDF 哈希保持不变；AMC8 活动项被精确拒绝为 `SPEC05_PARENT_NOT_FULL_SPEC04D`，没有伪造或隐式刷新其 bounded Spec 03。共享回归收集 74 项并以退出码 0 完成。该结论严格止于 `compile_pass + final_render_pack`，不包含 Reading render coverage、Spec 06、用户接受、跨模板验证、公式/表格重建或上游清理链；完整证据见 `refactor/spec05-native-execution-v1/`；
23. `[已完成第十五轮跨样本再排序]` 基于 Reading `spec05-native-v5` 的 185 页最终 render pack、第一黄金样本的哈希绑定用户接受、AMC8 的 `SPEC05_PARENT_NOT_FULL_SPEC04D` 负向范围证据和工作区模板实物清点，形成 `refactor/next-slice-decision-v3/cross_sample_residual_ranking_v3` 与 `five_skills_gap_matrix_delta_v11`。Reading 最终第 1 页明确保留模板图片内的 `MATHEMATICS` 文字及模板 logo，而来源第 1–2 页明确为 Reading Explorer 1 / National Geographic / Heinle；第一黄金样本使用相同资源但数学学科一致并已被用户接受，因此该缺口被裁定为“显式、来源／批准绑定的封面与 logo 产品配置合同”，不得实现为语言、书名、样本 ID 或全局资源替换规则。Reading 原封面与扉页继续保持正文排除，但可作为 presentation identity 证据，二者不得混同。工作区所有目标模板 ZIP 输入均为同一哈希 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`，当前没有真实第二模板可供兼容性证明；因此新排序为：先 `SPEC05-COVER-CONFIG-CONTRACT-V1`，再对修正后的 Reading 执行 render coverage 与完整 Spec 06，最后在取得真实第二模板后验证跨模板能力；
24. `[已完成第十六轮最小切片]` `SPEC05-COVER-CONFIG-CONTRACT-V1` 已建立并通过：新增版本化 `spec05_presentation_config.json` schema，分别约束 cover 与 logo 的 `template_default/source_region_asset/approved_static_asset` 模式；非默认资产必须绑定路径、SHA-256、MIME、像素尺寸、来源或批准证据、确定性 fit/crop 和关闭决定，禁止按书名、语言、学科、样本 ID 或文件名推断。模板合同 v2、机械 renderer、formal-native Spec 05 producer 与独立 promotion evaluator 已共同执行 `PR-H01`–`PR-H04` 和 `S5-PG-H13`；新增资源使用不同文件名，冻结 `figure/cover.jpg`、`figure/logo.jpg`、class、模板骨架和自定义 API 均保持字节不变。Reading Explorer 新不可变 `spec05-native-v6-cover` 精确执行 3388/3388 render node、复制 219 个来源资产和 1 个来源封面裁片，185 页 ZIP 哈希为 `10f15d7da4cfab65185010f8c11ced29c2c0a1eaed6b8844e87938ca6799eae0`，PDF 哈希为 `5b2112850bf2d2bc9e4d656bc805432a530501c6fb934a70e1eb452bbba13257`；正文 payload 哈希与 v5 完全一致，页面 2–185 raster 全部不变，仅第 1 页按合同变化。Spec 05 promotion v7 通过 13/13，活动选择固化于 `promotions/registry-v26.json`。第一黄金样本以双 `template_default` v2 合同验证通过且 accepted ZIP/PDF 哈希不变；AMC8 仍精确拒绝为 `SPEC05_PARENT_NOT_FULL_SPEC04D`。共享与工作区回归 77 项通过。该结论只关闭封面／logo 配置与 promotion 门禁，不包含 Reading render coverage、Spec 06、用户接受或真实第二模板验证；
25. `[已完成第十七轮产品验收并确认失败]` Reading Explorer 当前活动 `spec05-native-v6-cover` 已完成规范 03 `render_coverage` 与完整规范 06：不可变 `render-coverage-v4-cover` 以 3939 个来源记录、3461/3461 included source atom、3388/3388 render node、219 个媒体节点和 4 个来源支持虚拟结构节点通过 18/18 门禁，独立复核无错误；随后 185/185 最终页、18 个风险页、目录／来源映射和 20 个 review queue 项全部完成视觉核验并关闭人工队列。完整审查没有把机械覆盖冒充来源忠实：源 PDF 第 116 页上半页的吉萨金字塔复合照片未进入 canonical ledger，最终第 127 页只剩与照片空间关系断裂的 A/B/C 文字；源页 31、62、139 等复合版式 asset 又在独立渲染时带出标题字母、邻图边缘或正文残片。两类均依规范 06 确认为 V1，`final-review-failed-v1-cover` 严格为 `failed/not_ready`，9 个来源页眉泄漏候选经核验为字符串同名假阳性，目录 50/50 通过，未创建 `final_verified` ledger 或 acceptance commit；失败快照独立 19/19 验证通过。Spec 06 可视化与失败冻结工具同时移除了固定来源目录页和“只支持目录失败”的样本过拟合，新旧失败合同回归 3/3 通过，但这只修正验收证据能力，不改变 Reading 产品失败结论；
26. `[已完成第十八轮跨样本再排序；下一切片待确认]` 综合 Reading 完整 Spec 06 的两个真实 V1、第一黄金样本历史 `KD-008` 空白／截断裁片与 `KD-009` 图表残留、以及 AMC8 bounded Spec 03 媒体控制，形成 `refactor/next-slice-decision-v4/cross_sample_defect_ranking_v4`、`known_defects_delta_v9` 和 `five_skills_gap_matrix_delta_v13`。新证据证明：100% block coverage 只能证明完整消费现有账本，不能证明账本覆盖原 PDF 的全部有意义视觉区域；MinerU/Popo asset 哈希一致只证明上游字节身份，不能证明裁片适合独立呈现。建议的下一最小切片为 `SPEC03-VISUAL-REGION-INTEGRITY-V1`，只在 Spec 01/02 来源协调—Spec 03 媒体表示边界建立页面级视觉区域完整性、复合 fragment 关系和裁片污染硬门禁，并以 Reading、第一黄金样本、AMC8 回归。该切片尚未实施，须经用户确认；不得扩展到公式／表格重建、教学盒子、第二模板、整个上游清理链或 renderer 本地修图。
27. `[已完成第十九轮最小切片]` `SPEC03-VISUAL-REGION-INTEGRITY-V1` 已建立并通过：Spec 03 新增独立原 PDF 全页 raster、页面级有意义视觉区域闭环、候选媒体完整指纹、独立呈现适用性决定、来源支持的复合 fragment 分组及 `PG-H14-page-visual-and-composite-integrity` formal-native promotion 硬门禁；直接 PDF 裁片改为从隔离 PDF 实例渲染，消除页面缓存历史对 PNG 字节哈希的影响。Reading Explorer 在 `formal_full_source` 范围复核 160/160 页，补入 1 个原账本遗漏的 visual source atom，将 6 个污染媒体原子重组为 4 个来源复合媒体，231 个输入媒体形成 229 个输出媒体、开放评审为 0，最终 `native-media-v7-visual` 以当前执行闭包通过 14/14 promotion。第一黄金样本以 `KD-008`、`KD-009` 和已接受交付执行不可变回归，ZIP 哈希 `946c10f84e0f17934d84a1261aa9629ece96aa4cce307d6933692296346d65b6`、PDF 哈希 `fd7c9c1e4c188c62aec4fa69cb3f4063ada4084151e97bf54e865b70bd3299f0` 均未变化；这不冒充其余历史媒体已完成 formal-native 全量重建。AMC8 仅以 `bounded_media_regression` 覆盖 17 页、23 个媒体原子并通过 14/14 promotion，不冒充全书来源忠实。活动选择固化于 `promotions/registry-v28.json`，共享技能 50/50、工作区 21/21、跨样本回归 7/7 通过。Reading 旧 Spec 04-A→04-D、Spec 05、render coverage 与 Spec 06 不是新活动 Spec 03 的后代，现为失效下游且本轮未重放；本结论不包含 Reading 产品通过，也未扩大到公式／表格重建、教学盒子、第二模板、整个上游清理链或 renderer 本地修图；完整证据见 `refactor/spec03-visual-region-integrity-v1/`。
28. `[已完成第二十轮 Reading 全链重放；待用户接受]` 对第 27 项暴露的正式血缘缺口先作通用合同修正：新 visual source atom 现在保留明确的原 PDF 页级 `upstream_block_ref`，并由 Spec 03 producer 根据新不可变账本重新计算 `source_records/source_evidence_records/included_atoms/excluded_source_records` 汇总；没有放宽 render coverage。随后从 `visual-region-v6`、`native-media-v10-provenance-fixed` 起机械重放 Reading Explorer 的 Spec 04-A/04-B/04-C/04-D v6、Spec 05 v9、`render-coverage-v6-provenance-fixed` 与 `final-review-passed-v1-provenance-fixed`，活动选择固化于 `promotions/registry-v45.json`。最终 3940 个来源记录中的 3462 个 included logical atom、3367 个 render node、213 个来源 asset 节点和 4 个来源 region 节点全部闭合；185 页 PDF 哈希为 `39aacd14a0a4976d1fa2c6f7688e3e48381a99110fb5e5f4537d89974ed19b7f`，正式 ZIP 哈希为 `3311d84ff385eb98f75f1e4259ae5945a5912c168a0f5506c0d8a08058bc41fb`。完整 Spec 06 已人工复核 185/185 页和 22/22 风险页，4 个复合媒体均在最终产品中正确呈现，人工队列为 0、确认 V0/V1 为 0，21/21 硬门禁、23/23 独立复核和 22/22 跨阶段一致性检查全部通过；保留第 30、57、68、79、132、143、154 页 7 项非阻断 V3 稀疏分页瑕疵。当前准确状态是 `spec_status=passed`、`acceptance_status=ready_for_user_acceptance`、`human_accepted=false`；不得把代理完成的逐页验收冒充用户接受。共享编排技能 50/50、机械渲染技能 9/9、工作区 23/23、三样本视觉区域回归 7/7 通过；第一黄金样本已接受字节未变，AMC8 仍仅为 bounded-media 回归。本轮未扩展到公式／表格重建、教学盒子、第二模板或上游清理链；完整重放证据见 `refactor/spec03-visual-region-integrity-v1/reading-full-replay-v1.*`。
29. `[已完成 Reading 用户接受]` 用户已明确接受 Reading 产品，并要求先将 7 项 V3 与其他样本残余缺陷重新排序，不立即启动共享能力重构。新的不可变 `human-acceptance-v1-provenance-fixed` 是 `final-review-passed-v1-provenance-fixed` 接受提交 M 的子版本，绑定原 PDF、185 页最终 PDF、正式 ZIP、模板合同与完整性报告、最终 decision index D、`final_verified` ledger L、最终页账本和 render manifest 的精确哈希；独立 9/9 校验通过。当前 Reading 正式达到 `spec_status=passed`、`acceptance_status=human_accepted`，PDF 哈希保持 `39aacd14a0a4976d1fa2c6f7688e3e48381a99110fb5e5f4537d89974ed19b7f`，ZIP 哈希保持 `3311d84ff385eb98f75f1e4259ae5945a5912c168a0f5506c0d8a08058bc41fb`；旧 `ready_for_user_acceptance` 提交未被覆盖。7 项 V3 均作为用户知悉的非阻断项绑定当前接受提交，不因此改变六规范通过状态。
30. `[已完成第二十一轮跨样本再排序；未选择共享重构]` 基于第一黄金样本与 Reading 两个哈希绑定的用户接受、Reading formal-native 全链证据、AMC8 bounded-media 控制、`promotions/registry-v45.json` 和现场模板 ZIP 清点，形成 `refactor/next-slice-decision-v5/cross_sample_residual_ranking_v5`、`known_defects_delta_v10` 与 `five_skills_gap_matrix_delta_v14`，10/10 证据边界验证通过。当前两个已接受产品中没有开放的确认 V0/V1；上一轮两个 Reading V1 已关闭并转为回归义务。最高优先项是第三种、结构不同材料类型的完整产品证据缺口，而不是已复现代码缺陷：AMC8 仍只证明 17 页/23 媒体原子的 bounded Spec 03，下一任务应先只读审计其是否具备完整 PDF、MinerU/Popo 血缘、正文范围、source-reconciled ledger 和模板输入；不足时选择另一组正式完整输入，不得把 fixture 冒充全书。第二模板验证继续因工作区所有目标模板 ZIP 均为同一哈希而阻塞。第一黄金样本第 29 页与 Reading 7 项分页 V3 已形成跨样本现象，但包含标题—正文分离、孤立图标、脚注和复合媒体跨页等不同关系，尚不能安全归并为一个通用分页规则；没有同类 taxonomy 和两个已接受产品无退化证据前，不实施 `keep-with-next`、强制分页、缩放或浮动策略。本轮没有修改共享技能，也未扩大到公式／表格重建、教学盒子、第二模板或上游清理链。
31. `[已完成第三完整样本 source-side 输入审计及模板约束纠偏；可启动原生 Spec 01/02]` 对 AMC8 的判断已从“既有 bounded fixture 是否完整”与“底层正式输入是否完整”两层重新核验：`AMC8_2026_Solutions.pdf` 的 23 页权威 PDF、冻结 MinerU 23/23 页、冻结 Popo 全页产物、同一 material_id/PDF hash 及 Popo→MinerU 精确血缘均存在；当前只读物化的 124 个文件（1 PDF、59 MinerU、64 Popo）现场重算 size/SHA-256 为 124/124 通过，已有 92 个图片对象检查也为 0 失败。故 AMC8 被选择为第三个 full-source 候选，不改选其他样本；但其既有 `bounded_media_regression` 仍严格只覆盖 17 页/23 媒体原子，不能升级或作为完整阶段父项，formal Spec 01/02、source-reconciled ledger 和完整产品仍为 `not_evaluated/not_built`。AMC8 与所有后续样本已按根本任务目标固定绑定唯一目标模板 `2025教材模版新版.zip`（SHA-256 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`），不存在模板选择 review；模板 class、导言区和既有定义必须冻结，生成正文不得定义或调用模板局部自定义命令／环境，只能在语义支持时通过标准 `tcolorbox` 调用模板已有 style key。新链仍须关闭“英文来源但上游 `lang=ch`”及第 1/23 页正文边界决定。完整审计与 9/9 验证见 `refactor/third-sample-full-source-audit-v1/`；本轮未修改共享技能、MinIO、生产系统或既有不可变产物。
32. `[已完成 AMC8 原生 Spec 01/02 full-source 链]` 从第 31 项已核验的只读正式输入新建 `full-source-input-v1` 与不可变 `source-reconciled-full-v1`：23/23 原 PDF 页面均已视觉复核，固定模板精确绑定唯一批准哈希 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`，124/124 物化对象现场重哈希、17/17 Spec 01 门禁和 8/8 独立 Spec 01/02 验证全部通过。正文页级范围为第 1–22 页，第 23 页 URL／二维码推广页排除；另以通用配置驱动的原子级范围合同排除第 1 页 5 个标题／署名／归属原子及 25 组空 `Solution:`＋`Watch LIVE` 推广原子共 50 个，来源可见的高亮正确选项继续保留。206 个 Popo 来源原子全部恰好一次入账，其中 149 个纳入、57 个排除；tree omission、顺序风险和开放 review 均为 0，canonical ledger 文件哈希为 `3b62b0599b1e4e795639ebbf7dc24a1371ceed4a37a42404df2e66f55970a102`，stage commit 哈希为 `9eb12f54549fae482b9e7e1f18c871d8d30be288df968dcbb75a1ed655c61c22`。上游错误的 `lang=ch` 被保留为证据并由关闭决定裁定为来源可见英文 `en`。工作区生产器升级为 `native-spec01-spec02/1.2.0`，新增原子级范围 override、固定模板批准哈希、全对象现场重哈希及视觉证据内封装；逻辑不读取 AMC8 文本／页码／样本标识，Reading Explorer 历史 v4 回归仍为 8/8，错误模板哈希负向运行被拒绝。本结论严格止于 `ledger_checkpoint=source_reconciled`，不包含 Spec 03 媒体 promotion、Spec 04、Spec 05、Spec 06 或产品接受；下一步只能由 formal-full-source Spec 03 消费本快照，不得复用旧 bounded fixture 冒充父项。完整摘要见 `refactor/amc8-native-spec01-spec02-full-source-v1/summary.md`。
33. `[已完成 AMC8 原生 Spec 03 formal-full-source 与正式提升]` 原生 Spec 03 已直接消费第 32 项 `source-reconciled-full-v1`，没有读取或继承旧 `bounded_media_regression` fixture。新鲜 MinerU+Popo 归一化得到 23 个媒体原子并与正式 canonical ledger 的 23 个媒体 source fragment 精确一一绑定，最低 bbox IoU 为 `0.89441586`、未绑定和低重叠评审均为 0；其中 provider `formula` 与 canonical `equation` 的差异通过通用标签兼容表归一化，不含样本标识、页码或正文硬编码。独立 `formal_full_source` 视觉区域阶段重新核验原 PDF 23/23 页及 23/23 媒体候选：所有有意义图形、公式、表格、选项视觉和被排除二维码均有明确处置，未发现空白／截断裁片、邻接污染或不可分离复合关系，因此复合媒体为 0、新增 visual source atom 为 0、开放 review 为 0，7/7 视觉门禁和 9/9 live validation 通过。随后 `native-media-full-v1` 形成 206 个来源记录、11 个累计关闭决定和 23 个媒体合同（21 个 included `source_asset_image`、2 个 excluded `none`），Spec 03 `spec_status=passed`；来源血缘 5/5、正式 promotion `native-media-full-v2` 14/14 通过，`PG-H14` 明确绑定 `scope_mode=formal_full_source`。活动 AMC8 Spec 03 选择已在 `promotions/registry-v46.json` 替换旧 bounded 项，promotion manifest 哈希为 `cd08f9a056faa2e063f0d6d97b8fb3cc234ff9b19a14f96ba30e325e43833a6e`；Reading、第一黄金样本和 AMC8 的视觉区域跨样本回归 7/7、聚焦单测 13/13 通过，两个已接受产品字节未变。本结论严格止于 Spec 03 `source_reconciled` 媒体合同与 promotion，不包含 AMC8 Spec 04、LaTeX、编译、Spec 06 或产品接受；没有修改共享技能、MinIO 或生产系统。完整摘要见 `refactor/amc8-native-spec03-full-source-v1/summary.md`。
34. `[已完成 AMC8 原生 Spec 04-A full-source 结构合同与正式提升]` Spec 04-A 已机械消费 `promotions/registry-v46.json` 中活动的 AMC8 formal-native Spec 03 promotion `amc8-native-spec03-media-full-v2`，精确继承其 206 个来源记录、11 个关闭决定、ledger identity 和原 PDF 血缘。逐页结构核验确认来源没有目录页、纳入正文的标题候选、unit 或 section 边界；第 1–22 页构成连续的 25 题 assessment，第 23 页推广内容继续排除。因此冻结为 1 个来源支持的 level-0 `assessment` 节点和 1 个最终目录项 `2026 AMC 8 Solutions`，题号保持 item-local，不污染书级目录；0 个标题候选、0 个 local heading、0 个开放 review。新不可变 `spec04a-structure-full-v1` 的 canonical ledger 文件哈希为 `1bb35a62710350802a79d67faedd5333263b724d90e3a804962477e1acd1ed61`、payload hash 为 `b4c12076f1e13560455848131c32a03ef36f7f115d3876e8db05735b690f7eea`，决定索引 12/12 closed。独立 promotion `amc8-spec04a-structure-full-v1` 通过 10/10 并以 formal-native 活动项追加到 `promotions/registry-v47.json`；v46 的 13 个既有活动项逐对象保持不变，聚焦单测 5/5 通过。该结论只覆盖来源目录—正文层级—抽象最终目录，`full_spec04_status=not_evaluated`；run 中没有 render plan、media binding、template contract、LaTeX 或教学构件选择，也未进入 Spec 04-B/04-C/04-D、Spec 05/06。没有修改共享技能、MinIO、生产系统或两个已接受产品。完整摘要见 `refactor/amc8-native-spec04a-full-source-v1/summary.md`。
35. `[已完成 AMC8 原生 Spec 04-B full-source 语义 span 与栏目分组提升]` Spec 04-B 已机械消费 `promotions/registry-v47.json` 中活动的 AMC8 formal-native Spec 04-A promotion `amc8-spec04a-structure-full-v1`，精确继承其 ledger、12 项累计关闭父决定、source outline 和 final TOC，不重新判断目录或标题候选；本阶段追加 1 项关闭决定后，决定索引为 13/13 closed。对第 1–22 页全部来源 raster 完成逐页教学栏目核验：纳入正文只有连续题干、选项、公式、图形和一个表格；重复的空 `Solution:` 与 `Watch LIVE` 行已由 Spec 02 排除，因而没有可成立的“栏目标记＋非空正文”教学栏目，也没有独立语义标签。新不可变 `spec04b-semantic-full-v1` 将 149 个 included source atom 恰好一次划分为 149 个 span：`book_structure=1`、`fragile_or_media=17`、`plain_body=131`，teaching groups 0、standalone labels 0、开放 review 0；“0 组”是来源支持的正式结论，不是漏标。canonical ledger 文件哈希为 `125d6ef8779e437483ea6943eaad1840da0499adb08faa55db906ea6bed293fc`、payload hash 为 `6b5a42e9a28ad0466a12851c1ff85ab04d0489c6eca5e06c72d32239b18b67a6`。独立 promotion `amc8-spec04b-semantic-full-v1` 通过 10/10 并以 formal-native 活动项追加到 `promotions/registry-v48.json`；v47 的 14 个既有活动项逐对象保持不变，聚焦单测 7/7 通过。唯一 `book_structure` span 是 Spec 04-A 继承的第一题结构锚点，只表达 assessment 起点关系，不授权把第一题改成标题；后续 04-D 必须证明该题干仍被完整输出。该结论只覆盖来源支持的语义 span 与教学栏目成员关系，`full_spec04_status=not_evaluated`；没有构件、盒子、template capability、render plan、LaTeX、公式／表格重建或 Spec 05/06。没有修改共享技能、MinIO、生产系统或两个已接受产品。完整摘要见 `refactor/amc8-native-spec04b-full-source-v1/summary.md`。
36. `[已完成 AMC8 原生 Spec 04-C full-source 模板能力与零构件绑定提升]` Spec 04-C 已机械消费 `promotions/registry-v48.json` 中活动的 AMC8 formal-native Spec 04-B promotion，并从固定 `2025教材模版新版.zip`（SHA-256 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`）及精确 intake 原生提取章节、目录深度、既有 tcolorbox styles、普通段落、陈列公式与来源图片序列化能力。由于父阶段正式确认 teaching groups 0、standalone labels 0，本阶段冻结 semantic objects 0、construct rules 0、construct bindings 0、boxed bindings 0、open reviews 0；模板中存在盒子不构成使用授权。执行前发现共享 review-bundle schema 的 `minItems=1` 与生产器“规则集合必须精确等于语义对象集合”冲突，经用户明确授权作最小通用修正为 `minItems=0`，并新增零对象回归；共享聚焦单测 8/8、技能校验通过，第一黄金样本 309 个既有绑定与 Reading Explorer 28 个既有绑定以当前逻辑重算均保持一致。新不可变 `spec04c-construct-full-v1` 内部 11/11、live validation 和独立 promotion 11/11 全部通过，canonical ledger 文件哈希为 `7cc017b995313d85b8abdb279213203a2e79dd5a7749b5146869a929713a334b`，template capability manifest 哈希为 `b4a680cc081a0159d8dad7eb2a33c9f9abaa5bb36449807093b9c0fc564d6e34`；formal-native promotion `amc8-spec04c-construct-full-v1` 已追加为 `promotions/registry-v49.json` 活动项，v48 的历史 entry 和活动选择保持不变。该结论只覆盖 Spec 04-C，`full_spec04_status=not_evaluated`；没有 render plan、LaTeX、模板合同、公式／表格重建或 Spec 05/06。下一步若进入 04-D，必须证明第一题结构锚点与题干正文恰好一次输出，不得误建标题。完整摘要见 `refactor/amc8-native-spec04c-full-source-v1/summary.md`。
37. `[已完成 AMC8 原生 Spec 04-D full-source 完整计划冻结与正式提升]` Spec 04-D 已机械消费 `promotions/registry-v49.json` 中活动的 AMC8 formal-native Spec 03、04-A 和 04-C promotion，没有重选结构、语义、构件或媒体。针对 Spec 04-A 以第一题原子同时承担 assessment 起点锚点的边界，通用生产器新增显式结构来源角色合同：非 `title` 的 `heading_evidence` 不得自动成为可见标题，必须由关闭决定裁决为 `title_fragment` 或 `post_heading_body`；后者必须生成独立普通正文节点，并在生产、live validation 与 promotion 三处验证非标题、恰好一次、原文和哈希一致。AMC8 单书 policy 将 `src-8c697f32acfa2b6faee92f43` 裁决为 `post_heading_body`，最终结构节点无 title source fragment，第一题仅在 render order 2 的 `paragraph` 节点出现一次。新不可变 `spec04d-render-plan-full-v1` 将 149 个 included source atom 精确覆盖为 150 个 render node（1 个虚拟结构、1 个结构后正文、127 个普通正文、21 个继承媒体），内部 11/11、独立 formal-native promotion 12/12 通过，review queue 为 0，ledger checkpoint 为 `semantic_frozen`、`full_spec04_status=passed`；render plan 哈希为 `704b2ec99590736a80cc063db0675347b6dbe0f4f41ffeeca956d7a324be149b`，活动选择追加至 `promotions/registry-v50.json`。共享聚焦单测 7/7、全量 53/53、Reading Explorer 当前生产器 dry run 通过；第一黄金样本的 11 个历史非 title 结构证据被新门禁按预期拒绝静默猜测，未来新快照须显式裁决，但既有活动 migration promotion 与两个已接受产品字节均未改写。本结论不包含 Spec 05、LaTeX、编译、render coverage、Spec 06 或产品接受；完整证据见 `refactor/amc8-native-spec04d-full-source-v1/`。
38. `[已完成 AMC8 Spec 05 构建、render coverage 与完整 Spec 06；产品被证据化拒绝]` Spec 05 已机械消费 `promotions/registry-v50.json` 的 AMC8 活动 Spec 04-D，不重选语义、构件、媒体或顺序；固定 `2025教材模版新版.zip` 的 class、导言区和定义保持冻结，生成 `spec05-native-full-v1`。该构建精确执行 150/150 render node、物化 21 个来源资产，模板与编译硬门禁通过，15 页 PDF 哈希为 `9137e9f24122632157be8e289a6f9e584e5b463ab01f0943159f117bbafe6dc9`，正式 ZIP 哈希为 `6d768582de6c72a666553384e16f778c63bedaa8f75e12677927d132da01c55c`；独立 Spec 05 promotion 13/13 通过并成为 `promotions/registry-v51.json` 的活动 formal-native 项。新的 `render-coverage-full-v2` 将 149/149 included logical atom、150/150 emission 和 21/21 source asset 闭环，18/18 门禁及独立校验通过；期间修正了一个通用 coverage 判定错误：来源标题支撑虚拟结构、首题正文另行恰好一次输出的 assessment 合法结构，不再被仅允许媒体锚点的旧条件误拒绝，且新增正反测试。完整 Spec 06 随后实际审查 15/15 页、5/5 风险页和全部来源映射，10 项人工队列关闭为 0，但确认 `AMC8-V1-COMPOSITE-ORDER-001`：第 2、6、11、12、13、15、21、23、25 题的来源顺序均为“题干→图／数组→选项”，现有 source-reconciled ledger、render plan 和成品却为“题干→选项→图／数组”；第 25 题更把选项留在成品第 14 页、所需三角形图孤立到第 15 页。该缺陷是确定性 `V1 BLOCKING`，归属 Spec 02 来源阅读顺序及 Spec 03 复合媒体关系边界，不是末页留白 V3，也不得在 Spec 05/06 或 LaTeX 层修饰。`final-review-failed-full-v1` 因此为 `failed/not_ready`，`FR-H01/H11/H12/H17` 失败，独立失败审计 19/19 通过；没有创建 `final_verified` ledger、接受 commit 或用户接受状态。后续必须先修复这 9 个复合题组并建立可识别 stem-diagram-options 关系的通用门禁，再从新的 canonical ledger 机械重放 Spec 03→04-A→04-B→04-C→04-D→05→render coverage→完整 Spec 06；本轮未修改全局共享技能、MinIO、生产系统或既有接受产品。完整证据见 `refactor/amc8-spec05-spec06-full-source-v1/summary.md`。
39. `[已完成 AMC8 复合题关系门禁、canonical order 修正及全链重放]` Spec 02/03 边界已建立通用 `stem_media_options` 关系合同与硬门禁：候选检测只依赖来源原子类型、bbox 和树顺序，正式重排必须消费精确 evidence-bound 且已关闭的关系决定；未关闭候选阻止 source-reconciled 通过，通用内核不读取题号、页码、英文文本、样本标识或固定哈希。AMC8 第 2、6、11、12、13、15、21、23、25 题在不可变 `source-reconciled-full-v5` 中均冻结为题干→图／表→选项，9/9 关系在 `spec04d-render-plan-full-v2` 中保持同序；Reading Explorer 历史 formal source 快照以新增门禁回归 9/9 通过。随后完整机械重放 Spec 03 v3、04-A v2、04-B v2、04-C v2、04-D v2、Spec 05 v2、render coverage v3 与 Spec 06 v3，各阶段 promotion／门禁分别为 14/14、10/10、10/10、11/11、12/12、13/13、18/18、21/21，最终独立 Spec 06 为 23/23，跨阶段交付一致性为 22/22。固定模板 SHA-256 仍为 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`，class、导言区、既有命令／环境／styles 均未改变；15 页 PDF 哈希为 `efbaec6a210da8a4e84935f0e9697ba57a9563f4b28ecabf7412006dc24ab99a`，正式 ZIP 哈希为 `a8affa27aa6cb6968322f37d187c09804ee00922e92bccde15683c6c3f90c292`。逐页验收关闭 9/9 人工项、确认 V0/V1 为 0；第 25 题五个选项按正确顺序续至稀疏末页，记录为非阻断 V3。独立验收曾因短选项缺少自动页锚点正确拒绝 FR-H15，最终验收器据此增加精确 block 级来源页映射校正，只移动有视觉证据的五个选项原子，防止页级粗调误移同页题干与媒体。当前状态严格为 `spec_status=passed`、`acceptance_status=ready_for_user_acceptance`、`human_accepted=false`；工作区测试 32/32 通过，活动注册表为 `promotions/registry-v57.json`。本轮没有扩展到公式／表格重建、教学盒子、第二模板或上游清理链，也没有修改全局共享技能、MinIO 或生产系统。完整证据见 `refactor/amc8-composite-order-full-replay-v1/summary.md`。
40. `[已完成 AMC8 用户接受]` 用户已明确接受第 39 项哈希绑定产品，并知悉非阻断 V3 `AMC8-V3-Q25-OPTIONS-CONTINUATION-001`。新的不可变 `human-acceptance-v1-composite-order-fixed` 是 `final-review-passed-full-v3` 接受提交 M 的子版本，绑定原 PDF、15 页最终 PDF、正式 ZIP、模板合同及完整性报告、最终 decision index D、`final_verified` ledger L、最终页账本和 render manifest 的精确哈希；独立 9/9 校验通过。当前 AMC8 正式达到 `spec_status=passed`、`acceptance_status=human_accepted`，PDF 哈希保持 `efbaec6a210da8a4e84935f0e9697ba57a9563f4b28ecabf7412006dc24ab99a`，ZIP 哈希保持 `a8affa27aa6cb6968322f37d187c09804ee00922e92bccde15683c6c3f90c292`；旧 `ready_for_user_acceptance` 提交未被覆盖。该用户接受只证明当前精确 AMC8 产品成立，不把单一样本提升为全部材料类型或项目成熟。
41. `[工作区 Spec 02 合同一致性已关闭；正式 TP-H14 集成待明确授权]` 对第 39–40 项作跨规范实现复核后，确认旧 `source-reconciled-full-v5` 的 ORDER 决定误引不存在的 `RO-H12`，且旧 validator 会对未来 producer 版本 fail-open。工作区 producer 已升级为 `native-spec01-spec02/1.3.1`，使用规范实际存在的 `RO-R01/RO-R03/RO-R06/RO-H08`，validator 新增明确 producer allowlist、规则 ID 范围和 decision index/event 一致性门禁；旧 v5 在新 validator 下准确失败 9/10，新不可变 `source-reconciled-full-v6-contract-conformant` 以相同 206 个 source atom payload、相同 9 个复合关系 payload通过 10/10，Reading 历史 v4 保持 10/10 且仍明确 `composite applicable=false`。另建立独立、能力清单驱动的 `TP-H14` 诊断器，第一黄金样本、Reading 和 AMC8 三个已接受正文均为 0 个模板局部自定义 API 定义／调用；但全局 Spec 05 producer 与 promotion evaluator 仍只正式执行 TP-H01–TP-H13，独立诊断不能替代正式门禁。依当前工作区授权边界，本轮未修改全局共享技能，故该合同一致性切片准确状态为 `blocked_pending_explicit_shared_skill_authorization`；AMC8 已接受 PDF/ZIP 字节未变，工作区测试 41/41 通过。证据见 `refactor/contract-consistency-closure-v1/`。
42. `[已完成 TP-H14 正式共享门禁与 AMC8 v6 全链机械重放]` 经用户明确授权，`cleanlatex-to-elegantbook` 的 formal-native Spec 05 producer 升级为 `native-spec05-execution/1.2.0`：以活动 `template_capability_manifest.json` 为唯一模板局部自定义 API 清单，在编译前扫描精确 `rendered_body.tex`，输出并绑定 `template_local_api_usage_report.json`，任何局部自定义命令／环境的定义或调用均阻断 TP-H14；标准 LaTeX 与模板已声明 `tcolorbox` style 不受误禁。`luceon-popo-to-refined-elegantbook` 的独立 evaluator 升级为 `spec05-native-promotion-gate/1.2.0`，不信任 producer 自报结果，而是对 promotion 绑定的能力清单与正文重新扫描，并逐字段比对清单、输入哈希和发现。两技能全量测试 73/73、工作区测试 41/41 通过；第一黄金样本、Reading 和 AMC8 既有正文回归均为 0 违规。随后从不可变 `source-reconciled-full-v6-contract-conformant` 新建完整链：Spec 03 v4、04-A/B/C/D v3 promotion 分别通过 14/14、10/10、10/10、11/11、12/12，Spec 05 `spec05-native-full-v3b-contract-conformant-tph14` 的 producer 14 个模板门禁与 17 个编译门禁通过，独立 promotion 14/14，其中 TP-H14 对 `activitynum`、`answershow`、`internalanswerbox` 清单现场重扫为 0 违规。新 15 页 PDF 与 ZIP 哈希分别为 `efbaec6a210da8a4e84935f0e9697ba57a9563f4b28ecabf7412006dc24ab99a`、`a8affa27aa6cb6968322f37d187c09804ee00922e92bccde15683c6c3f90c292`，与第 40 项既有接受产品逐字节一致；旧 run、promotion、registry 和用户接受记录均未回写。新 render coverage 18/18、完整 Spec 06 21/21、独立 Spec 06 23/23、跨阶段 22/22 通过，15/15 页、4 个风险页和 9 个 review queue 项闭环，保留同一项非阻断 Q25 末页续排 V3；新链严格停在 `ready_for_user_acceptance`、`human_accepted=false`，活动注册表为 `promotions/registry-v63.json`。一次 Docker socket 权限失败和一次误用旧 finalizer 的半成品目录均未被复用、提升或登记为活动产物。没有调用外部 LLM/GPU，没有写 MinIO 或生产系统，也未扩展到公式／表格重建、教学盒子、第二模板或上游清理链。完整证据见 `refactor/amc8-contract-conformant-tph14-replay-v1/`。
43. `[已完成 AMC8 v6 绑定证据链用户接受]` 用户已明确确认“同意接受这条新的 v6 绑定证据链”。新的不可变 `human-acceptance-v2-contract-conformant-tph14` 是第 42 项 `ready_for_user_acceptance` 提交 M 的子版本，父提交 SHA-256 为 `d966eb058efca3029a8045b62d8c6b30ce334dac558f47a71a8aed6b5b247761`；接受提交绑定相同原 PDF、15 页最终 PDF、正式 ZIP、模板合同与完整性报告、最终 decision index D、`final_verified` ledger L、最终页账本和 render manifest 的精确哈希，独立用户接受校验 9/9 通过。接受提交 SHA-256 为 `fe1af18682465eddbf096dbc4a73a6f5be5bc1cc3e0d905aafacfb5c36dc2b76`，活动 registry v63 SHA-256 为 `764de2e74042c02e676f522ca5c585e4a3110bec2b86442a1cf399bb220f3732`，v6 来源 canonical ledger SHA-256 为 `4b77a6960372447646a454a71139ffbe72e2dcc13df9766db30a998f97abbab8`。当前这条精确新链达到 `spec_status=passed`、`acceptance_status=human_accepted`；用户同时知悉非阻断 V3 `AMC8-V3-Q25-OPTIONS-CONTINUATION-001`。第 40 项旧用户接受、旧 `ready_for_user_acceptance` 提交、旧 registry 和全部历史 run 均未覆盖或回写；本次接受只证明该精确 AMC8 v6 产品及证据链成立，不等同于项目成熟或未验证材料类型已经支持。接受证据见 `regression_samples/media-source-representation/sample-002-amc8-solutions/runs/human-acceptance-v2-contract-conformant-tph14/` 和 `refactor/amc8-contract-conformant-tph14-replay-v1/human_acceptance_v2_binding.*`。
44. `[已完成 post-registry-v63 重基线与 v1 支持范围冻结]` 已从 v63 之后的活动证据重新生成跨样本残余缺陷、已知缺陷和五技能差距增量，形成 `refactor/next-slice-decision-v6/`；v1 正式范围冻结为唯一固定 `2025教材模版新版.zip`（SHA-256 `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`）、原 PDF、完整 MinerU、完整 MinerU-Popo 和来源血缘，不支持第二模板、缺失原 PDF/完整上游的正式通过、模板导言区／class／自定义 API 修改或生产发布。经只读候选审计，中文工作簿盲样 `sample-004-chinese-winter-math-g7` 以 31 页来源和完整上游血缘通过 13/13 资格门禁；该选择是配置与证据决定，不进入通用产品逻辑。
45. `[已完成中文 formal-native 工作簿盲样 Spec 01–06]` 盲样从不可变 `source-reconciled-full-v4-hybrid-closed` 依次通过原生 Spec 03、04-A、04-B、04-C、04-D、Spec 05、render coverage 和完整 Spec 06，活动选择最终固化到 `promotions/registry-v70.json`。Spec 03 ledger 含 794 个记录、756 个 included 原子和 160 个媒体原子；最终 Spec 05 v4 使用来源封面、固定模板和 `pdftocairo` 视觉证据，生成 45 页 PDF（SHA-256 `abcbff8de89436793f71a08b821da772d779ecfefa932601752aa050e4dfccf5`）及 ZIP（SHA-256 `844e9349b9e3c49c63c4b13bd8dc4a1d778527b25e29d408659befa1523879b8`）。最终 `final-review-passed-full-v1-pdftocairo` 完成 45/45 页、30 个风险页、756/756 原子、98 个顺序锚点和 34 项人工队列闭环，Spec 06 独立 23/23 通过；状态严格为 `passed/ready_for_user_acceptance`、`human_accepted=false`，没有伪造用户接受。过程中证实 host `pdftoppm` 会丢失该 CJK 字体栅格而 PDF 本身无缺字，Spec 05 renderer policy 因而通用支持经批准的 `pdftocairo`，并保持未知 renderer fail-closed。
46. `[已完成五技能最终架构裁决]` 盲样证据关闭了架构裁决前置条件，最终不可变裁决位于 `refactor/five-skills-final-architecture-v1/`，独立校验 13/13 通过。`luceon-popo-to-refined-elegantbook` 保留为 Spec 01–04 唯一合同／promotion 编排权威；`pdf-clean-markdown-rebuild` 在 formal-v1 中收缩为只读 intake／来源证据适配器，`clean.md` 不得替代 canonical ledger；`material-semantic-annotator` 退出 formal-v1 语义权威，只可提供非权威 profile／review 建议；`cleanlatex-to-elegantbook` 保留为 Spec 05 唯一机械模板合同、序列化和编译执行器；`refine-elegantbook-latex` 保留为只读诊断。Spec 06 与 release gate 继续由工作区独立 producer/evaluator 拥有；统一 CLI 只编排 DAG、哈希和断点，不成为第六个内容权威。两个被收缩技能的 `SKILL.md` 已增加 formal-v1 边界，三个相关技能均通过 quick validation；其他独立授权工作流没有被删除。
47. `[已完成 v1.0.0-rc1 本地 release candidate 工程与验证]` 已建立 manifest 驱动的 `scripts/elegantbookcompiler.py`、版本化 pipeline schema、无 shell 的 argv 执行、输入／输出哈希绑定、不可变输出保护、DAG 依赖、失败停止、LLM/GPU 显式授权及断点恢复；首轮因虚拟环境符号链接被错误解析到 base Python 而失败的 v1 state/report 保持原样，修复后使用独立 `.venv-rc1` 和精确 `requirements-v1.lock`。最终 `qualification_pipeline_v5` 的 8 个阶段全部通过且 8/8 在 resume 时只复核后跳过：架构 13/13、依赖 11/11、工作区／共享技能 134/134 测试、四样本活体哈希回归 36/36、正式代码面 41 个文件零样本名／ID／哈希／固定页码／用户绝对路径违规。锁定 TeX runtime 的 clean recompile 中，Reading、AMC8 与中文盲样三个 formal-native 产品 PDF 字节完全复现；第一黄金样本作为 migration compatibility，其 287 页逐页栅格、文本、尺寸、链接数和目录签名全部一致后通过迁移等价门禁。最新 RC manifest 为 `release/v1.0.0-rc1/final-v3/release_manifest.json`（SHA-256 `fcdf5c7eb7899ef2cb8dbcbb77b386948f9c283cae393e815ab2d77279fad1b0`），独立 final validation 13/13 通过；状态是 `release_candidate_ready_for_user_review`、`published=false`，release 资格链 LLM 调用、GPU 秒数和外部写入均为 0。大批量吞吐、第二模板、RTL／复杂文字、生产发布和盲样用户接受仍未被宣称。
48. `[已完成中文工作簿盲样及 v1.0.0-rc1 用户接受]` 用户已明确回复“接受”，新的不可变 `human-acceptance-v1-pdftocairo` 作为第 45 项 `ready_for_user_acceptance` 提交的子版本，绑定相同原 PDF、45 页最终 PDF、正式 ZIP、模板证据、最终 D、L、页账本和 render manifest；接受提交 SHA-256 为 `a36e3d52b6a99a743bd1556ca577ae0e20d8f9e94c43e21124a4822a55680157`，独立用户接受校验 9/9 通过。用户同时知悉非阻断 V3 `CWG7-V3-SPARSE-CONTINUATION-001`。产品级 `regression_matrix_v2.json` 已把四个代表样本全部绑定为 `human_accepted`，现场活体哈希回归仍为 36/36；Spec 03–05 活动 promotion 没有变化，`promotions/registry-v70.json` 未被混入接受状态。RC 接受记录位于 `release/v1.0.0-rc1/acceptance-v1/`，将当前 RC 冻结为本地 v1 能力基线；它不构成生产发布、稳定版 `v1.0.0`、`project_mature`、支持范围扩张或历史快照改写。

不得跳过产品标准，直接以旧技能的输出能力定义什么叫合格。

## 16. 报告与沟通

每次阶段性结论应清楚说明：

- 当前判断依据了哪些一手证据；
- 哪些是事实，哪些是推断或建议；
- 当前达到哪个验收级别；
- 仍有哪些硬门禁和不确定项；
- 问题属于哪个阶段；
- 建议的下一步及其风险；
- 是否修改了文件、技能、外部状态或生产数据。

避免使用“基本完成”“看起来正常”“应该没问题”等无法验收的表述。

## 17. 本工作区完成条件

只有同时满足以下条件，才可以把本工作区的目标描述为完成：

1. 产品标准和验收协议经用户确认；
2. 当前黄金样本达到 `human_accepted`；
3. 模板冻结、来源忠实、流水顺序、语义映射、编译和逐页验收都有可复核证据；
4. 现有五个技能已按产品标准完成保留、重构或替换决定；
5. 可复用实现通过多个教育材料类型和多语言代表样本回归；
6. 没有依赖样本名称、固定页码、文件哈希或出版社字符串的产品逻辑；
7. 未支持范围、人工复核边界和残余风险得到明确记录。

在此之前，只能准确报告当前完成的阶段和证据，不得把黄金样本通过等同于项目成熟。
