# 05 模板冻结与编译规范

状态：`Normative Baseline v0.3`

生效日期：`2026-07-18`

上位契约：[AGENTS.md](../AGENTS.md)  
上游规范：[04 教学语义与 ElegantBook 映射规范](04-semantic-elegantbook-mapping-spec.md)

## 0. 共同硬原则

1. 原 PDF 不可访问时，只能执行受限诊断；正式链路保持 `blocked`，不得取得来源忠实或最终产品通过；
2. 任何未关闭的人工判断或 review queue 项都阻止相应规范进入 `passed`；
3. 最终 PDF 必须逐页自动渲染和检查，高风险、异常及语义争议必须人工闭环，黄金样本还必须由用户明确接受。

本规范的局部 `passed` 不等于最终产品通过，并且不得替代规范 06 的全页及用户验收。

## 1. 目的

本规范确保已确认语义的正文只被写入目标模板允许的位置，模板冻结区不发生越权变化，
并且最终交付 ZIP 在固定、干净、可复现的环境中使用目标 ElegantBook 入口成功编译。

本规范是冻结 render plan 的唯一 LaTeX 渲染执行阶段，也是权威 `template_contract.json` 的唯一生产者。

本规范证明模板完整性和工程可编译性，不替代来源忠实、语义正确或最终视觉验收。

## 2. 输入

- 固定目标模板 `2025教材模版新版.zip`，批准 SHA-256 为
  `ebc5d6575153239552785265d2765de03b76c27d0532137712952f20ad0a9d4d`；
- 已通过规范 04 的不可变 canonical ledger snapshot、render plan 和映射报告；
- 规范 04 的 `semantic_stage_manifest.json`；
- 规范 04 唯一生成并已绑定哈希的 `template_capability_manifest.json`；
- 规范 01 的 `template_intake.json`；
- 当前 `canonical_decision_index.json` 快照；
- 正文和经闭环确认的图片/表格/公式资产；
- 允许修改的 metadata 配置；
- 经 schema 校验、决定关闭且与精确资产绑定的版本化 `spec05_presentation_config.json`；
- 编译环境合同；
- 允许补充的旁路依赖清单；
- 当前构建和交付目录。

正式编译只能消费已冻结的 render plan，不得在此阶段重新猜测结构、语义或盒子类型。

## 3. 模板冻结模型

规范 05 只能从模板实物、`template_intake.json`、用户约束和规范 04 的能力清单生成一次权威模板合同。
模板合同至少包含：

- 原始模板 ZIP SHA-256；
- `elegantbook.cls` 和其他不可变文件的逐文件哈希；
- `main.tex` 模板骨架及其哈希；
- `\documentclass` 名称和选项；
- 包加载列表、顺序和选项；
- 自定义命令、环境、theorem、tcolorbox style/key 的库存和签名；
- 正文插入边界；
- metadata 白名单、参数位置和允许值类型；
- cover、logo 各自的呈现模式、精确资产身份、来源／批准证据、确定性裁切与适配参数，以及对应关闭决定；
- 可补充但不得改变模板行为的旁路依赖清单；
- 正式编译引擎和最低环境要求。

规范 04 的 `template_capability_manifest.json` 必须字节级原样携带并保持原哈希。
本规范另产 `template_capability_validation_report.json`，证明清单与当前模板实物一致；
不得覆盖、修补或同名重生成能力清单。验证失败必须退回规范 01/04 修正固定模板身份或能力合同；
不得更换为其他模板输入。

由于 metadata 和封面配置可能位于 `\begin{document}` 之后，不能只比较传统导言区。
必须把允许修改的 metadata 参数和正文插入区替换为稳定占位符，再计算 `masked_main_sha256`；
模板骨架的其他字节均视为冻结。

## 4. 允许修改

仅允许：

- 修改模板合同列出的 `\title`、`\subtitle`、`\author`、`\institute`、`\date`、`\extrainfo` 等参数值；
- 修改合同允许的 `\logo`、`\cover` 或封面配置值；
- 在正文插入区写入 render plan 生成的正文；
- 复制账本已确认的资产；
- 增加模板合同明确允许的非可执行静态旁路依赖，并记录来源、用途和哈希。

允许项不是模糊的文件范围，而是具体宏参数、正文插入区和文件清单。

cover 与 logo 必须分别显式选择 `template_default`、`source_region_asset` 或
`approved_static_asset`，不得从书名、语言、学科、样本 ID 或文件名推断。非默认资产必须使用新文件名复制到
正式工程，绑定路径、SHA-256、MIME、像素尺寸和确定性 fit/crop；不得覆盖模板原有 cover/logo 文件。
`source_region_asset` 还必须绑定原 PDF、页面 raster、页码、bbox 和正文范围决定，并证明物化资产与来源裁片
逐像素一致。原书封面、扉页即使被规范 02 排除出正文，仍可作为 presentation identity 证据；这不会改变其
正文范围状态，也不得把其中内容重新排入正文。

## 5. 禁止修改

- 不得修改 `elegantbook.cls`；
- 不得修改 `\documentclass` 选项；
- 不得新增、删除或重定义宏包、命令、环境、颜色和 style；
- 不得在生成正文中定义或调用模板局部自定义命令、模板局部自定义环境；
- 不得把 tcolorbox style key 当成自定义环境调用；盒子只能序列化为标准 `tcolorbox` 环境并引用冻结模板已有 style key；
- 不得用 `\input`、`\AtBeginDocument` 等方式在正文侧绕过冻结区；
- 不得重定义 `\clearpage`、`\cleardoublepage` 或破坏章节和文档尾部 flush；
- 不得使用任何不同于固定 `2025教材模版新版.zip` 的模板或 class；
- 不得为单本样本增加临时“安全修复”宏；
- 不得使用 demo image、占位图或 fallback 文档冒充正式输出；
- 不得在编译阶段删除难处理正文、公式、表格或图片。

旁路依赖默认只允许冻结模板已经引用的静态图片、字体，以及不含 `@preamble`、命令/环境定义或脚本的纯数据型
`.bib` 文件。禁止新增 `.tex`、`.sty`、`.cls`、`.cfg`、`.def`、`.lua`、`.py`、`.sh`、可执行文件、
符号链接和任何能定义或改变 TeX 行为的内容。需要这些文件时只能建立经用户批准的新模板版本并重新冻结。

最终工程必须递归检查 `\input`、`\include`、class、package 和配置加载图，并对展开后的包、命令、环境、
theorem、颜色和 tcolorbox style/key 库存作机械比较；新增文件不得成为绕过冻结区的入口。

## 6. 编译合同

### 6.1 唯一渲染执行

规范 05 的确定性 renderer 只能执行已冻结的 render binding、必要的合法 LaTeX 转义和序列化。
它先生成规范化暂存产物 `rendered_body.tex`，再把完全相同的正文 payload 写入模板允许的正文插入区或模板已有正文文件。

必须生成 `render_execution_report.json`，记录：

- 输入 ledger snapshot、render plan、profile、book config 和能力清单哈希；
- `rendered_body.tex` 哈希；
- 最终工程中承载正文的文件、插入边界和正文 payload 哈希；
- 每个 output node/emission 到实际 LaTeX 锚点的映射；
- renderer、转义器和序列化规则版本；
- 确定性重跑结果。

renderer 不得重新选择语义、构件、参数、浮动或分页方案。无法执行计划时必须失败并退回规范 04，
不得在本规范内人工改选布局。

### 6.2 交付物先确定

正式 ZIP 必须先封装并计算哈希，再解压到全新隔离构建目录中编译。
这样可证明最终 PDF 来自与交付 ZIP 完全相同的源文件，而不是另一份临时工程。

### 6.3 干净构建

- 禁止依赖旧 `.aux`、`.toc`、缓存或历史 PDF；
- 使用模板合同规定的 XeLaTeX/latexmk 或其他目标引擎；
- 记录 TeX 版本、容器/主机、字体、依赖和命令；
- 连续编译到目录、页码和引用收敛，并设置最大轮数；
- 构建日志、输入哈希、ZIP 哈希和 PDF 哈希必须绑定同一 build ID。

### 6.4 全页渲染包

编译通过后启动一次绑定最终 PDF 哈希和固定渲染配置的全页 render job，并生成
`final_render_pack/manifest.json` 及全部页面 raster。manifest 至少包含：

- `schema_version`、`render_job_id`、`build_id`；
- 最终 PDF 路径、SHA-256 和页数；
- renderer 名称、版本、二进制哈希；
- DPI、色彩空间、页面格式、配置及配置哈希；
- 每页连续索引、页标签、尺寸、旋转、raster 相对路径和 SHA-256；
- 完成状态、生成时间和 manifest 自身哈希规则。

该不可变 render pack 由规范 06 直接消费；PDF 哈希和渲染配置未变时不得重建另一套互不一致的页面证据。

## 7. 必需产物

- `template_contract.json`；
- `spec05_presentation_config.json` 及其 schema、哈希和决定绑定；
- 规范 04 的原样 `template_capability_manifest.json` 及其原哈希；
- `template_capability_validation_report.json`；
- `template_integrity_report.json`；
- `template_integrity_report.md`；
- `rendered_body.tex`；
- `render_execution_report.json`；
- `build_environment.json`；
- `build_manifest.json`；
- `compile_report.json`；
- `compile_report.md`；
- `compile_warnings.json`；
- 正式 ElegantBook ZIP；
- 最终编译 PDF；
- 编译日志；
- `final_render_pack/manifest.json` 及全部页面 raster；
- `compile_decisions.jsonl`；
- 本规范消费或新建的 `canonical_decision_index.json` 不可变快照及哈希。

除目标模板本来就要求的工程文件和已批准的正文资产外，上述合同、报告、账本、决定文件、render pack 和
`rendered_body.tex` 暂存件均为审计 sidecar，不得擅自塞入正式 ElegantBook ZIP。

## 8. 模板硬门禁

- `TP-H01 template_zip_hash_matches`：使用正确模板版本；
- `TP-H02 class_hash_unchanged`：class 和不可变文件哈希不变；
- `TP-H03 masked_scaffold_hash_matches`：除白名单 metadata 和正文区外，模板骨架不变；
- `TP-H04 custom_api_inventory_unchanged`：命令、环境和 style 库存及签名不变；
- `TP-H05 documentclass_unchanged`：类和选项不变；
- `TP-H06 package_inventory_unchanged`：包、顺序和选项不变；
- `TP-H07 metadata_changes_allowlisted`：所有 metadata 差异均在白名单；
- `TP-H08 body_only_in_insertion_region`：正文只写入允许区域；
- `TP-H09 no_behavioral_bypass`：不存在正文侧绕过冻结区的定义；
- `TP-H10 ancillary_files_allowlisted`：旁路依赖均为严格白名单内的静态文件，并有来源、用途和哈希；
- `TP-H11 capability_manifest_verified`：原样能力清单与当前模板实物、合同和哈希一致，且验证报告独立存在；
- `TP-H12 transitive_tex_api_unchanged`：递归加载图和展开后的包、命令、环境、颜色及 style 库存无漂移；
- `TP-H13 no_executable_ancillary`：不存在宏定义型、配置型、脚本型、可执行或符号链接旁路依赖。
- `TP-H14 no_template_local_custom_api_usage`：生成正文中没有模板局部自定义命令／环境的定义或调用；
  tcolorbox 仅通过标准环境引用能力清单批准的既有 style key。

模板冻结违规不能人工豁免。需要改变模板时，必须由用户批准新模板版本并重新冻结。

## 8.1 呈现配置硬门禁

- `PR-H01 explicit_cover_logo_contract`：cover 与 logo 均有显式模式和完整合同，不存在隐式推断；
- `PR-H02 presentation_decisions_closed`：来源身份、默认资源适用性和非默认资源使用决定均已关闭；
- `PR-H03 frozen_presentation_assets_preserved`：模板原有 cover/logo 与其他冻结文件字节不变，新增资产不覆盖原文件；
- `PR-H04 presentation_assets_hash_bound`：配置、模板合同、物化资产、最终 ZIP 和决定索引中的路径与哈希完全一致。

formal-native Spec 05 promotion 必须独立重算上述四项并以
`S5-PG-H13-presentation-contract` 绑定；任一项不成立时不得 promotion。

## 9. 编译硬门禁

- `CP-H01 final_zip_is_build_input`：编译输入就是最终 ZIP 的解包内容；
- `CP-H02 clean_build`：使用全新构建目录；
- `CP-H03 compiler_exit_zero`：正式编译进程退出码为 0；
- `CP-H04 no_tex_error`：无 LaTeX Error、Undefined control sequence、Emergency stop、runaway argument；
- `CP-H05 all_dependencies_resolve`：图片、字体和必要文件完整；
- `CP-H06 references_converged`：目录、交叉引用和引用已收敛；
- `CP-H07 no_missing_glyph`：无缺失字形或未经批准的字体替代；
- `CP-H08 pdf_valid`：PDF 可解析且页数大于 0；
- `CP-H09 build_artifacts_bound`：ZIP、日志、manifest、PDF 和 render job 绑定同一 build ID/hash；
- `CP-H10 no_fallback_or_demo`：正式构建未使用 fallback、demo 或占位资产；
- `CP-H11 no_blocking_warning`：不存在 C0/C1 warning；
- `CP-H12 no_open_compile_review`：所有 C2 warning 已关闭；
- `CP-H13 frozen_render_plan_executed`：实际 LaTeX 逐项来自冻结 render plan，无重新分类或布局选择；
- `CP-H14 rendered_body_bound_to_delivery`：暂存正文与最终 ZIP 中正文 payload 哈希一致且锚点完整；
- `CP-H15 final_render_manifest_complete`：全页 render manifest 绑定当前 build/PDF，页数、路径和哈希完整；
- `CP-H16 decision_index_consistent`：本阶段决定已登记；决定索引只引用其冻结时已存在的 build、ZIP、PDF、
  warning 和父 ledger 证据，不引用随后生成的 `render_coverage` 子 ledger；
- `CP-H17 semantic_stage_commit_verified`：输入 ledger、render plan、能力清单和决定索引哈希与
  `semantic_stage_manifest.json` 完全一致。

## 10. Warning 分级

- `C0 FATAL`：TeX 错误、非零退出、PDF 损坏或构建结果缺失；
- `C1 BLOCKING`：缺字、字体替代、缺图、缺文件、未解析引用、构建不收敛、确认的内容裁切或严重越界；
- `C2 REVIEW_REQUIRED`：可能影响布局但无法自动确认的浮动、盒子、overfull、类兼容或字体 warning；
- `C3 INFO`：经证据证明不影响内容和可读性的固定模板 warning 或轻微 underfull。

固定模板 warning 可以形成带消息指纹、位置、数量和模板哈希的 baseline。
新 warning、位置变化或数量变化不能自动继承旧决定。

## 11. 人工决策门禁

- `CP-R01 metadata_values`：确认白名单 metadata 值；
- `CP-R02 ancillary_dependency_provenance`：只确认严格静态白名单内、且已被冻结模板引用的依赖来源与身份；
- `CP-R03 warning_classification`：对 C2 warning 结合渲染证据作决定；
- `CP-R04 presentation_assets`：确认 cover/logo 模式、产品身份适用性，以及非默认资产的来源或批准证据；
- `CP-R05 template_revision`：现有模板确实无法满足产品时，决定是否建立新模板版本。

所有布局选择必须已在规范 04 的 render plan 冻结前关闭。
人工不能授权可执行旁路依赖，也不能豁免模板漂移、C0/C1、缺失字形、缺图、未解析引用或非目标编译结果。
本阶段每个决定事件都必须登记到 canonical decision index 的新不可变快照。

## 12. 失败码

- `TEMPLATE_ARCHIVE_HASH_MISMATCH`
- `TEMPLATE_CLASS_DRIFT`
- `TEMPLATE_SCAFFOLD_DRIFT`
- `TEMPLATE_CUSTOM_API_DRIFT`
- `TEMPLATE_METADATA_NOT_ALLOWLISTED`
- `TEMPLATE_BEHAVIORAL_BYPASS`
- `TEMPLATE_ANCILLARY_FILE_UNAPPROVED`
- `TEMPLATE_CAPABILITY_MANIFEST_MISMATCH`
- `TEMPLATE_TRANSITIVE_API_DRIFT`
- `TEMPLATE_EXECUTABLE_ANCILLARY`
- `PRESENTATION_CONFIG_MISSING`
- `PRESENTATION_CONFIG_UNRESOLVED`
- `PRESENTATION_ASSET_HASH_MISMATCH`
- `PRESENTATION_SOURCE_SCOPE_CONFLICT`
- `PRESENTATION_INFERENCE_FORBIDDEN`
- `RENDER_PLAN_EXECUTION_MISMATCH`
- `RENDERED_BODY_DELIVERY_MISMATCH`
- `COMPILE_FINAL_ZIP_MISMATCH`
- `COMPILE_NONZERO_EXIT`
- `COMPILE_TEX_ERROR`
- `COMPILE_DEPENDENCY_MISSING`
- `COMPILE_REFERENCE_NOT_CONVERGED`
- `COMPILE_GLYPH_OR_FONT_FAILURE`
- `COMPILE_BLOCKING_WARNING`
- `COMPILE_PDF_INVALID`
- `COMPILE_RENDER_MANIFEST_INVALID`
- `COMPILE_DECISION_INDEX_INVALID`
- `COMPILE_SEMANTIC_STAGE_COMMIT_INVALID`
- `COMPILE_REVIEW_OPEN`

## 13. 失效与重验

- 正文、图片、metadata 或 cover/logo 配置及资产改动：重新冻结模板合同、重新封装、完整编译和全页自动渲染；
- 模板、class、包、字体或环境改动：模板合同失效，规范 05 从头执行；
- 只更新人工 warning 决定且 ZIP/PDF/hash 未变：可以不重新编译，但决定必须绑定现有哈希；
- 任意 PDF 字节变化：旧 render pack 和规范 06 结论全部失效。

## 14. 验收与交接

本规范的 `spec_status` 使用 `blocked/failed/needs_review/passed`。

只有 `passed` 时，才能把最终 ZIP、PDF、模板完整性报告、render execution、编译报告、warning 决定、
canonical decision index 快照和 `final_render_pack/manifest.json` 交给规范 03 的 `render_coverage` 重验及规范 06。
本规范通过仅表示模板与编译合格，不等于产品已完成。
