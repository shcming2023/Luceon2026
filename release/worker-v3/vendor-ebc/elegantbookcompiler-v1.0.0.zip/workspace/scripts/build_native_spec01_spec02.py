#!/usr/bin/env python3
"""Build immutable Spec 01/02 evidence and a source_reconciled ledger.

The core is material-agnostic. Source boundaries, profile, template identity,
and provider coordinate contracts are explicit configuration. Commit order is
E -> D1 -> Spec 01 artifacts -> E2 -> D2 -> Spec 02/03-L -> M.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import statistics
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader


VERSION = "native-spec01-spec02/1.3.2"
RUNNING_TYPES = {"header", "footer", "page_number"}
MEDIA_TYPES = {"image", "table", "chart"}
COMPOSITE_RELATION = "stem_media_options"
COMPOSITE_ROLES = ("stem", "media", "options")
SPATIAL_SWEEP_STRATEGY = "single_column_spatial_sweep"
EXPLICIT_SOURCE_ORDER_STRATEGY = "explicit_source_order"
FONT = "/System/Library/Fonts/Supplemental/Arial.ttf"


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def chash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def write_json(path: Path, value: Any) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return sha(path)


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for x in rows), encoding="utf-8")
    return sha(path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def scope_row(config: dict[str, Any], page: int) -> dict[str, Any]:
    matches = [x for x in config["scope_ranges"] if x["start_page"] <= page <= x["end_page"]]
    if len(matches) != 1:
        raise ValueError(f"page {page} has {len(matches)} scope decisions")
    return matches[0]


def flatten_tree(tree: dict[str, Any]) -> tuple[dict[int, int], dict[int, dict[str, Any]]]:
    ranks: dict[int, int] = {}
    contexts: dict[int, dict[str, Any]] = {}
    cursor = 0
    def walk(node: dict[str, Any], path: tuple[int, ...]) -> None:
        nonlocal cursor
        context = {"node_path": list(path), "node_type": node.get("type"), "node_title": node.get("title", ""), "node_level": node.get("level")}
        for block_id in node.get("block_ids") or []:
            if block_id not in ranks:
                ranks[block_id] = cursor
                contexts[block_id] = context
                cursor += 1
        for i, child in enumerate(node.get("children") or []):
            walk(child, path + (i,))
    walk(tree, ())
    return ranks, contexts


def raw_hash(value: Any) -> str:
    if isinstance(value, str):
        return hashlib.sha256(value.encode()).hexdigest()
    return chash(value)


def safe_template_inventory(template: Path) -> list[dict[str, Any]]:
    rows = []
    with zipfile.ZipFile(template) as z:
        for info in z.infolist():
            member = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            if member.is_absolute() or ".." in member.parts or mode == 0o120000:
                raise ValueError(f"unsafe template member: {info.filename}")
            if info.is_dir():
                continue
            data = z.read(info.filename)
            rows.append({"member": info.filename, "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    return rows


def validate_materialized_contract(intake: Path, contract: dict[str, Any]) -> dict[str, Any]:
    if contract.get("status") != "passed":
        raise ValueError("materialized input contract is not passed")
    entries = contract.get("entries") or []
    if not entries:
        raise ValueError("materialized input contract has no object inventory")
    failures = []
    for item in entries:
        path = intake / item["path"]
        if not path.is_file():
            failures.append({"path": item["path"], "error": "missing"})
            continue
        actual_size = path.stat().st_size
        actual_hash = sha(path)
        if actual_size != int(item["size_bytes"]) or actual_hash != item["sha256"]:
            failures.append({"path": item["path"], "error": "hash_or_size_mismatch"})
    declared_failures = [
        item for item in contract.get("declared_object_checks") or []
        if not item.get("sha256_match") or not item.get("size_match")
    ]
    image_failures = [
        item for item in contract.get("all_image_object_checks") or []
        if not item.get("declared") or not item.get("sha256_match") or not item.get("size_match")
    ]
    if failures or declared_failures or image_failures:
        raise ValueError(
            f"materialized input validation failed: objects={len(failures)} "
            f"declared={len(declared_failures)} images={len(image_failures)}"
        )
    return {
        "entries_rehashed": len(entries),
        "object_failures": 0,
        "declared_checks": len(contract.get("declared_object_checks") or []),
        "declared_failures": 0,
        "image_checks": len(contract.get("all_image_object_checks") or []),
        "image_failures": 0,
    }


def materialized_source_path(intake: Path, contract: dict[str, Any]) -> Path:
    """Resolve the source PDF from the validated materialization contract.

    Object names are upstream evidence and may use any Unicode-safe filename.
    The producer must not assume that the local basename is ``source.pdf``.
    """
    relative = contract.get("source_pdf", {}).get("path")
    if not isinstance(relative, str) or not relative:
        raise ValueError("materialized input contract has no source_pdf.path")
    candidate = (intake / relative).resolve()
    source_root = (intake / "inputs/source").resolve()
    if candidate.parent != source_root or candidate.suffix.lower() != ".pdf":
        raise ValueError(f"unsafe or invalid materialized source PDF path: {relative}")
    if not candidate.is_file():
        raise ValueError(f"materialized source PDF is missing: {relative}")
    return candidate


def block_scope_overrides(config: dict[str, Any], raw: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    known = {item["source_id"] for item in raw}
    expanded: dict[str, dict[str, Any]] = {}
    for group_index, group in enumerate(config.get("block_scope_overrides") or [], 1):
        if group.get("status") != "excluded":
            raise ValueError("block_scope_overrides currently allow only explicit exclusions")
        source_ids = group.get("source_ids") or []
        if not source_ids:
            raise ValueError(f"block scope override group {group_index} is empty")
        if not group.get("reason") or not group.get("page_category") or not group.get("evidence_refs"):
            raise ValueError(f"block scope override group {group_index} lacks reason, category, or evidence")
        for source_id in source_ids:
            if source_id not in known:
                raise ValueError(f"unknown block scope override source_id: {source_id}")
            if source_id in expanded:
                raise ValueError(f"duplicate block scope override source_id: {source_id}")
            expanded[source_id] = {**group, "override_group": group.get("override_id", f"BLOCK-SCOPE-{group_index:03d}")}
    return expanded


def copy_visual_evidence(source: Path, output: Path) -> tuple[str, str]:
    destination = output / "evidence/visual_review"
    destination.mkdir(parents=True, exist_ok=True)
    files = sorted(source.rglob("*")) if source.is_dir() else [source]
    inventory = []
    for path in files:
        if not path.is_file():
            continue
        relative = path.relative_to(source).as_posix() if source.is_dir() else path.name
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        inventory.append({"path": target.relative_to(output).as_posix(), "sha256": sha(target), "size_bytes": target.stat().st_size})
    if not inventory:
        raise ValueError("visual review evidence is empty")
    manifest_path = output / "evidence/visual_review_manifest.json"
    manifest_hash = write_json(manifest_path, {"schema_version": "visual-review-evidence/1.0", "files": inventory, "file_count": len(inventory)})
    return manifest_path.relative_to(output).as_posix(), manifest_hash


def nearest_mineru(row: dict[str, Any], by_page: dict[int, list[tuple[int, dict[str, Any]]]]) -> dict[str, Any] | None:
    candidates = by_page.get(int(row["page"]) - 1, [])
    if not candidates:
        return None
    compatible = {"title": {"text"}, "text": {"text", "list"}, "image": {"image", "chart"}, "table": {"table"}}.get(row["type"], {row["type"]})
    pool = [x for x in candidates if x[1].get("type") in compatible] or candidates
    rb = [float(x) for x in row.get("bbox") or [0, 0, 0, 0]]
    def score(item: tuple[int, dict[str, Any]]) -> float:
        b = [float(x) / 1000.0 for x in item[1].get("bbox") or [0, 0, 0, 0]]
        return sum(abs(rb[i] - b[i]) for i in range(4))
    index, candidate = min(pool, key=score)
    return {"flat_index": index, "page_idx": candidate.get("page_idx"), "type": candidate.get("type"), "bbox": candidate.get("bbox"), "bbox_distance": round(score((index, candidate)), 6), "asset_ref": candidate.get("img_path")}


def canonical_block_id(row: dict[str, Any]) -> str:
    return "src-" + hashlib.sha256(row["source_id"].encode()).hexdigest()[:24]


def expand_page_reading_strategies(config: dict[str, Any], page_count: int) -> dict[int, dict[str, Any]]:
    """Validate reviewed page-flow strategies and expand them to physical pages."""
    expanded: dict[int, dict[str, Any]] = {}
    strategy_ids: set[str] = set()
    for ordinal, strategy in enumerate(config.get("page_reading_order_strategies") or [], 1):
        strategy_id = strategy.get("strategy_id")
        if not strategy_id or strategy_id in strategy_ids:
            raise ValueError(f"page reading strategy {ordinal} has a missing or duplicate strategy_id")
        strategy_ids.add(strategy_id)
        if strategy.get("strategy_type") not in {SPATIAL_SWEEP_STRATEGY, EXPLICIT_SOURCE_ORDER_STRATEGY}:
            raise ValueError(f"{strategy_id} uses an unsupported strategy_type")
        if strategy.get("review_status") != "closed" or not strategy.get("evidence_refs") or not strategy.get("rationale"):
            raise ValueError(f"{strategy_id} lacks closed review, evidence, or rationale")
        start, end = int(strategy.get("start_page", 0)), int(strategy.get("end_page", 0))
        if start < 1 or end < start or end > page_count:
            raise ValueError(f"{strategy_id} has an invalid page range {start}-{end}")
        for page in range(start, end + 1):
            if page in expanded:
                raise ValueError(f"page {page} is claimed by multiple page reading strategies")
            expanded[page] = strategy
        if strategy.get("strategy_type") == EXPLICIT_SOURCE_ORDER_STRATEGY:
            if start != end:
                raise ValueError(f"{strategy_id} explicit_source_order must cover exactly one page")
            ordered_source_ids = strategy.get("ordered_source_ids") or []
            if not ordered_source_ids or len(ordered_source_ids) != len(set(ordered_source_ids)):
                raise ValueError(f"{strategy_id} explicit_source_order is empty or duplicated")
    return expanded


def single_column_spatial_sweep(
    rows: list[dict[str, Any]],
    tree_ranks: dict[int, int],
) -> tuple[list[dict[str, Any]], float]:
    """Order a reviewed single-column page by adaptive visual rows, then left-to-right.

    The row quantum is derived from the page's median non-media line height, so
    the universal core does not depend on a language, title vocabulary, page
    number, or fixed sample coordinate.
    """
    line_heights = [
        max(0.0, float(row["bbox"][3]) - float(row["bbox"][1]))
        for row in rows
        if row.get("type") not in MEDIA_TYPES
    ]
    positive = [height for height in line_heights if height > 0]
    quantum = (statistics.median(positive) * 0.60) if positive else 0.01
    quantum = max(quantum, 1e-6)

    def key(row: dict[str, Any]) -> tuple[int, float, float, int]:
        x0, y0 = float(row["bbox"][0]), float(row["bbox"][1])
        return (
            round(y0 / quantum),
            x0,
            y0,
            tree_ranks.get(int(row["id"]), 10**9),
        )

    return sorted(rows, key=key), quantum


def detect_composite_media_order_risks(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Find media whose tree order contradicts the page's vertical reading flow.

    This deliberately does not infer question labels or option text.  It only
    raises a reviewable spatial relation candidate.  A material-specific,
    evidence-bound relationship must close the candidate before formal pass.
    """
    positions = {row["source_id"]: index for index, row in enumerate(rows)}
    findings: list[dict[str, Any]] = []
    for media in rows:
        if media.get("type") not in MEDIA_TYPES:
            continue
        _, media_y0, _, media_y1 = [float(x) for x in media.get("bbox") or [0, 0, 0, 0]]
        above = [
            row for row in rows
            if row is not media
            and row.get("type") not in MEDIA_TYPES
            and float((row.get("bbox") or [0, 0, 0, 0])[3]) <= media_y0 + 0.015
        ]
        below = [
            row for row in rows
            if row is not media
            and row.get("type") not in MEDIA_TYPES
            and float((row.get("bbox") or [0, 0, 0, 0])[1]) >= media_y1 - 0.015
        ]
        displaced_below = [row for row in below if positions[row["source_id"]] < positions[media["source_id"]]]
        if not above or not displaced_below:
            continue
        findings.append({
            "candidate_id": f"COMPOSITE-CANDIDATE-{canonical_block_id(media)[4:].upper()}",
            "physical_page": int(media["page"]),
            "media_source_id": media["source_id"],
            "media_block_id": canonical_block_id(media),
            "media_type": media["type"],
            "tree_position": positions[media["source_id"]] + 1,
            "source_vertical_predecessor_refs": [canonical_block_id(row) for row in above],
            "displaced_below_refs": [canonical_block_id(row) for row in displaced_below],
            "detection_basis": "media bbox lies vertically between non-media spans but tree order places at least one lower span before the media",
        })
    return findings


def normalize_composite_relationships(
    config: dict[str, Any],
    raw: list[dict[str, Any]],
    ordered_by_page: dict[int, list[dict[str, Any]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Validate reviewed relations and mechanically apply their partial order."""
    known = {row["source_id"]: row for row in raw}
    relationship_ids: set[str] = set()
    claimed_source_ids: set[str] = set()
    normalized: list[dict[str, Any]] = []
    events: list[dict[str, Any]] = []
    findings = [finding for page in sorted(ordered_by_page) for finding in detect_composite_media_order_risks(ordered_by_page[page])]
    finding_by_media = {finding["media_source_id"]: finding for finding in findings}
    closed_media: set[str] = set()

    for ordinal, relation in enumerate(config.get("composite_reading_relationships") or [], 1):
        relationship_id = relation.get("relationship_id")
        if not relationship_id or relationship_id in relationship_ids:
            raise ValueError(f"composite relationship {ordinal} has a missing or duplicate relationship_id")
        relationship_ids.add(relationship_id)
        if relation.get("relationship_type") != COMPOSITE_RELATION:
            raise ValueError(f"{relationship_id} uses unsupported relationship_type")
        if relation.get("review_status") != "closed" or not relation.get("evidence_refs") or not relation.get("rationale"):
            raise ValueError(f"{relationship_id} lacks closed review, evidence, or rationale")
        physical_page = int(relation.get("physical_page", 0))
        segments = relation.get("segments") or []
        if [segment.get("role") for segment in segments] != list(COMPOSITE_ROLES):
            raise ValueError(f"{relationship_id} must declare the exact stem/media/options segment order")

        role_rows: dict[str, list[dict[str, Any]]] = {}
        flat_source_ids: list[str] = []
        for segment in segments:
            role = segment["role"]
            source_ids = segment.get("source_ids") or []
            if not source_ids or len(source_ids) != len(set(source_ids)):
                raise ValueError(f"{relationship_id}/{role} is empty or duplicated")
            unknown = [source_id for source_id in source_ids if source_id not in known]
            if unknown:
                raise ValueError(f"{relationship_id}/{role} references unknown source ids: {unknown}")
            rows = [known[source_id] for source_id in source_ids]
            if any(int(row["page"]) != physical_page for row in rows):
                raise ValueError(f"{relationship_id}/{role} crosses its declared physical page")
            if role == "media" and any(row.get("type") not in MEDIA_TYPES for row in rows):
                raise ValueError(f"{relationship_id}/media contains a non-media source type")
            if role != "media" and any(row.get("type") in MEDIA_TYPES for row in rows):
                raise ValueError(f"{relationship_id}/{role} contains a media source type")
            overlap = claimed_source_ids.intersection(source_ids)
            if overlap:
                raise ValueError(f"{relationship_id} overlaps another composite relationship: {sorted(overlap)}")
            role_rows[role] = rows
            flat_source_ids.extend(source_ids)
            claimed_source_ids.update(source_ids)

        stem_bottom = max(float(row["bbox"][3]) for row in role_rows["stem"])
        media_top = min(float(row["bbox"][1]) for row in role_rows["media"])
        media_bottom = max(float(row["bbox"][3]) for row in role_rows["media"])
        options_top = min(float(row["bbox"][1]) for row in role_rows["options"])
        if stem_bottom > media_top + 0.015 or media_bottom > options_top + 0.015:
            raise ValueError(f"{relationship_id} is not supported by source vertical geometry")

        page_rows = ordered_by_page.get(physical_page, [])
        page_source_ids = {row["source_id"] for row in page_rows}
        if not set(flat_source_ids).issubset(page_source_ids):
            raise ValueError(f"{relationship_id} contains excluded or non-logical source atoms")
        media_ids = [row["source_id"] for row in role_rows["media"]]
        missing_candidates = [source_id for source_id in media_ids if source_id not in finding_by_media]
        if missing_candidates:
            raise ValueError(f"{relationship_id} does not close a detected media-order inversion: {missing_candidates}")

        before_ids = [row["source_id"] for row in page_rows]
        before_positions = {source_id: before_ids.index(source_id) for source_id in flat_source_ids}
        anchor = min(before_positions.values())
        relation_set = set(flat_source_ids)
        remainder = [row for row in page_rows if row["source_id"] not in relation_set]
        ordered_relation_rows = [row for role in COMPOSITE_ROLES for row in role_rows[role]]
        remainder[anchor:anchor] = ordered_relation_rows
        ordered_by_page[physical_page] = remainder
        after_ids = [row["source_id"] for row in remainder]
        if [after_ids.index(source_id) for source_id in flat_source_ids] != list(range(anchor, anchor + len(flat_source_ids))):
            raise ValueError(f"{relationship_id} did not freeze as one contiguous ordered group")
        closed_media.update(media_ids)
        role_block_ids = {role: [canonical_block_id(row) for row in role_rows[role]] for role in COMPOSITE_ROLES}
        local_evidence = list(dict.fromkeys([
            *relation["evidence_refs"],
            f"evidence/source_pages/page-{physical_page:03d}.png",
            f"evidence/order_overlays/page-{physical_page:03d}.png",
        ]))
        normalized.append({
            "relationship_id": relationship_id,
            "relationship_type": COMPOSITE_RELATION,
            "physical_page": physical_page,
            "review_status": "closed",
            "roles": role_block_ids,
            "source_ids_by_role": {role: [row["source_id"] for row in role_rows[role]] for role in COMPOSITE_ROLES},
            "before_order": [canonical_block_id(known[source_id]) for source_id in before_ids if source_id in relation_set],
            "after_order": [canonical_block_id(known[source_id]) for source_id in flat_source_ids],
            "source_geometry": {"stem_bottom": stem_bottom, "media_top": media_top, "media_bottom": media_bottom, "options_top": options_top},
            "rationale": relation["rationale"],
            "evidence_refs": local_evidence,
        })
        events.append({
            "event_id": f"ORDER-COMPOSITE-{ordinal:03d}",
            "physical_page": physical_page,
            "trigger_kind": "reading_order_reanchor",
            "trigger_code": "COMPOSITE_STEM_MEDIA_OPTIONS_ORDER",
            "action_kind": "reanchor_reading_order",
            "signal_only": False,
            "requires_human_review": True,
            "review_status": "closed",
            "relationship_id": relationship_id,
            "affected_source_refs": [canonical_block_id(known[source_id]) for source_id in flat_source_ids],
            "before_position": before_positions[media_ids[0]] + 1,
            "after_position": anchor + len(role_rows["stem"]) + 1,
            "before_order": normalized[-1]["before_order"],
            "after_order": normalized[-1]["after_order"],
            "evidence_refs": [
                f"evidence/source_pages/page-{physical_page:03d}.png",
                f"evidence/order_overlays/page-{physical_page:03d}.png",
            ],
        })

    unresolved = [finding for finding in findings if finding["media_source_id"] not in closed_media]
    unresolved_events = [{
        **finding,
        "event_id": f"ORDER-UNRESOLVED-{finding['candidate_id']}",
        "trigger_kind": "manual_ambiguity",
        "trigger_code": "COMPOSITE_MEDIA_ORDER_INVERSION_UNRESOLVED",
        "action_kind": "queue_manual_review",
        "signal_only": False,
        "requires_human_review": True,
        "review_status": "open",
        "affected_source_refs": [finding["media_block_id"], *finding["displaced_below_refs"]],
        "evidence_refs": [
            f"evidence/source_pages/page-{int(finding['physical_page']):03d}.png",
            f"evidence/order_overlays/page-{int(finding['physical_page']):03d}.png",
        ],
    } for finding in unresolved]
    return normalized, events + unresolved_events


def order_page(rows: list[dict[str, Any]], tree_ranks: dict[int, int], physical_page: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    ranked = sorted([r for r in rows if r["id"] in tree_ranks], key=lambda r: tree_ranks[r["id"]])
    omitted = sorted([r for r in rows if r["id"] not in tree_ranks], key=lambda r: (r["bbox"][1], r["bbox"][0]))
    events: list[dict[str, Any]] = []
    event_counter = 0
    def record_event(row: dict[str, Any], trigger_code: str, action_kind: str, before: int | None, after: int) -> None:
        nonlocal event_counter
        event_counter += 1
        events.append({
            "event_id": f"ORDER-RISK-P{physical_page:03d}-{event_counter:03d}",
            "physical_page": physical_page,
            "trigger_kind": "source_tree_omission" if trigger_code == "POPO_TREE_OMISSION" else "reading_order_reanchor",
            "trigger_code": trigger_code,
            "action_kind": action_kind,
            "signal_only": False,
            "requires_human_review": True,
            "affected_source_refs": [canonical_block_id(row)],
            "before_position": before,
            "after_position": after,
            "evidence_refs": [f"evidence/order_overlays/page-{physical_page:03d}.png"],
        })
    for item in omitted:
        y, x = item["bbox"][1], item["bbox"][0]
        position = len(ranked)
        for i, other in enumerate(ranked):
            if other["bbox"][1] > y + 0.01 or (abs(other["bbox"][1] - y) <= 0.01 and other["bbox"][0] > x):
                position = i
                break
        ranked.insert(position, item)
        record_event(item, "POPO_TREE_OMISSION", "reinsert_missing_source", None, position + 1)
    for item in list(ranked):
        x0, y0, x1, _ = item["bbox"]
        if item["type"] == "image" and y0 <= 0.05 and x1 - x0 >= 0.75:
            old = ranked.index(item)
            if old > 0:
                ranked.pop(old); ranked.insert(0, item)
                record_event(item, "TOP_SPANNING_MEDIA", "reanchor_reading_order", old + 1, 1)
    for item in list(ranked):
        x0, y0, x1, _ = item["bbox"]
        if item["type"] != "image" or x0 <= 0.45 or y0 <= 0.5 or x1 - x0 <= 0.2:
            continue
        right_predecessors = [r for r in ranked if r is not item and r["bbox"][0] > 0.45 and r["bbox"][1] < y0 and r["type"] != "image"]
        if right_predecessors:
            target = max(ranked.index(r) for r in right_predecessors) + 1
            old = ranked.index(item)
            if old < target:
                ranked.pop(old); target -= 1; ranked.insert(target, item)
                record_event(item, "LOWER_RIGHT_MEDIA_AFTER_COLUMN_TEXT", "reanchor_reading_order", old + 1, target + 1)
    return ranked, events


def overlay(raster: Path, rows: list[dict[str, Any]], destination: Path) -> None:
    image = Image.open(raster).convert("RGB")
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(FONT, 15)
    for i, row in enumerate(rows, 1):
        x0, y0, x1, y1 = row["bbox"]
        box = (round(x0 * image.width), round(y0 * image.height), round(x1 * image.width), round(y1 * image.height))
        draw.rectangle(box, outline=(220, 0, 0), width=2)
        draw.rectangle((box[0], box[1], box[0] + 28, box[1] + 18), fill="white", outline=(220, 0, 0))
        draw.text((box[0] + 2, box[1]), str(i), font=font, fill="black")
    destination.parent.mkdir(parents=True, exist_ok=True)
    image.save(destination, optimize=True)


def build(args: argparse.Namespace) -> dict[str, Any]:
    repo, intake, output = args.repo_root.resolve(), args.intake_run.resolve(), args.output.resolve()
    config = read_json(args.config.resolve())
    decision_prefix = "DEC-" + hashlib.sha256(config["sample_id"].encode("utf-8")).hexdigest()[:10].upper()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"refusing nonempty output: {output}")
    output.mkdir(parents=True, exist_ok=True)
    stamp = now()
    mineru_root, popo_root = intake / "inputs/mineru", intake / "inputs/popo"
    mineru_manifest, popo_manifest = read_json(mineru_root / "manifest.json"), read_json(popo_root / "manifest.json")
    materialized_path = intake / "contracts/input_contract.json"
    materialized = read_json(materialized_path)
    materialized_validation = validate_materialized_contract(intake, materialized)
    source = materialized_source_path(intake, materialized)
    raw = read_json(popo_root / "popo_raw.json")
    scope_overrides = block_scope_overrides(config, raw)
    pdf = PdfReader(str(source)); page_count = len(pdf.pages)
    if args.require_page_count and page_count != int(config["expected_page_count"]):
        raise ValueError(f"unexpected page count {page_count}; expected {config['expected_page_count']}")
    for page in range(1, page_count + 1): scope_row(config, page)
    page_strategies = expand_page_reading_strategies(config, page_count)
    template = (repo / config["template"]["path"]).resolve()
    approved_template_hash = config["template"].get("approved_sha256")
    if not approved_template_hash:
        raise ValueError("template.approved_sha256 is required for a formal run")
    if sha(template) != approved_template_hash:
        raise ValueError("template hash differs from the workspace-approved fixed template")
    template_inventory = safe_template_inventory(template)
    template_copy = output / "inputs/template/template.zip"; template_copy.parent.mkdir(parents=True); shutil.copy2(template, template_copy)
    if sha(template_copy) != approved_template_hash:
        raise ValueError("copied template hash differs from the approved fixed template")

    # E1 -> D1.
    evidence1 = [
        {"ref": str(source), "sha256": sha(source)},
        {"ref": str(mineru_root / "manifest.json"), "sha256": sha(mineru_root / "manifest.json")},
        {"ref": str(popo_root / "manifest.json"), "sha256": sha(popo_root / "manifest.json")},
        {"ref": "inputs/template/template.zip", "sha256": sha(template_copy)},
    ]
    input_events = [
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-IN-001", "rule_id": "IN-R02", "status": "closed", "decision": "Use the manifest-proven MinerU and Popo lineage selected by the user.", "evidence_refs": [evidence1[1]["ref"], evidence1[2]["ref"]], "recorded_at": stamp},
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-IN-002", "rule_id": "IN-R04/IN-H06", "status": "closed", "decision": "Bind this sample to the sole workspace-approved fixed ElegantBook template by exact SHA-256; use it for identity only in this slice.", "evidence_refs": ["inputs/template/template.zip"], "recorded_at": stamp},
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-IN-003", "rule_id": "IN-H07", "status": "closed", "decision": "Treat MinIO sources as read-only and materialize only local isolated copies.", "evidence_refs": [str(intake / "contracts/input_contract.json")], "recorded_at": stamp},
    ]
    source_profile = config.get("source_profile") or {}
    if source_profile.get("upstream_declared_language") and source_profile.get("upstream_declared_language") != source_profile.get("language"):
        input_events.append({"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-IN-004", "rule_id": "IN-R03", "status": "closed", "decision": source_profile["language_resolution"], "evidence_refs": [evidence1[0]["ref"], evidence1[1]["ref"]], "recorded_at": stamp})
    input_events_hash = write_jsonl(output / "decisions/input_decisions.jsonl", input_events)
    d1 = {"schema_version": "canonical-decision-index/1.1", "decision_index_id": f"{config['sample_id']}-decisions", "snapshot_id": f"{config['sample_id']}-input-decisions-v1", "version": 1, "parent_index_ref": None, "parent_index_hash": None, "acyclic_commit_rule": "evidence_E_then_root_decision_index_D", "spec_status": "passed", "evidence_committed_before_index": evidence1, "decision_event_files": [{"path": "decisions/input_decisions.jsonl", "sha256": input_events_hash}], "decisions": [{"decision_id": x["decision_id"], "status": x["status"], "rule_id": x["rule_id"], "event_file": "decisions/input_decisions.jsonl"} for x in input_events], "summary": {"total": len(input_events), "closed": len(input_events), "open": 0, "stale": 0, "invalidated": 0}, "generated_at": stamp}
    d1_hash = write_json(output / "decisions/input_decision_index.json", d1)
    source_trace = {"schema_version": "source-trace/1.0", "material_id": config["material_id"], "source_pdf": mineru_manifest["source_pdf"], "mineru": {"run_id": mineru_manifest["run_id"], "manifest_sha256": evidence1[1]["sha256"]}, "popo": {"run_id": popo_manifest["run_id"], "manifest_sha256": evidence1[2]["sha256"], "upstream_mineru": popo_manifest.get("upstream_mineru")}, "lineage_verified": popo_manifest.get("upstream_mineru", {}).get("run_id") == mineru_manifest["run_id"]}
    write_json(output / "contracts/source_trace.json", source_trace)
    write_json(output / "contracts/materialized_manifest.json", materialized)
    template_intake = {"schema_version": "template-intake/1.1", "template_zip_sha256": sha(template_copy), "approved_template_sha256": approved_template_hash, "binding_status": "exact_match", "members": template_inventory, "entry": "main.tex", "class": "elegantbook.cls", "usage_scope": config["template"]["usage_scope"]}
    write_json(output / "contracts/template_intake.json", template_intake)
    input_contract = {"schema_version": "input-contract/2.1", "run_id": args.run_id, "material_id": config["material_id"], "sample_id": config["sample_id"], "spec_status": "passed", "run_mode": "formal", "access_mode": "read_only_materialization", "source_pdf": {"path": str(source), "sha256": sha(source), "page_count": page_count, "size_bytes": source.stat().st_size}, "mineru": {"run_id": mineru_manifest["run_id"], "manifest_sha256": evidence1[1]["sha256"]}, "popo": {"run_id": popo_manifest["run_id"], "manifest_sha256": evidence1[2]["sha256"]}, "template": {"path": "inputs/template/template.zip", "sha256": sha(template_copy), "approved_sha256": approved_template_hash, "binding_status": "exact_match"}, "source_profile": source_profile, "materialized_contract": {"source_ref": str(materialized_path), "sha256": sha(materialized_path), **materialized_validation}, "page_coordinate_basis": {"pdf_physical_page": "one_based", "upstream_page_idx": "Popo one_based and MinerU zero_based", "mineru_bbox": config["bbox_contract"]["upstream_space"], "popo_bbox": "normalized_0_1", "origin": "top_left", "pdf_cropbox": "points_bottom_left"}, "canonical_decision_index_ref": "decisions/input_decision_index.json", "canonical_decision_index_sha256": d1_hash, "generated_by": VERSION}
    input_contract_hash = write_json(output / "contracts/input_contract.json", input_contract)
    input_gates = [{"gate_id": f"IN-H{i:02d}", "status": "passed"} for i in range(1, 18)]
    input_gates[1]["evidence"] = {"source_hash_match": sha(source) == config["source_pdf"]["sha256"], "source_size_match": source.stat().st_size == int(config["source_pdf"]["size_bytes"]), "page_count_match": page_count == int(config["expected_page_count"])}
    input_gates[4]["evidence"] = {"lineage_verified": popo_manifest.get("upstream_mineru", {}).get("run_id") == mineru_manifest["run_id"]}
    input_gates[5]["evidence"] = {"fixed_template_hash_match": sha(template_copy) == approved_template_hash}
    input_gates[7]["evidence"] = materialized_validation
    if not all(input_gates[1]["evidence"].values()) or not input_gates[4]["evidence"]["lineage_verified"]:
        raise ValueError("Spec 01 source identity, page count, or lineage validation failed")
    write_json(output / "qa/input_validation_report.json", {"schema_version": "input-validation/1.1", "spec_status": "passed", "gates": input_gates, "failures": [], "input_contract_sha256": input_contract_hash})

    # E2: page geometry, rasters, Popo atoms, candidate order, overlays.
    raster_source = args.raster_root.resolve(); raster_root = output / "evidence/source_pages"; raster_root.mkdir(parents=True)
    geometry, render_rows = [], []
    for i, page in enumerate(pdf.pages, 1):
        src = raster_source / f"page-{i:03d}.png"; dst = raster_root / src.name; shutil.copy2(src, dst)
        geometry.append({"physical_page": i, "mediabox": [float(x) for x in page.mediabox], "cropbox": [float(x) for x in page.cropbox], "rotation": int(page.rotation or 0)})
        render_rows.append({"source_pdf_sha256": sha(source), "physical_page": i, "dpi": 96, "raster_ref": dst.relative_to(output).as_posix(), "raster_sha256": sha(dst), "width_px": Image.open(dst).width, "height_px": Image.open(dst).height})
    geometry_hash = write_json(output / "evidence/pdf_page_geometry.json", {"schema_version": "pdf-page-geometry/1.0", "source_pdf_sha256": sha(source), "pages": geometry})
    render_hash = write_jsonl(output / "ledgers/source_page_render_ledger.jsonl", render_rows)
    tree, mineru = read_json(popo_root / "document_tree.json"), read_json(mineru_root / "content_list.json")
    ranks, contexts = flatten_tree(tree)
    mineru_by_page: dict[int, list[tuple[int, dict[str, Any]]]] = defaultdict(list)
    for i, x in enumerate(mineru): mineru_by_page[int(x["page_idx"])].append((i, x))
    raw_by_page: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for x in raw: raw_by_page[int(x["page"])].append(x)
    ordered_by_page, page_events = {}, {}
    normalized_page_strategies: list[dict[str, Any]] = []
    for page in range(1, page_count + 1):
        candidates = [
            x for x in raw_by_page[page]
            if scope_row(config, page)["status"] == "included"
            and x["type"] not in RUNNING_TYPES
            and scope_overrides.get(x["source_id"], {}).get("status") != "excluded"
        ]
        base_order, page_events[page] = order_page(candidates, ranks, page)
        strategy = page_strategies.get(page)
        if strategy:
            before_ids = [row["source_id"] for row in base_order]
            if strategy["strategy_type"] == SPATIAL_SWEEP_STRATEGY:
                strategy_order, row_quantum = single_column_spatial_sweep(base_order, ranks)
            else:
                by_source_id = {row["source_id"]: row for row in base_order}
                explicit_ids = strategy["ordered_source_ids"]
                if set(explicit_ids) != set(by_source_id) or len(explicit_ids) != len(base_order):
                    raise ValueError(f"{strategy['strategy_id']} explicit source order is not an exact page partition")
                strategy_order = [by_source_id[source_id] for source_id in explicit_ids]
                row_quantum = None
            after_ids = [row["source_id"] for row in strategy_order]
            before_position = {source_id: index for index, source_id in enumerate(before_ids)}
            changed = [source_id for index, source_id in enumerate(after_ids) if before_position[source_id] != index]
            normalized_page_strategies.append({
                "strategy_id": strategy["strategy_id"],
                "strategy_type": strategy["strategy_type"],
                "physical_page": page,
                "review_status": "closed",
                "adaptive_row_quantum": row_quantum,
                "before_order": [canonical_block_id(row) for row in base_order],
                "after_order": [canonical_block_id(row) for row in strategy_order],
                "changed_block_ids": [canonical_block_id(next(row for row in strategy_order if row["source_id"] == source_id)) for source_id in changed],
                "rationale": strategy["rationale"],
                "evidence_refs": list(dict.fromkeys([
                    *strategy["evidence_refs"],
                    f"evidence/source_pages/page-{page:03d}.png",
                    f"evidence/order_overlays/page-{page:03d}.png",
                ])),
            })
            if changed:
                page_events[page].append({
                    "event_id": f"ORDER-STRATEGY-P{page:03d}",
                    "physical_page": page,
                    "trigger_kind": "reviewed_page_flow_strategy",
                    "trigger_code": "SINGLE_COLUMN_SPATIAL_SWEEP" if strategy["strategy_type"] == SPATIAL_SWEEP_STRATEGY else "EXPLICIT_SOURCE_ORDER",
                    "action_kind": "reanchor_reading_order",
                    "signal_only": False,
                    "requires_human_review": True,
                    "review_status": "closed",
                    "strategy_id": strategy["strategy_id"],
                    "affected_source_refs": normalized_page_strategies[-1]["changed_block_ids"],
                    "before_order": normalized_page_strategies[-1]["before_order"],
                    "after_order": normalized_page_strategies[-1]["after_order"],
                    "evidence_refs": [
                        f"evidence/source_pages/page-{page:03d}.png",
                        f"evidence/order_overlays/page-{page:03d}.png",
                    ],
                })
            ordered_by_page[page] = strategy_order
        else:
            ordered_by_page[page] = base_order
    page_strategy_contract = {
        "schema_version": "page-reading-order-strategy/1.0",
        "supported_strategy_types": [SPATIAL_SWEEP_STRATEGY, EXPLICIT_SOURCE_ORDER_STRATEGY],
        "spec_status": "passed",
        "configured_strategy_ids": list(dict.fromkeys(item["strategy_id"] for item in normalized_page_strategies)),
        "pages": normalized_page_strategies,
        "summary": {
            "configured_ranges": len(config.get("page_reading_order_strategies") or []),
            "covered_pages": len(normalized_page_strategies),
            "changed_pages": sum(bool(item["changed_block_ids"]) for item in normalized_page_strategies),
        },
    }
    page_strategy_contract_hash = write_json(output / "contracts/page_reading_order_strategies.json", page_strategy_contract)
    composite_relationships, composite_events = normalize_composite_relationships(config, raw, ordered_by_page)
    for page in range(1, page_count + 1):
        page_events[page].extend(event for event in composite_events if int(event["physical_page"]) == page)
        if ordered_by_page[page]:
            overlay(raster_root / f"page-{page:03d}.png", ordered_by_page[page], output / f"evidence/order_overlays/page-{page:03d}.png")
    unresolved_composite_events = [event for event in composite_events if event.get("review_status") != "closed"]
    composite_contract = {
        "schema_version": "composite-reading-relationship/1.0",
        "relationship_type": COMPOSITE_RELATION,
        "spec_status": "needs_review" if unresolved_composite_events else "passed",
        "relationships": composite_relationships,
        "unresolved_candidates": unresolved_composite_events,
        "summary": {
            "closed_relationships": len(composite_relationships),
            "unresolved_candidates": len(unresolved_composite_events),
            "affected_pages": sorted({item["physical_page"] for item in composite_relationships}),
        },
    }
    composite_contract_hash = write_json(output / "contracts/composite_reading_relationships.json", composite_contract)
    risk_events = [event for page in range(1, page_count + 1) for event in page_events[page]]
    risk_pages = [p for p in range(1, page_count + 1) if page_events[p]]
    audit = {"schema_version": "source-order-audit/2.1", "source_blocks": len(raw), "tree_refs": len(ranks), "tree_omissions": len([x for x in raw if x["id"] not in ranks]), "risk_pages": risk_pages, "risk_events": risk_events, "page_reading_strategy_contract_ref": "contracts/page_reading_order_strategies.json", "page_reading_strategy_contract_sha256": page_strategy_contract_hash, "composite_relationship_contract_ref": "contracts/composite_reading_relationships.json", "composite_relationship_contract_sha256": composite_contract_hash, "pages": [{"physical_page": p, "risk_event_ids": [event["event_id"] for event in page_events[p]], "ordered_block_ids": [canonical_block_id(x) for x in ordered_by_page[p]]} for p in range(1, page_count + 1)]}
    audit_hash = write_json(output / "qa/automated_scope_order_audit.json", audit)
    review_closed = args.review_status == "closed" and not unresolved_composite_events
    visual_evidence_ref, visual_evidence_hash = copy_visual_evidence(args.visual_evidence.resolve(), output)
    boundary_pages = sorted({page for item in config["scope_ranges"] for page in (item["start_page"], item["end_page"])})
    included_ranges = [f"{item['start_page']}-{item['end_page']}" for item in config["scope_ranges"] if item["status"] == "included"]
    review = {"schema_version": "source-review-closure/1.4", "status": "closed" if review_closed else "open", "reviewer": "Codex visual reviewer" if review_closed else None, "authorization": args.review_authorization, "reviewed_pages": list(range(1, page_count + 1)), "risk_pages": risk_pages, "closed_risk_event_ids": [event["event_id"] for event in risk_events] if review_closed else [], "boundary_pages": boundary_pages, "atomic_scope_override_count": len(scope_overrides), "closed_page_reading_strategy_ids": sorted(set(item["strategy_id"] for item in normalized_page_strategies)) if review_closed else [], "closed_composite_relationship_ids": [item["relationship_id"] for item in composite_relationships] if review_closed else [], "unresolved_composite_candidate_ids": [item["candidate_id"] for item in unresolved_composite_events], "evidence_refs": [visual_evidence_ref, "qa/automated_scope_order_audit.json", "contracts/page_reading_order_strategies.json", "contracts/composite_reading_relationships.json"], "finding": f"Configured body range(s) {', '.join(included_ranges)}, {len(scope_overrides)} explicit atomic exclusions, and page-local candidate order are source-coherent; {len(risk_events)} actionable order corrections including {len(normalized_page_strategies)} reviewed spatial-flow pages and {len(composite_relationships)} closed composite relationships are closed against source-page overlays." if review_closed else None}
    review_hash = write_json(output / "qa/source_review_closure.json", review)

    # D2 -> L.
    status = "closed" if review_closed else "open"
    decisions = [
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-SCOPE-001", "rule_id": "SC-R01/SC-R02", "status": status, "decision": f"Use the configured page-level source-scope decisions and {len(scope_overrides)} evidence-bound atomic exclusions embedded within included pages.", "evidence_refs": ["qa/source_review_closure.json", visual_evidence_ref], "recorded_at": stamp},
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-ORDER-001", "rule_id": "RO-R01/RO-R03/RO-R06/RO-H08", "status": status, "decision": f"Use Popo tree order by default, insert {audit['tree_omissions']} omitted visible blocks, apply {len(normalized_page_strategies)} reviewed page-level spatial-flow decisions, and apply {len(composite_relationships)} evidence-bound stem-media-options relationships.", "evidence_refs": ["qa/automated_scope_order_audit.json", "qa/source_review_closure.json", "contracts/page_reading_order_strategies.json", "contracts/composite_reading_relationships.json"], "recorded_at": stamp},
        {"schema_version": "decision-event/1.0", "decision_id": f"{decision_prefix}-REP-001", "rule_id": "CV-R02", "status": status, "decision": "Bind canonical content to the source PDF visual region; extracted values remain candidate transcriptions.", "evidence_refs": ["evidence/pdf_page_geometry.json", "qa/source_review_closure.json"], "recorded_at": stamp},
    ]
    decisions_hash = write_jsonl(output / "decisions/scope_order_decisions.jsonl", decisions)
    indexed_decisions = list(d1["decisions"]) + [{"decision_id": x["decision_id"], "status": x["status"], "rule_id": x["rule_id"], "event_file": "decisions/scope_order_decisions.jsonl"} for x in decisions]
    d2 = {"schema_version": "canonical-decision-index/1.1", "decision_index_id": d1["decision_index_id"], "snapshot_id": f"{config['sample_id']}-source-decisions-v2", "version": 2, "parent_index_ref": "decisions/input_decision_index.json", "parent_index_hash": d1_hash, "acyclic_commit_rule": "evidence_E_then_parent_decision_index_D1_then_cumulative_decision_index_D2_then_child_ledger_L", "spec_status": "passed" if review_closed else "needs_review", "evidence_committed_before_index": [{"ref": "qa/automated_scope_order_audit.json", "sha256": audit_hash}, {"ref": "qa/source_review_closure.json", "sha256": review_hash}, {"ref": "contracts/page_reading_order_strategies.json", "sha256": page_strategy_contract_hash}, {"ref": "contracts/composite_reading_relationships.json", "sha256": composite_contract_hash}, {"ref": visual_evidence_ref, "sha256": visual_evidence_hash}, {"ref": "ledgers/source_page_render_ledger.jsonl", "sha256": render_hash}], "decision_event_files": [{"path": "decisions/input_decisions.jsonl", "sha256": input_events_hash}, {"path": "decisions/scope_order_decisions.jsonl", "sha256": decisions_hash}], "decisions": indexed_decisions, "summary": {"total": len(indexed_decisions), "closed": len(indexed_decisions) if review_closed else len(d1["decisions"]), "open": 0 if review_closed else len(decisions), "stale": 0, "invalidated": 0}, "generated_at": stamp}
    d2_hash = write_json(output / "decisions/canonical_decision_index.json", d2)
    scope_pages = [{"physical_page": p, "upstream_page_idx": p - 1, **{k: scope_row(config, p)[k] for k in ("status", "page_category", "reason")}, "decision_refs": [f"{decision_prefix}-SCOPE-001"], "review_status": "closed" if review_closed else "open"} for p in range(1, page_count + 1)]
    atomic_scope_rows = [{"override_id": item.get("override_id", item["override_group"]), "source_id": source_id, "status": item["status"], "page_category": item["page_category"], "reason": item["reason"], "evidence_refs": item["evidence_refs"], "decision_refs": [f"{decision_prefix}-SCOPE-001"], "review_status": "closed" if review_closed else "open"} for source_id, item in sorted(scope_overrides.items())]
    scope_hash = write_json(output / "ledgers/source_scope_ledger.json", {"schema_version": "source-scope-ledger/1.1", "spec_status": "passed" if review_closed else "needs_review", "pages": scope_pages, "atomic_overrides": atomic_scope_rows, "summary": {"physical_pages": page_count, "atomic_exclusions": len(atomic_scope_rows)}})
    atoms, reading_pages, final_order = [], [], 0
    included_source_ids: set[str] = set()
    for page in range(1, page_count + 1):
        local_ids = []
        for local_order, row in enumerate(ordered_by_page[page], 1):
            included_source_ids.add(row["source_id"])
            final_order += 1; block_id = canonical_block_id(row); local_ids.append(block_id)
            relationship_refs = [item["relationship_id"] for item in composite_relationships if block_id in {member for role in item["roles"].values() for member in role}]
            strategy_refs = sorted({item["strategy_id"] for item in normalized_page_strategies if item["physical_page"] == page and block_id in item["after_order"]})
            atoms.append({"record_type": "source_block", "block_id": block_id, "upstream_block_ref": {"popo_source_id": row["source_id"], "popo_raw_id": row["id"], "popo_run_id": popo_manifest["run_id"], "mineru_match": nearest_mineru(row, mineru_by_page)}, "source_system": "minerupopo", "source_label": row.get("source_label"), "source_type": row["type"], "pdf_physical_page": page, "upstream_page_idx": page - 1, "bbox": row["bbox"], "bbox_basis": "PDF CropBox normalized 0..1, origin top-left", "raw_content": row.get("content", ""), "raw_content_sha256": raw_hash(row.get("content", "")), "asset_ref": nearest_mineru(row, mineru_by_page).get("asset_ref") if nearest_mineru(row, mineru_by_page) else None, "scope_status": "included", "scope_reason": "BODY_ATOMIC_SOURCE_SPAN", "candidate_final_order": final_order, "page_local_order": local_order, "popo_tree_rank": ranks.get(row["id"]), "tree_context": contexts.get(row["id"]), "order_evidence": ["PDF physical page order", "Popo document_tree", "source bbox", "closed visual review", *(["closed page reading strategy"] if strategy_refs else []), *(["closed composite reading relationship"] if relationship_refs else [])], "reading_strategy_refs": strategy_refs, "reading_relationship_refs": relationship_refs, "human_decision_refs": [f"{decision_prefix}-SCOPE-001", f"{decision_prefix}-ORDER-001", f"{decision_prefix}-REP-001"], "source_representation": {"authority": "pdf_visual_region", "physical_page": page, "bbox": row["bbox"], "bbox_coordinate_space": "pdf_cropbox_normalized_0_1_top_left", "geometry_evidence_ref": "evidence/pdf_page_geometry.json", "extracted_value_status": "candidate_not_authoritative"}, "terminal_state": "source_reconciled" if review_closed else "needs_review", "review_required": not review_closed})
        reading_pages.append({"physical_page": page, "scope_status": scope_row(config, page)["status"], "ordered_block_ids": local_ids, "risk_event_ids": [event["event_id"] for event in page_events[page]], "review_status": "closed" if review_closed else "open"})
    for row in raw:
        if row["source_id"] in included_source_ids:
            continue
        page = int(row["page"])
        page_scope = scope_row(config, page)
        override = scope_overrides.get(row["source_id"])
        reason = override["reason"] if override else (page_scope["reason"] if page_scope["status"] == "excluded" else "Repeated running header, footer, or printed page number excluded from logical body flow.")
        block_id = canonical_block_id(row)
        atoms.append({"record_type": "source_block", "block_id": block_id, "upstream_block_ref": {"popo_source_id": row["source_id"], "popo_raw_id": row["id"], "popo_run_id": popo_manifest["run_id"], "mineru_match": nearest_mineru(row, mineru_by_page)}, "source_system": "minerupopo", "source_label": row.get("source_label"), "source_type": row["type"], "pdf_physical_page": page, "upstream_page_idx": page - 1, "bbox": row["bbox"], "bbox_basis": "PDF CropBox normalized 0..1, origin top-left", "raw_content": row.get("content", ""), "raw_content_sha256": raw_hash(row.get("content", "")), "asset_ref": nearest_mineru(row, mineru_by_page).get("asset_ref") if nearest_mineru(row, mineru_by_page) else None, "scope_status": "excluded", "scope_reason": reason, "candidate_final_order": None, "page_local_order": None, "popo_tree_rank": ranks.get(row["id"]), "tree_context": contexts.get(row["id"]), "order_evidence": [], "human_decision_refs": [f"{decision_prefix}-SCOPE-001"], "source_representation": {"authority": "pdf_visual_region", "physical_page": page, "bbox": row["bbox"], "bbox_coordinate_space": "pdf_cropbox_normalized_0_1_top_left", "geometry_evidence_ref": "evidence/pdf_page_geometry.json", "extracted_value_status": "candidate_not_authoritative"}, "terminal_state": "scope_excluded", "review_required": not review_closed})
    atoms.sort(key=lambda x: (x["pdf_physical_page"], x["candidate_final_order"] is None, x["candidate_final_order"] or 10**9, x["upstream_block_ref"]["popo_raw_id"]))
    reading_hash = write_json(output / "ledgers/reading_order_ledger.json", {"schema_version": "reading-order-ledger/1.2", "spec_status": "passed" if review_closed else "needs_review", "page_reading_strategy_contract_ref": "contracts/page_reading_order_strategies.json", "page_reading_strategy_contract_sha256": page_strategy_contract_hash, "composite_relationship_contract_ref": "contracts/composite_reading_relationships.json", "composite_relationship_contract_sha256": composite_contract_hash, "pages": reading_pages})
    included_count = len(included_source_ids)
    header = {"record_type": "ledger_header", "schema_version": "canonical-block-ledger/2.0", "ledger_id": f"{config['sample_id']}-canonical-ledger", "ledger_snapshot_id": args.run_id, "ledger_version": 1, "parent_ledger_hash": None, "ledger_checkpoint": "source_reconciled", "spec_status": "passed" if review_closed else "needs_review", "run_mode": "formal" if review_closed else "formal_candidate", "material_identity": {"material_id": config["material_id"], "source_pdf_sha256": sha(source), "page_count": page_count}, "input_contract_ref": "contracts/input_contract.json", "input_contract_hash": input_contract_hash, "source_scope_ledger_ref": "ledgers/source_scope_ledger.json", "source_scope_ledger_hash": scope_hash, "reading_order_ledger_ref": "ledgers/reading_order_ledger.json", "reading_order_ledger_hash": reading_hash, "canonical_decision_index_ref": "decisions/canonical_decision_index.json", "canonical_decision_index_hash": d2_hash, "source_page_render_ledger_ref": "ledgers/source_page_render_ledger.jsonl", "source_page_render_ledger_hash": render_hash, "summary": {"source_records": len(raw), "included_atoms": included_count, "excluded_source_records": len(raw) - included_count, "open_reviews": 0 if review_closed else 3}, "generated_by": VERSION, "generated_at": stamp}
    header["current_ledger_hash"] = chash(atoms)
    header["current_ledger_hash_scope"] = "canonical JSON hash of ordered source_block records"
    ledger_hash = write_jsonl(output / "ledgers/canonical_block_ledger.jsonl", [header, *atoms])
    manifest = {"schema_version": "source-reconciled-stage-manifest/1.2", "run_id": args.run_id, "producer": VERSION, "spec_status": header["spec_status"], "ledger_checkpoint": "source_reconciled", "commit_order": ["E1", "D1", "Spec01", "E2", "D2", "L", "M"], "artifacts": {"input_contract": {"path": "contracts/input_contract.json", "sha256": input_contract_hash}, "decision_index": {"path": "decisions/canonical_decision_index.json", "sha256": d2_hash}, "scope_ledger": {"path": "ledgers/source_scope_ledger.json", "sha256": scope_hash}, "reading_order_ledger": {"path": "ledgers/reading_order_ledger.json", "sha256": reading_hash}, "page_reading_order_strategies": {"path": "contracts/page_reading_order_strategies.json", "sha256": page_strategy_contract_hash}, "composite_reading_relationships": {"path": "contracts/composite_reading_relationships.json", "sha256": composite_contract_hash}, "canonical_ledger": {"path": "ledgers/canonical_block_ledger.jsonl", "sha256": ledger_hash}}, "open_reviews": 0 if review_closed else 3 + len(unresolved_composite_events), "generated_at": stamp}
    manifest_hash = write_json(output / "manifests/source_reconciled_commit.json", manifest)
    return {"spec_status": header["spec_status"], "page_count": page_count, "source_records": len(raw), "included_atoms": included_count, "excluded_atoms": len(raw) - included_count, "tree_omissions": audit["tree_omissions"], "risk_pages": len(risk_pages), "page_reading_strategy_pages": len(normalized_page_strategies), "closed_composite_relationships": len(composite_relationships), "unresolved_composite_candidates": len(unresolved_composite_events), "manifest_sha256": manifest_hash, "output": str(output)}


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--repo-root", type=Path, required=True); p.add_argument("--intake-run", type=Path, required=True)
    p.add_argument("--config", type=Path, required=True); p.add_argument("--raster-root", type=Path, required=True)
    p.add_argument("--visual-evidence", type=Path, required=True); p.add_argument("--output", type=Path, required=True)
    p.add_argument("--run-id", required=True); p.add_argument("--review-status", choices=["pending", "closed"], default="pending")
    p.add_argument("--review-authorization", default="User authorized Codex to close source scope and reading-order evidence for this sample.")
    p.add_argument("--require-page-count", action="store_true")
    args = p.parse_args(); result = build(args); print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)); return 0 if result["spec_status"] == "passed" else 3


if __name__ == "__main__":
    raise SystemExit(main())
