#!/usr/bin/env python3
"""Audit the formal-v1 release code surface for sample-specific product logic."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable


HEX64 = re.compile(r"(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])", re.IGNORECASE)
MATERIAL_ID = re.compile(r"pdf-[0-9a-f]{12,}", re.IGNORECASE)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def iter_files(workspace: Path, config: dict[str, Any]) -> Iterable[Path]:
    seen = set()
    for raw in config.get("workspace_files", []):
        path = (workspace / raw).resolve()
        if path not in seen:
            seen.add(path)
            yield path
    for raw in config.get("shared_skill_script_roots", []):
        root = Path(raw).resolve()
        for path in sorted(root.rglob("*.py")):
            if "__pycache__" not in path.parts and path not in seen:
                seen.add(path)
                yield path
    for raw in config.get("shared_skill_files", []):
        path = Path(raw).resolve()
        if path not in seen:
            seen.add(path)
            yield path


def names(node: ast.AST) -> set[str]:
    values = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            values.add(child.id.lower())
        elif isinstance(child, ast.Attribute):
            values.add(child.attr.lower())
    return values


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--surface", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    config = json.loads(args.surface.read_text(encoding="utf-8"))
    forbidden = [item.casefold() for item in config.get("forbidden_sample_literals", [])]
    forbidden_hashes = {item.lower() for item in config.get("forbidden_sample_hashes", [])}
    violations = []
    page_candidates = []
    files = []

    for path in iter_files(workspace, config):
        if not path.is_file():
            violations.append({"kind": "missing_release_code", "path": str(path)})
            continue
        text = path.read_text(encoding="utf-8")
        try:
            relative = str(path.relative_to(workspace))
        except ValueError:
            relative = str(path)
        files.append({"path": relative, "sha256": sha256(path), "bytes": path.stat().st_size})
        folded = text.casefold()
        for literal in forbidden:
            if literal and literal in folded:
                violations.append({"kind": "sample_literal", "path": relative, "literal": literal})
        for match in MATERIAL_ID.findall(text):
            violations.append({"kind": "material_id_literal", "path": relative, "literal": match})
        for match in HEX64.findall(text):
            if match.lower() in forbidden_hashes:
                violations.append({"kind": "sample_hash_literal", "path": relative, "literal": match.lower()})
        try:
            tree = ast.parse(text, filename=str(path))
        except SyntaxError as exc:
            violations.append({"kind": "syntax_error", "path": relative, "detail": str(exc)})
            continue
        absolute_user_prefixes = ("/" + "Users/", "/" + "home/")
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.startswith(absolute_user_prefixes):
                violations.append({"kind": "absolute_user_path_literal", "path": relative, "line": node.lineno, "literal": node.value})
        for node in ast.walk(tree):
            if not isinstance(node, ast.Compare):
                continue
            involved = names(node)
            if not any("page" in name for name in involved):
                continue
            constants = [child.value for child in ast.walk(node) if isinstance(child, ast.Constant) and isinstance(child.value, int) and not isinstance(child.value, bool)]
            if constants:
                page_candidates.append({"path": relative, "line": node.lineno, "names": sorted(involved), "constants": constants, "source": ast.get_source_segment(text, node)})

    suspicious_page_constants = [
        item for item in page_candidates
        if any(abs(value) > 1 for value in item["constants"])
    ]
    for item in suspicious_page_constants:
        violations.append({"kind": "fixed_page_constant", **item})

    duplicate_violations = []
    seen = set()
    for item in violations:
        key = json.dumps(item, sort_keys=True)
        if key not in seen:
            seen.add(key)
            duplicate_violations.append(item)
    violations = duplicate_violations

    report = {
        "schema_version": "generic-hardcoding-audit/1.0",
        "status": "passed" if not violations else "failed",
        "surface": {"path": str(args.surface.resolve()), "sha256": sha256(args.surface)},
        "summary": {
            "files_scanned": len(files),
            "violations": len(violations),
            "page_constant_review_candidates": len(page_candidates),
        },
        "violations": violations,
        "page_constant_review": {
            "status": "passed_generic_sentinels_only" if page_candidates and not suspicious_page_constants else ("failed" if suspicious_page_constants else "not_applicable"),
            "policy": config.get("page_constant_review_policy"),
            "suspicious": suspicious_page_constants,
            "candidates": page_candidates,
        },
        "files": files,
        "claim_boundary": "The audit covers only the declared formal-v1 release code surface. Historical sample-closure scripts and data configs are intentionally outside production logic.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not violations else 1


if __name__ == "__main__":
    raise SystemExit(main())
