#!/usr/bin/env python3
"""Independently validate a finalized failed Spec 06 review run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def readl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--review-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    run = sample / "runs" / args.review_run
    compile_run = sample / "runs" / args.compile_run
    output = args.output.resolve()
    page_review = read(run / "reports/page_review.json")
    page_ledger = readl(run / "reports/final_page_hash_ledger.jsonl")
    queue = read(run / "qa/human_review_queue.json")
    acceptance = read(run / "final_acceptance.json")
    index = read(run / "decisions/canonical_decision_index.json")
    decisions = readl(run / "decisions/final_decisions.jsonl")
    toc_audit = read(run / "reports/toc_page_number_audit.json")
    source_page_coverage = read(run / "reports/source_page_coverage.json")
    source_block_coverage = read(run / "reports/source_block_coverage.json")
    media_audit = read(run / "reports/formula_table_image_audit.json")
    manifest = read(run / "manifests/failure_return_manifest.json")
    render_manifest = read(compile_run / "final_render_pack/manifest.json")
    build_manifest = read(compile_run / "manifests/build_manifest.json")
    final_pdf = compile_run / build_manifest["artifacts"]["final_pdf"]["path"]
    final_zip = compile_run / build_manifest["artifacts"]["formal_zip"]["path"]

    checks: dict[str, bool] = {}
    checks["failed_not_ready"] = page_review["spec_status"] == "failed" and page_review["acceptance_status"] == "not_ready"
    expected_pages = render_manifest["page_count"]
    checks["page_counts_match"] = len(page_review["pages"]) == len(page_ledger) == len(render_manifest["pages"]) == expected_pages
    checks["page_indices_contiguous"] = [row["physical_page"] for row in page_ledger] == list(range(1, expected_pages + 1))
    checks["page_review_and_ledger_identical"] = page_review["pages"] == page_ledger
    checks["all_page_raster_hashes_verified"] = all(row["raster_hash_verified"] for row in page_ledger)
    checks["all_pages_human_closed"] = bool(page_review.get("all_pages_human_reviewed")) and all(row.get("human_review_status") == "closed" for row in page_ledger)
    checks["review_queue_closed"] = queue["open_count"] == 0 and queue["closed_count"] == len(queue["items"])
    failed_gates = [row["gate"] for row in page_review["hard_gate_matrix"] if row["status"] == "failed"]
    checks["confirmed_v1_blocks_passing"] = bool(failed_gates) and "FR-H17" in failed_gates
    checks["no_acceptance_artifacts_claimed"] = not acceptance["final_verified_ledger_created"] and not acceptance["acceptance_commit_created"] and not acceptance["human_accepted"]
    checks["no_final_verified_ledger_present"] = not any("final_verified" in path.name for path in run.rglob("*ledger*"))
    checks["decision_events_closed"] = bool(decisions) and all(row["status"] == "closed" for row in decisions)
    checks["decision_index_closed"] = index["spec_status"] == "failed" and index["summary"]["open"] == 0 and all(any(item["decision_id"] == row["decision_id"] for item in index["decisions"]) for row in decisions)
    checks["decision_event_hash_bound"] = any(item["path"] == "decisions/final_decisions.jsonl" and item["sha256"] == sha(run / item["path"]) for item in index["decision_event_files"])
    checks["pdf_hash_bound"] = sha(final_pdf) == page_review["final_pdf_sha256"] == acceptance["final_pdf_sha256"] == manifest["final_pdf_sha256"]
    checks["zip_hash_bound"] = sha(final_zip) == acceptance["final_zip_sha256"] == manifest["final_zip_sha256"]
    checks["confirmed_defect_family_present"] = page_review["confirmed_v1_defect_families"] > 0 and bool(page_review["confirmed_defects"])
    defect_types = {item["type"] for item in page_review["confirmed_defects"]}
    if "missing_toc_entries" in defect_types:
        checks["confirmed_failure_audit_matches_type"] = (
            toc_audit["spec_status"] == "failed"
            and toc_audit["needs_review"] == 0
            and toc_audit.get("failed", 0) == len(toc_audit.get("confirmed_missing_entries", [])) > 0
            and all(item["status"] == "failed_confirmed_v1" for item in toc_audit["confirmed_missing_entries"])
        )
    else:
        affected_final_pages = {
            page
            for defect in page_review["confirmed_defects"]
            if defect["type"] in {
                "source_visual_region_missing",
                "media_crop_contamination",
                "composite_media_reading_order_violation",
            }
            for page in defect["final_pdf_pages"]
        }
        ledger_by_page = {row["physical_page"]: row for row in page_ledger}
        checks["confirmed_failure_audit_matches_type"] = (
            bool(affected_final_pages)
            and source_page_coverage["spec_status"] == "failed"
            and source_block_coverage["spec_status"] == "failed"
            and source_block_coverage.get("source_ledger_completeness_invalidated_by_visual_review") is True
            and media_audit["spec_status"] == "failed"
            and all(
                ledger_by_page[page]["page_status"] == "failed_confirmed_blocker"
                and ledger_by_page[page]["confirmed_severity"] in {"V0", "V1"}
                for page in affected_final_pages
            )
        )
    checks["acceptance_binds_decision_index"] = acceptance["review_decision_index"]["snapshot_id"] == index["snapshot_id"] and acceptance["review_decision_index"]["sha256"] == sha(run / "decisions/canonical_decision_index.json")
    checks["manifest_files_valid"] = all(sha(run / item["path"]) == item["sha256"] and (run / item["path"]).stat().st_size == item["size"] for item in manifest["files"])

    result = {
        "schema_version": "spec06-failed-review-validation/1.1",
        "review_run": args.review_run,
        "spec_status": "passed" if all(checks.values()) else "failed",
        "validated_review_status": page_review["spec_status"],
        "validated_acceptance_status": page_review["acceptance_status"],
        "checks": checks,
        "summary": {
            "passed_checks": sum(checks.values()),
            "total_checks": len(checks),
            "final_pages": len(page_ledger),
            "open_human_reviews": queue["open_count"],
            "failed_hard_gates": failed_gates,
            "final_verified_ledger_created": acceptance["final_verified_ledger_created"],
            "acceptance_commit_created": acceptance["acceptance_commit_created"],
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
