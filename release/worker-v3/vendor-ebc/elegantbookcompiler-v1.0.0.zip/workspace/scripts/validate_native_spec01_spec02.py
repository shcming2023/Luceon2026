#!/usr/bin/env python3
"""Independently validate a frozen native Spec 01/02 source-reconciled run."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Callable


PRODUCER_CONTRACTS = {
    "native-spec01-spec02/1.0.0": {"materialized_rehash": False, "composite_relationships": False},
    "native-spec01-spec02/1.1.0": {"materialized_rehash": False, "composite_relationships": False},
    "native-spec01-spec02/1.2.0": {"materialized_rehash": True, "composite_relationships": False},
    "native-spec01-spec02/1.3.0": {"materialized_rehash": True, "composite_relationships": True},
    "native-spec01-spec02/1.3.1": {"materialized_rehash": True, "composite_relationships": True},
    "native-spec01-spec02/1.3.2": {"materialized_rehash": True, "composite_relationships": True, "page_reading_strategies": True},
}

KNOWN_SOURCE_RULE_IDS = {
    *(f"IN-H{index:02d}" for index in range(1, 18)),
    *(f"IN-R{index:02d}" for index in range(1, 6)),
    *(f"SC-H{index:02d}" for index in range(1, 10)),
    *(f"SC-R{index:02d}" for index in range(1, 4)),
    *(f"RO-H{index:02d}" for index in range(1, 9)),
    *(f"RO-R{index:02d}" for index in range(1, 7)),
    *(f"CV-H{index:02d}" for index in range(1, 19)),
    *(f"CV-R{index:02d}" for index in range(1, 8)),
}


def producer_contract(producer: Any) -> dict[str, bool]:
    if producer not in PRODUCER_CONTRACTS:
        raise ValueError(f"unsupported source producer contract: {producer!r}")
    return PRODUCER_CONTRACTS[producer]


def validate_rule_id_expression(expression: Any) -> list[str]:
    if not isinstance(expression, str) or not expression.strip():
        raise ValueError("decision rule_id is empty or not a string")
    tokens = expression.split("/")
    if any(not token or token != token.strip() for token in tokens):
        raise ValueError(f"decision rule_id expression is malformed: {expression!r}")
    unknown = sorted(set(tokens) - KNOWN_SOURCE_RULE_IDS)
    if unknown:
        raise ValueError(f"decision references unknown normative rule ids: {unknown}")
    return tokens


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[Any]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


class Checks:
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []

    def add(self, check_id: str, fn: Callable[[], Any]) -> None:
        try:
            self.items.append({"check_id": check_id, "status": "passed", "evidence": fn()})
        except Exception as exc:
            self.items.append({"check_id": check_id, "status": "failed", "detail": str(exc)})


def validate(args: argparse.Namespace) -> dict[str, Any]:
    run = args.run.resolve()
    intake = args.intake_run.resolve()
    config = read_json(args.config.resolve())
    materialized_contract = read_json(intake / "contracts/input_contract.json")
    source_relative = materialized_contract.get("source_pdf", {}).get("path")
    if not isinstance(source_relative, str) or not source_relative:
        raise ValueError("materialized input contract has no source_pdf.path")
    source = (intake / source_relative).resolve()
    source_root = (intake / "inputs/source").resolve()
    if source.parent != source_root or source.suffix.lower() != ".pdf" or not source.is_file():
        raise ValueError(f"unsafe or missing source PDF path in materialized contract: {source_relative}")
    popo_raw = read_json(intake / "inputs/popo/popo_raw.json")
    popo_source_ids = [row["source_id"] for row in popo_raw]
    manifest = read_json(run / "manifests/source_reconciled_commit.json")
    input_contract = read_json(run / "contracts/input_contract.json")
    input_report = read_json(run / "qa/input_validation_report.json")
    scope = read_json(run / "ledgers/source_scope_ledger.json")
    order = read_json(run / "ledgers/reading_order_ledger.json")
    decisions = read_json(run / "decisions/canonical_decision_index.json")
    input_decisions = read_json(run / "decisions/input_decision_index.json")
    review = read_json(run / "qa/source_review_closure.json")
    visual_review_manifest_path = run / "evidence/visual_review_manifest.json"
    visual_review_manifest = read_json(visual_review_manifest_path) if visual_review_manifest_path.is_file() else None
    audit = read_json(run / "qa/automated_scope_order_audit.json")
    geometry = read_json(run / "evidence/pdf_page_geometry.json")
    render_rows = read_jsonl(run / "ledgers/source_page_render_ledger.jsonl")
    ledger_path = run / "ledgers/canonical_block_ledger.jsonl"
    ledger_rows = read_jsonl(ledger_path)
    header, atoms = ledger_rows[0], ledger_rows[1:]
    producer = header.get("generated_by")
    contract = PRODUCER_CONTRACTS.get(producer, {})
    strict_v12_plus = bool(contract.get("materialized_rehash"))
    strict_composite = bool(contract.get("composite_relationships"))
    strict_page_strategies = bool(contract.get("page_reading_strategies"))
    composite_path = run / "contracts/composite_reading_relationships.json"
    composite = read_json(composite_path) if composite_path.is_file() else None
    page_strategy_path = run / "contracts/page_reading_order_strategies.json"
    page_strategy = read_json(page_strategy_path) if page_strategy_path.is_file() else None
    page_count = int(config["expected_page_count"])
    checks = Checks()

    def supported_producer_contract() -> dict[str, Any]:
        capabilities = producer_contract(producer)
        identities = {
            "ledger": producer,
            "manifest": manifest.get("producer"),
            "input_contract": input_contract.get("generated_by"),
        }
        if set(identities.values()) != {producer}:
            raise ValueError(f"producer identity differs across immutable artifacts: {identities}")
        return {"producer": producer, **capabilities}

    def formal_status() -> dict[str, Any]:
        values = {
            "manifest": manifest.get("spec_status"),
            "input": input_contract.get("spec_status"),
            "scope": scope.get("spec_status"),
            "order": order.get("spec_status"),
            "decisions": decisions.get("spec_status"),
            "ledger": header.get("spec_status"),
        }
        if set(values.values()) != {"passed"} or manifest.get("open_reviews") != 0 or header.get("ledger_checkpoint") != "source_reconciled":
            raise ValueError(f"formal source-reconciled status not closed: {values}")
        if review.get("status") != "closed" or review.get("reviewed_pages") != list(range(1, page_count + 1)):
            raise ValueError("full source review is not closed for every physical page")
        return values | {"reviewed_pages": page_count}

    def input_identity() -> dict[str, Any]:
        if input_contract["source_pdf"]["sha256"] != sha256_file(source):
            raise ValueError("source PDF hash mismatch")
        if input_contract["source_pdf"]["sha256"] != config["source_pdf"]["sha256"]:
            raise ValueError("source PDF differs from the approved configuration identity")
        copied_template = run / input_contract["template"]["path"]
        if input_contract["template"]["sha256"] != sha256_file(copied_template):
            raise ValueError("copied template hash mismatch")
        approved_template = config["template"].get("approved_sha256")
        if not approved_template or sha256_file(copied_template) != approved_template:
            raise ValueError("run is not bound to the sole approved fixed template hash")
        materialized_binding = input_contract.get("materialized_contract") or {}
        if strict_v12_plus:
            if input_contract["template"].get("approved_sha256") != approved_template or input_contract["template"].get("binding_status") != "exact_match":
                raise ValueError("v1.2 run lacks the explicit fixed-template binding fields")
            materialized = read_json(intake / "contracts/input_contract.json")
            if materialized.get("status") != "passed" or materialized_binding.get("sha256") != sha256_file(intake / "contracts/input_contract.json") or materialized_binding.get("object_failures") or materialized_binding.get("image_failures"):
                raise ValueError("formal input contract does not bind a fully rehashed materialization")
        gates = input_report.get("gates", [])
        if len(gates) != 17 or any(item.get("status") != "passed" for item in gates):
            raise ValueError("not all 17 Spec 01 hard gates passed")
        return {"source_pdf_sha256": sha256_file(source), "template_sha256": sha256_file(copied_template), "input_gates": len(gates), "materialized_entries_rehashed": materialized_binding.get("entries_rehashed")}

    def scope_partition() -> dict[str, Any]:
        pages = scope.get("pages", [])
        if [row.get("physical_page") for row in pages] != list(range(1, page_count + 1)):
            raise ValueError("scope ledger does not cover every physical page exactly once")
        expected = {}
        for page in range(1, page_count + 1):
            matches = [row for row in config["scope_ranges"] if row["start_page"] <= page <= row["end_page"]]
            if len(matches) != 1:
                raise ValueError(f"configuration does not partition page {page}")
            expected[page] = matches[0]["status"]
        if any(row["status"] != expected[row["physical_page"]] or row.get("review_status") != "closed" for row in pages):
            raise ValueError("scope ledger differs from the closed configured decisions")
        configured_overrides = {
            source_id: group
            for group in config.get("block_scope_overrides") or []
            for source_id in group.get("source_ids") or []
        }
        ledger_overrides = {row["source_id"]: row for row in scope.get("atomic_overrides") or []}
        if set(configured_overrides) != set(ledger_overrides):
            raise ValueError("scope ledger atomic overrides differ from configuration")
        for source_id, group in configured_overrides.items():
            row = ledger_overrides[source_id]
            if row.get("status") != group.get("status") or row.get("reason") != group.get("reason") or row.get("review_status") != "closed":
                raise ValueError(f"atomic scope override is not closed as configured: {source_id}")
        counts = Counter(row["status"] for row in pages)
        return {**dict(counts), "atomic_exclusions": len(ledger_overrides)}

    def rendered_source_pages() -> dict[str, Any]:
        if len(geometry.get("pages", [])) != page_count or len(render_rows) != page_count:
            raise ValueError("source geometry or page raster ledger is incomplete")
        if [row["physical_page"] for row in render_rows] != list(range(1, page_count + 1)):
            raise ValueError("source page raster ledger is not a unique ordered page partition")
        drifted = []
        for row in render_rows:
            path = run / row["raster_ref"]
            if not path.is_file() or sha256_file(path) != row["raster_sha256"]:
                drifted.append(row["physical_page"])
        if drifted:
            raise ValueError(f"source page rasters drifted: {drifted[:8]}")
        visual_files = (visual_review_manifest or {}).get("files") or []
        if strict_v12_plus and not visual_files:
            raise ValueError("visual review evidence manifest is empty")
        visual_drifted = []
        for item in visual_files:
            path = run / item["path"]
            if not path.is_file() or sha256_file(path) != item["sha256"]:
                visual_drifted.append(item["path"])
        if visual_drifted:
            raise ValueError(f"visual review evidence drifted: {visual_drifted[:8]}")
        return {"pages": page_count, "drifted": 0, "visual_evidence_files": len(visual_files)}

    def decision_dag() -> dict[str, Any]:
        if decisions.get("parent_index_ref") != "decisions/input_decision_index.json" or decisions.get("parent_index_hash") != sha256_file(run / "decisions/input_decision_index.json"):
            raise ValueError("D2 parent hash does not bind D1")
        validated_rule_tokens = 0
        for document in (input_decisions, decisions):
            if not document.get("acyclic_commit_rule"):
                raise ValueError("decision index lacks the acyclic commit rule")
            summary = document.get("summary", {})
            if summary.get("open") or summary.get("stale") or summary.get("invalidated"):
                raise ValueError("decision index contains unresolved decisions")
            for item in document.get("decisions", []):
                if not item.get("event_file") or not item.get("rule_id"):
                    raise ValueError("decision inventory lacks rule_id or event_file")
                validated_rule_tokens += len(validate_rule_id_expression(item["rule_id"]))
                event_path = run / item["event_file"]
                if not event_path.is_file():
                    raise ValueError(f"decision event file is missing: {item['event_file']}")
                event_by_id = {event["decision_id"]: event for event in read_jsonl(event_path)}
                event = event_by_id.get(item["decision_id"])
                if not event or event.get("rule_id") != item["rule_id"] or event.get("status") != item.get("status"):
                    raise ValueError(f"decision index/event mismatch: {item['decision_id']}")
        parent_by_id = {item["decision_id"]: item for item in input_decisions.get("decisions", [])}
        child_by_id = {item["decision_id"]: item for item in decisions.get("decisions", [])}
        missing = sorted(set(parent_by_id) - set(child_by_id))
        changed = sorted(decision_id for decision_id, item in parent_by_id.items() if child_by_id.get(decision_id) != item)
        if missing or changed:
            raise ValueError(f"D2 cumulative inheritance failed: missing={missing} changed={changed}")
        d2_text = (run / "decisions/canonical_decision_index.json").read_text(encoding="utf-8")
        if "canonical_block_ledger" in d2_text or header.get("current_ledger_hash") in d2_text:
            raise ValueError("D2 illegally references its descendant canonical ledger")
        return {"input_decisions": input_decisions["summary"], "source_decisions": decisions["summary"], "validated_rule_tokens": validated_rule_tokens}

    def reading_order_partition() -> dict[str, Any]:
        pages = order.get("pages", [])
        if [row.get("physical_page") for row in pages] != list(range(1, page_count + 1)):
            raise ValueError("reading-order ledger does not cover each source page exactly once")
        if any(row.get("review_status") != "closed" for row in pages):
            raise ValueError("reading-order review remains open")
        expected_audit_schema = "source-order-audit/2.1" if strict_page_strategies else "source-order-audit/2.0"
        if audit.get("schema_version") != expected_audit_schema:
            raise ValueError(f"source order audit is not the expected {expected_audit_schema} contract")
        events = audit.get("risk_events", [])
        event_ids = [event.get("event_id") for event in events]
        if None in event_ids or len(event_ids) != len(set(event_ids)):
            raise ValueError("risk event ids are missing or duplicated")
        if any(event.get("signal_only") is not False or event.get("requires_human_review") is not True or not event.get("affected_source_refs") or not event.get("evidence_refs") for event in events):
            raise ValueError("risk queue contains a broad signal or lacks actionable evidence")
        event_pages = sorted({int(event["physical_page"]) for event in events})
        if sorted(audit.get("risk_pages", [])) != event_pages or event_pages != sorted(review.get("risk_pages", [])):
            raise ValueError("review closure is not bound to the current risk-page set")
        if set(review.get("closed_risk_event_ids", [])) != set(event_ids):
            raise ValueError("review closure does not close the current risk-event inventory")
        missing_overlays = [page for page in audit.get("risk_pages", []) if not (run / f"evidence/order_overlays/page-{page:03d}.png").is_file()]
        if missing_overlays:
            raise ValueError(f"risk-page overlays missing: {missing_overlays}")
        ordered_ids = [block_id for page in pages for block_id in page.get("ordered_block_ids", [])]
        if len(ordered_ids) != len(set(ordered_ids)):
            raise ValueError("logical reading order contains duplicate blocks")
        strategy_evidence: dict[str, Any] = {"applicable": False}
        if strict_page_strategies:
            if not page_strategy or page_strategy.get("schema_version") != "page-reading-order-strategy/1.0" or page_strategy.get("spec_status") != "passed":
                raise ValueError("v1.3.2 run lacks a passed page reading strategy contract")
            if audit.get("page_reading_strategy_contract_ref") != "contracts/page_reading_order_strategies.json" or audit.get("page_reading_strategy_contract_sha256") != sha256_file(page_strategy_path):
                raise ValueError("source order audit does not bind the page reading strategy contract")
            if order.get("page_reading_strategy_contract_ref") != "contracts/page_reading_order_strategies.json" or order.get("page_reading_strategy_contract_sha256") != sha256_file(page_strategy_path):
                raise ValueError("reading-order ledger does not bind the page reading strategy contract")
            configured_by_page: dict[int, dict[str, Any]] = {}
            configured_ids: list[str] = []
            for strategy in config.get("page_reading_order_strategies") or []:
                configured_ids.append(strategy["strategy_id"])
                if strategy.get("strategy_type") not in {"single_column_spatial_sweep", "explicit_source_order"} or strategy.get("review_status") != "closed" or not strategy.get("evidence_refs") or not strategy.get("rationale"):
                    raise ValueError(f"configured page reading strategy is not evidence-closed: {strategy.get('strategy_id')}")
                for page in range(int(strategy["start_page"]), int(strategy["end_page"]) + 1):
                    if page in configured_by_page:
                        raise ValueError(f"page {page} is claimed by multiple configured reading strategies")
                    configured_by_page[page] = strategy
            frozen_pages = page_strategy.get("pages") or []
            if [int(item["physical_page"]) for item in frozen_pages] != sorted(configured_by_page):
                raise ValueError("frozen page reading strategy coverage differs from configuration")
            order_by_page = {int(item["physical_page"]): item["ordered_block_ids"] for item in pages}
            block_by_id = {atom["block_id"]: atom for atom in atoms}
            changed_pages: set[int] = set()
            for item in frozen_pages:
                page = int(item["physical_page"])
                configured = configured_by_page[page]
                if item.get("strategy_id") != configured["strategy_id"] or item.get("strategy_type") != configured["strategy_type"] or item.get("review_status") != "closed":
                    raise ValueError(f"frozen page reading strategy differs from configuration on page {page}")
                if item.get("after_order") != order_by_page[page] or len(item.get("after_order") or []) != len(set(item.get("after_order") or [])):
                    raise ValueError(f"frozen page strategy order differs from the reading ledger on page {page}")
                if configured["strategy_type"] == "explicit_source_order":
                    by_source_id = {atom["upstream_block_ref"]["popo_source_id"]: atom["block_id"] for atom in atoms if int(atom["pdf_physical_page"]) == page and atom.get("scope_status") == "included"}
                    configured_block_order = [by_source_id[source_id] for source_id in configured.get("ordered_source_ids") or [] if source_id in by_source_id]
                    if len(configured_block_order) != len(by_source_id) or configured_block_order != item.get("after_order"):
                        raise ValueError(f"explicit source order is not an exact included-atom partition on page {page}")
                if any(item["strategy_id"] not in block_by_id[block_id].get("reading_strategy_refs", []) for block_id in item["after_order"]):
                    raise ValueError(f"canonical atoms do not retain page strategy lineage on page {page}")
                if item.get("changed_block_ids"):
                    changed_pages.add(page)
            strategy_events = [event for event in events if event.get("trigger_code") in {"SINGLE_COLUMN_SPATIAL_SWEEP", "EXPLICIT_SOURCE_ORDER"}]
            if {int(event["physical_page"]) for event in strategy_events} != changed_pages or any(event.get("review_status") != "closed" for event in strategy_events):
                raise ValueError("spatial-flow risk events do not exactly cover changed strategy pages")
            if set(review.get("closed_page_reading_strategy_ids", [])) != set(configured_ids):
                raise ValueError("source review closure does not close the configured page reading strategies")
            strategy_evidence = {"applicable": bool(configured_by_page), "configured_ranges": len(configured_ids), "covered_pages": len(frozen_pages), "changed_pages": len(changed_pages)}
        return {"logical_blocks": len(ordered_ids), "risk_pages": audit.get("risk_pages", []), "risk_events": len(events), "tree_omissions": audit.get("tree_omissions"), "page_reading_strategies": strategy_evidence}

    def composite_relationship_gate() -> dict[str, Any]:
        if not strict_composite:
            return {"applicable": False, "producer": producer}
        if not composite or composite.get("schema_version") != "composite-reading-relationship/1.0":
            raise ValueError("v1.3 run lacks the composite reading relationship contract")
        if composite.get("spec_status") != "passed" or composite.get("unresolved_candidates"):
            raise ValueError("composite reading relationship candidates remain unresolved")
        if audit.get("composite_relationship_contract_ref") != "contracts/composite_reading_relationships.json" or audit.get("composite_relationship_contract_sha256") != sha256_file(composite_path):
            raise ValueError("source order audit does not bind the composite relationship contract")
        if order.get("composite_relationship_contract_ref") != "contracts/composite_reading_relationships.json" or order.get("composite_relationship_contract_sha256") != sha256_file(composite_path):
            raise ValueError("reading-order ledger does not bind the composite relationship contract")

        configured = config.get("composite_reading_relationships") or []
        relations = composite.get("relationships") or []
        if [item.get("relationship_id") for item in relations] != [item.get("relationship_id") for item in configured]:
            raise ValueError("frozen composite relationships differ from the reviewed configuration")
        block_by_id = {row["block_id"]: row for row in atoms}
        page_order = {int(page["physical_page"]): page.get("ordered_block_ids", []) for page in order.get("pages", [])}
        claimed: set[str] = set()
        for relation in relations:
            if relation.get("relationship_type") != "stem_media_options" or relation.get("review_status") != "closed":
                raise ValueError(f"relationship is not closed or uses the wrong type: {relation.get('relationship_id')}")
            roles = relation.get("roles") or {}
            if set(roles) != {"stem", "media", "options"} or any(not roles.get(role) for role in ("stem", "media", "options")):
                raise ValueError(f"relationship roles are incomplete: {relation.get('relationship_id')}")
            flattened = [block_id for role in ("stem", "media", "options") for block_id in roles[role]]
            if len(flattened) != len(set(flattened)) or claimed.intersection(flattened):
                raise ValueError(f"relationship members are duplicated or overlap: {relation.get('relationship_id')}")
            claimed.update(flattened)
            if any(block_id not in block_by_id or block_by_id[block_id].get("scope_status") != "included" for block_id in flattened):
                raise ValueError(f"relationship contains a missing or excluded atom: {relation.get('relationship_id')}")
            physical_page = int(relation["physical_page"])
            positions = [page_order[physical_page].index(block_id) for block_id in flattened]
            if positions != list(range(min(positions), min(positions) + len(flattened))):
                raise ValueError(f"relationship is not frozen contiguously in stem-media-options order: {relation.get('relationship_id')}")
            if relation.get("after_order") != flattened:
                raise ValueError(f"relationship after_order differs from its role partition: {relation.get('relationship_id')}")
            if any(relation["relationship_id"] not in block_by_id[block_id].get("reading_relationship_refs", []) for block_id in flattened):
                raise ValueError(f"canonical atoms do not retain relationship lineage: {relation.get('relationship_id')}")
        event_ids = {
            event.get("relationship_id") for event in audit.get("risk_events", [])
            if event.get("trigger_code") == "COMPOSITE_STEM_MEDIA_OPTIONS_ORDER"
        }
        if event_ids != {item["relationship_id"] for item in relations}:
            raise ValueError("source-order risk events do not exactly cover the frozen composite relationships")
        if set(review.get("closed_composite_relationship_ids", [])) != event_ids or review.get("unresolved_composite_candidate_ids"):
            raise ValueError("source review closure does not close the composite relationship inventory")
        return {"applicable": True, "relationships": len(relations), "affected_pages": composite["summary"]["affected_pages"], "unresolved": 0}

    def canonical_atoms() -> dict[str, Any]:
        if len(atoms) != len(popo_raw):
            raise ValueError("canonical ledger does not contain every Popo source atom")
        atom_source_ids = [row["upstream_block_ref"]["popo_source_id"] for row in atoms]
        if Counter(atom_source_ids) != Counter(popo_source_ids) or len(set(atom_source_ids)) != len(atom_source_ids):
            raise ValueError("Popo source ids are not represented exactly once")
        block_ids = [row["block_id"] for row in atoms]
        if len(block_ids) != len(set(block_ids)):
            raise ValueError("canonical block ids are not unique")
        included = [row for row in atoms if row["scope_status"] == "included"]
        excluded = [row for row in atoms if row["scope_status"] == "excluded"]
        final_orders = sorted(row["candidate_final_order"] for row in included)
        if final_orders != list(range(1, len(included) + 1)):
            raise ValueError("included canonical atoms do not have a contiguous unique final order")
        if any(row["candidate_final_order"] is not None for row in excluded):
            raise ValueError("excluded atoms acquired a logical final order")
        configured_overrides = {
            source_id: group
            for group in config.get("block_scope_overrides") or []
            for source_id in group.get("source_ids") or []
        }
        by_source_id = {row["upstream_block_ref"]["popo_source_id"]: row for row in atoms}
        for source_id, group in configured_overrides.items():
            atom = by_source_id[source_id]
            if atom.get("scope_status") != "excluded" or atom.get("scope_reason") != group.get("reason"):
                raise ValueError(f"canonical atom did not consume scope override: {source_id}")
        ordered_ids = {block_id for page in order["pages"] for block_id in page["ordered_block_ids"]}
        if ordered_ids != {row["block_id"] for row in included}:
            raise ValueError("reading-order ledger and included canonical atoms diverge")
        if header.get("record_type") != "ledger_header" or not header.get("ledger_id"):
            raise ValueError("canonical ledger lacks the standard formal header identity")
        if header.get("current_ledger_hash_scope") != "canonical JSON hash of ordered source_block records":
            raise ValueError("canonical ledger uses a non-standard payload hash scope")
        if any(row.get("record_type") != "source_block" for row in atoms):
            raise ValueError("canonical ledger contains non-source_block payload records")
        recorded = header.get("current_ledger_hash")
        if recorded != canonical_hash(atoms):
            raise ValueError("canonical ledger payload hash mismatch")
        if "render_plan" in ledger_path.read_text(encoding="utf-8").lower():
            raise ValueError("source-reconciled canonical ledger contains a render-plan dependency")
        return {"source_atoms": len(atoms), "included": len(included), "excluded": len(excluded), "ledger_sha256": sha256_file(ledger_path)}

    def stage_commit() -> dict[str, Any]:
        expected_order = ["E1", "D1", "Spec01", "E2", "D2", "L", "M"]
        if manifest.get("commit_order") != expected_order:
            raise ValueError("stage commit order differs from the acyclic contract")
        drifted = []
        for item in manifest.get("artifacts", {}).values():
            path = run / item["path"]
            if not path.is_file() or sha256_file(path) != item["sha256"]:
                drifted.append(item["path"])
        if drifted:
            raise ValueError(f"stage artifact hashes drifted: {drifted}")
        return {"commit_order": expected_order, "artifacts": len(manifest["artifacts"]), "drifted": 0}

    checks.add("NATIVE-0102-H00-supported-producer-contract", supported_producer_contract)
    checks.add("NATIVE-0102-H01-formal-status-and-review-closure", formal_status)
    checks.add("NATIVE-0102-H02-input-and-template-identity", input_identity)
    checks.add("NATIVE-0102-H03-full-page-scope-partition", scope_partition)
    checks.add("NATIVE-0102-H04-source-page-render-evidence", rendered_source_pages)
    checks.add("NATIVE-0102-H05-acyclic-closed-decision-index", decision_dag)
    checks.add("NATIVE-0102-H06-reading-order-partition-and-risk-evidence", reading_order_partition)
    checks.add("NATIVE-0102-H07-composite-reading-relationship-gate", composite_relationship_gate)
    checks.add("NATIVE-0102-H08-atomic-canonical-coverage", canonical_atoms)
    checks.add("NATIVE-0102-H09-stage-commit-hashes", stage_commit)
    status = "passed" if all(item["status"] == "passed" for item in checks.items) else "failed"
    return {
        "schema_version": "native-spec01-spec02-validation/1.4",
        "status": status,
        "summary": {
            "checks": len(checks.items),
            "passed": sum(item["status"] == "passed" for item in checks.items),
            "failed": sum(item["status"] == "failed" for item in checks.items),
        },
        "checks": checks.items,
        "scope_limit": "Spec 01 input/provenance, Spec 02 scope/reading order, and the source_reconciled canonical checkpoint only.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--intake-run", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = validate(args)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
