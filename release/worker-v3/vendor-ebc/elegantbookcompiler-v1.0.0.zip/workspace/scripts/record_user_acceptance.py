#!/usr/bin/env python3
"""Append an immutable user-acceptance commit to a passed Spec 06 result."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rel(origin: Path, target: Path) -> str:
    return Path(os.path.relpath(target, origin)).as_posix()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--final-review-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--output-run", required=True)
    parser.add_argument("--accepted-by", required=True)
    parser.add_argument("--statement", required=True)
    parser.add_argument("--known-nonblocking-finding", action="append", default=[])
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    review = sample / "runs" / args.final_review_run
    compile_run = sample / "runs" / args.compile_run
    out = sample / "runs" / args.output_run
    require(not out.exists(), f"immutable output already exists: {out}")

    parent_path = review / "final_acceptance.json"
    parent = read(parent_path)
    build = read(compile_run / "manifests/build_manifest.json")
    final_pdf = compile_run / build["artifacts"]["final_pdf"]["path"]
    final_zip = compile_run / build["artifacts"]["formal_zip"]["path"]
    decision_index = review / parent["decision_index_D"]["path"]
    final_ledger = review / parent["final_verified_ledger_L"]["path"]
    ledger_manifest = review / parent["final_verified_ledger_manifest"]["path"]
    page_review = review / parent["page_review"]["path"]
    page_ledger = review / parent["page_ledger"]["path"]
    render_manifest = (review / parent["render_manifest"]["path"]).resolve()
    template_contract = compile_run / build["artifacts"]["template_contract"]["path"]
    template_integrity = compile_run / build["artifacts"]["template_integrity"]["path"]

    require(parent["spec_status"] == "passed", "parent Spec 06 status is not passed")
    require(parent["acceptance_status"] == "ready_for_user_acceptance", "parent is not ready for user acceptance")
    require(parent["human_accepted"] is False and parent["user_acceptance_record"] is None, "parent already claims a user decision")
    require(parent["build_id"] == build["build_id"], "build identity mismatch")
    require(parent["final_pdf_sha256"] == sha(final_pdf), "final PDF hash mismatch")
    require(parent["final_zip_sha256"] == sha(final_zip), "final ZIP hash mismatch")
    require(parent["decision_index_D"]["sha256"] == sha(decision_index), "decision index D hash mismatch")
    require(parent["final_verified_ledger_L"]["sha256"] == sha(final_ledger), "final_verified ledger L hash mismatch")
    require(parent["final_verified_ledger_manifest"]["sha256"] == sha(ledger_manifest), "ledger manifest hash mismatch")
    require(parent["page_review"]["sha256"] == sha(page_review), "page review hash mismatch")
    require(parent["page_ledger"]["sha256"] == sha(page_ledger), "page ledger hash mismatch")
    require(parent["render_manifest"]["sha256"] == sha(render_manifest), "render manifest hash mismatch")
    require(parent["template_contract_sha256"] == sha(template_contract), "template contract hash mismatch")
    require(parent["template_integrity_sha256"] == sha(template_integrity), "template integrity hash mismatch")

    out.mkdir(parents=True)
    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    parent_hash = sha(parent_path)
    record = {
        "schema_version": "final-acceptance-commit/1.1",
        "manifest_kind": "user_acceptance_commit",
        "commit_id": f"human-accept-{parent['final_pdf_sha256'][:12]}-{parent_hash[:12]}",
        "generated_at": timestamp,
        "spec_status": "passed",
        "acceptance_status": "human_accepted",
        "reason_code": "USER_ACCEPTED",
        "human_accepted": True,
        "parent_acceptance_ref": rel(out, parent_path),
        "parent_acceptance_hash": parent_hash,
        "parent_acceptance_commit_id": parent["commit_id"],
        "build_id": parent["build_id"],
        "source_pdf_sha256": parent["source_pdf_sha256"],
        "final_pdf_sha256": parent["final_pdf_sha256"],
        "final_zip_sha256": parent["final_zip_sha256"],
        "template_contract_sha256": parent["template_contract_sha256"],
        "template_integrity_sha256": parent["template_integrity_sha256"],
        "decision_index_D": {
            **parent["decision_index_D"],
            "path": rel(out, decision_index),
        },
        "final_verified_ledger_L": {
            **parent["final_verified_ledger_L"],
            "path": rel(out, final_ledger),
        },
        "final_verified_ledger_manifest": {
            **parent["final_verified_ledger_manifest"],
            "path": rel(out, ledger_manifest),
        },
        "page_review": {"path": rel(out, page_review), "sha256": sha(page_review)},
        "page_ledger": {"path": rel(out, page_ledger), "sha256": sha(page_ledger)},
        "render_manifest": {"path": rel(out, render_manifest), "sha256": sha(render_manifest)},
        "user_acceptance_record": {
            "accepted_at": timestamp,
            "accepted_by": args.accepted_by,
            "statement": args.statement,
            "scope": "The exact source PDF, final PDF, project ZIP, template evidence, D, L, page ledger, and render manifest bound by this commit.",
            "known_nonblocking_findings_acknowledged": args.known_nonblocking_finding,
        },
        "immutable_after_publication": True,
    }
    acceptance_path = out / "final_acceptance.json"
    write(acceptance_path, record)

    report = [
        "# 黄金样本用户接受记录",
        "",
        f"- 状态：`{record['acceptance_status']}`",
        f"- 接受人：`{args.accepted_by}`",
        f"- 接受时间：`{timestamp}`",
        f"- 父接受提交：`{parent['commit_id']}` / `{parent_hash}`",
        f"- PDF SHA-256：`{record['final_pdf_sha256']}`",
        f"- ZIP SHA-256：`{record['final_zip_sha256']}`",
        f"- D SHA-256：`{record['decision_index_D']['sha256']}`",
        f"- L SHA-256：`{record['final_verified_ledger_L']['sha256']}`",
        "",
        "## 用户原始确认",
        "",
        args.statement,
        "",
        "## 已知非阻断项",
        "",
    ]
    report.extend(f"- {item}" for item in args.known_nonblocking_finding)
    report.append("")
    report_path = out / "human_acceptance.md"
    report_path.write_text("\n".join(report), encoding="utf-8")

    manifest = {
        "schema_version": "user-acceptance-run-manifest/1.0",
        "generated_at": timestamp,
        "run_id": args.output_run,
        "spec_status": "passed",
        "acceptance_status": "human_accepted",
        "parent_acceptance_hash": parent_hash,
        "files": [
            {"path": "final_acceptance.json", "sha256": sha(acceptance_path), "size": acceptance_path.stat().st_size},
            {"path": "human_acceptance.md", "sha256": sha(report_path), "size": report_path.stat().st_size},
        ],
    }
    write(out / "manifest.json", manifest)
    print(json.dumps({
        "run": str(out),
        "acceptance_status": record["acceptance_status"],
        "commit_id": record["commit_id"],
        "parent_acceptance_hash": parent_hash,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
