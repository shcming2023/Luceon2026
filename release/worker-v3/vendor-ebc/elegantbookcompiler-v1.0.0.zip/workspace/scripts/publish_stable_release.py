#!/usr/bin/env python3
"""Publish an independently validated stable release to an isolated MinIO prefix."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


FORBIDDEN_PREFIXES = {"elegantbook", "latex", "minerupopo", "mineru", "raw", "clean", "standard"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def endpoint_config(raw: str) -> tuple[str, bool]:
    value = raw.strip()
    parsed = urlparse(value if "://" in value else f"http://{value}")
    if not parsed.netloc:
        raise SystemExit("invalid MinIO endpoint")
    return parsed.netloc, parsed.scheme == "https"


def clean_prefix(value: str) -> str:
    parts = [part for part in value.replace("\\", "/").split("/") if part and part not in {".", ".."}]
    prefix = "/".join(parts)
    if not prefix or parts[0].lower() in FORBIDDEN_PREFIXES:
        raise SystemExit("release prefix overlaps a material or pipeline namespace")
    return prefix


def get_bytes(client: Any, bucket: str, object_name: str) -> bytes:
    response = client.get_object(bucket, object_name)
    try:
        return response.read()
    finally:
        response.close()
        response.release_conn()


def put_immutable(client: Any, bucket: str, object_name: str, data: bytes, content_type: str) -> str:
    try:
        existing = get_bytes(client, bucket, object_name)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code not in {"NoSuchKey", "NoSuchObject", "NotFound"}:
            raise
    else:
        if sha256_bytes(existing) != sha256_bytes(data):
            raise SystemExit(f"refusing to overwrite different immutable object: {bucket}/{object_name}")
        return "verified_existing"
    client.put_object(
        bucket,
        object_name,
        io.BytesIO(data),
        length=len(data),
        content_type=content_type,
        metadata={"sha256": sha256_bytes(data)},
    )
    if sha256_bytes(get_bytes(client, bucket, object_name)) != sha256_bytes(data):
        raise SystemExit(f"post-upload hash mismatch: {bucket}/{object_name}")
    return "uploaded"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--bucket", default="eduassets-elegantbook")
    parser.add_argument("--prefix", default="compiler-releases")
    parser.add_argument("--release-dir", type=Path, required=True)
    parser.add_argument("--validation", type=Path, required=True)
    parser.add_argument("--maturity-assessment", type=Path, required=True)
    parser.add_argument("--receipt-output", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    release_dir = args.release_dir.resolve()
    manifest_path = release_dir / "release_manifest.json"
    manifest = load(manifest_path)
    validation = load(args.validation)
    maturity = load(args.maturity_assessment)
    if manifest.get("status") != "stable_release" or manifest.get("release") != "v1.0.0":
        raise SystemExit("release manifest is not the stable v1.0.0 snapshot")
    if validation.get("status") != "passed" or validation.get("manifest_sha256") != sha256(manifest_path):
        raise SystemExit("stable release independent validation is missing or does not bind the manifest")
    prefix = clean_prefix(args.prefix)
    release_prefix = f"{prefix}/{manifest['release']}"
    files = {
        "release_manifest.json": manifest_path,
        "independent_validation.json": args.validation,
        "release_notes.md": release_dir / "release_notes.md",
        "package_inventory.json": release_dir / "package_inventory.json",
        manifest["portable_package"]["path"]: release_dir / manifest["portable_package"]["path"],
        "project_maturity_assessment.json": args.maturity_assessment,
    }
    for path in files.values():
        if not path.is_file():
            raise SystemExit(f"publication input missing: {path}")
    plan = [
        {"bucket": args.bucket, "object": f"{release_prefix}/{name}", "sha256": sha256(path), "bytes": path.stat().st_size}
        for name, path in files.items()
    ]
    if not args.execute:
        print(json.dumps({"status": "dry_run", "release": manifest["release"], "objects": plan}, ensure_ascii=False, indent=2))
        return 0

    from minio import Minio

    env = read_env(args.env_file)
    endpoint, secure = endpoint_config(env.get("MINIO_ENDPOINT", ""))
    access_key = env.get("MINIO_ACCESS_KEY", "")
    secret_key = env.get("MINIO_SECRET_KEY", "")
    if not access_key or not secret_key:
        raise SystemExit("MinIO credentials are missing from env file")
    client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)
    if not client.bucket_exists(args.bucket):
        raise SystemExit(f"required production bucket does not exist: {args.bucket}")

    results = []
    for name, path in files.items():
        data = path.read_bytes()
        content_type = "application/json" if path.suffix == ".json" else "application/zip" if path.suffix == ".zip" else "text/markdown"
        object_name = f"{release_prefix}/{name}"
        action = put_immutable(client, args.bucket, object_name, data, content_type)
        results.append({"bucket": args.bucket, "object": object_name, "sha256": sha256_bytes(data), "bytes": len(data), "action": action})

    receipt = {
        "schema_version": "elegantbookcompiler-production-publication/1.0",
        "release": manifest["release"],
        "status": "production_published",
        "published_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "target": {"namespace": "consumer:LuceonWeb/global-MinIO", "bucket": args.bucket, "prefix": release_prefix},
        "release_manifest_sha256": sha256(manifest_path),
        "portable_package_sha256": manifest["portable_package"]["sha256"],
        "project_mature": maturity.get("project_mature") is True,
        "objects": results,
        "claim_boundary": "This receipt proves object publication and post-upload hash verification. It does not claim that LuceonWeb material jobs have switched to this compiler release.",
    }
    args.receipt_output.parent.mkdir(parents=True, exist_ok=True)
    args.receipt_output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    receipt_data = args.receipt_output.read_bytes()
    receipt_object = f"{release_prefix}/publication_receipt.json"
    put_immutable(client, args.bucket, receipt_object, receipt_data, "application/json")

    stable_pointer = {
        "schema_version": "elegantbookcompiler-stable-pointer/1.0",
        "release": manifest["release"],
        "status": "stable",
        "manifest": {"bucket": args.bucket, "object": f"{release_prefix}/release_manifest.json", "sha256": sha256(manifest_path)},
        "package": {"bucket": args.bucket, "object": f"{release_prefix}/{manifest['portable_package']['path']}", "sha256": manifest["portable_package"]["sha256"]},
        "publication_receipt": {"bucket": args.bucket, "object": receipt_object, "sha256": sha256_bytes(receipt_data)},
        "project_mature": maturity.get("project_mature") is True,
    }
    pointer_data = (json.dumps(stable_pointer, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    pointer_object = f"{prefix}/stable.json"
    client.put_object(args.bucket, pointer_object, io.BytesIO(pointer_data), len(pointer_data), content_type="application/json", metadata={"sha256": sha256_bytes(pointer_data)})
    if sha256_bytes(get_bytes(client, args.bucket, pointer_object)) != sha256_bytes(pointer_data):
        raise SystemExit("stable pointer post-upload hash mismatch")
    print(json.dumps({"status": "production_published", "receipt": str(args.receipt_output), "stable_pointer": stable_pointer}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
