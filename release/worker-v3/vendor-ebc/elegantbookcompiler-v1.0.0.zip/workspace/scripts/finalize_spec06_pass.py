#!/usr/bin/env python3
"""Freeze a passed Spec 06 review after explicit, evidence-bound visual review.

The program is sample-agnostic.  It does not perform visual judgment: a reviewer
must supply a configuration that enumerates every reviewed contact sheet, risk
board, and source-mapping board and binds the judgment to the exact PDF, ZIP,
build, and render-coverage ledger.  The program validates those bindings, closes
the diagnostic queue, then commits D -> L -> M in the order required by Spec 06.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import shutil
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def readl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def writel(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def chash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def rel(origin: Path, target: Path) -> str:
    return Path(os.path.relpath(target, origin)).as_posix()


def exact_files(directory: Path, pattern: str) -> list[str]:
    return sorted(path.name for path in directory.glob(pattern) if path.is_file())


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def apply_source_page_mapping_corrections(
    source_page_coverage: dict[str, Any],
    source_block_coverage: dict[str, Any],
    page_review: dict[str, Any],
    corrections: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Apply explicit human-reviewed page corrections to diagnostic mappings.

    Diagnostic media nodes without visible text anchors are placed by monotonic
    interpolation.  A correction may move only already-covered blocks from one
    final page to another; it cannot add, remove, or reassign source atoms.
    """
    final_labels = {int(item["physical_page"]): str(item["page_label"]) for item in page_review["pages"]}
    source_page_rows = {int(item["source_pdf_page"]): item for item in source_page_coverage["pages"]}
    applied: list[dict[str, Any]] = []
    for correction in corrections:
        source_page = int(correction["source_pdf_page"])
        move_map = {int(old): int(new) for old, new in correction["move_final_pages"].items()}
        selected_block_ids = {str(value) for value in correction.get("source_block_ids", [])}
        require(source_page in source_page_rows, f"mapping correction references unknown source page {source_page}")
        require(all(page in final_labels for page in move_map.values()), f"mapping correction references unknown final page: {correction}")
        moved = 0
        matched_block_ids: set[str] = set()
        for block in source_block_coverage["blocks"]:
            if int(block["source_pdf_page"]) != source_page:
                continue
            if selected_block_ids and str(block["block_id"]) not in selected_block_ids:
                continue
            old_page = int(block["final_pdf_page"])
            if old_page in move_map:
                new_page = move_map[old_page]
                block["final_pdf_page"] = new_page
                block["final_page_label"] = final_labels[new_page]
                block["mapping_method"] = "human_visual_mapping_correction"
                moved += 1
                matched_block_ids.add(str(block["block_id"]))
        if selected_block_ids:
            require(matched_block_ids == selected_block_ids, f"mapping correction did not move the exact selected blocks: expected {sorted(selected_block_ids)}, moved {sorted(matched_block_ids)}")
        require(moved == int(correction["expected_moved_block_count"]), f"mapping correction moved {moved} blocks, expected {correction['expected_moved_block_count']}: source page {source_page}")
        mapped_blocks = [item for item in source_block_coverage["blocks"] if int(item["source_pdf_page"]) == source_page]
        final_pages = sorted({int(item["final_pdf_page"]) for item in mapped_blocks})
        require(final_pages == [int(page) for page in correction["final_pdf_pages"]], f"corrected final-page set mismatch for source page {source_page}: {final_pages}")
        source_row = source_page_rows[source_page]
        source_row.update({
            "final_pdf_pages": final_pages,
            "final_page_labels": [final_labels[page] for page in final_pages],
            "mapping_confidence": "human_visual_correction",
            "human_mapping_correction": {
                "reason": correction["reason"],
                "evidence_refs": correction["evidence_refs"],
                "moved_block_count": moved,
                "source_block_ids": sorted(selected_block_ids),
            },
        })
        applied.append({**correction, "moved_block_count": moved})

    if corrections:
        blocks_by_final: dict[int, list[dict[str, Any]]] = {}
        for block in source_block_coverage["blocks"]:
            blocks_by_final.setdefault(int(block["final_pdf_page"]), []).append(block)
        for page in page_review["pages"]:
            blocks = blocks_by_final.get(int(page["physical_page"]), [])
            page["mapped_source_blocks"] = sorted({str(item["block_id"]) for item in blocks})
            page["mapped_source_pages"] = sorted({int(item["source_pdf_page"]) for item in blocks})
        source_page_coverage["human_mapping_corrections"] = applied
        source_block_coverage["human_mapping_corrections"] = applied
        page_review["human_mapping_corrections"] = applied
    return applied


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--diagnostic-run", required=True)
    parser.add_argument("--visual-run", required=True)
    parser.add_argument("--semantic-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--coverage-run", required=True)
    parser.add_argument("--review-config", required=True, type=Path)
    parser.add_argument("--output-run", required=True)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    diagnostic = sample / "runs" / args.diagnostic_run
    visual = sample / "runs" / args.visual_run
    semantic = sample / "runs" / args.semantic_run
    compile_run = sample / "runs" / args.compile_run
    coverage = sample / "runs" / args.coverage_run
    config_path = args.review_config.resolve()
    out = sample / "runs" / args.output_run
    require(not out.exists(), f"immutable output already exists: {out}")
    for directory in ("decisions", "ledgers", "reports", "qa", "review", "manifests"):
        (out / directory).mkdir(parents=True, exist_ok=False)

    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    config = read(config_path)
    diagnostic_page_review = read(diagnostic / "reports/page_review.json")
    diagnostic_queue = read(diagnostic / "qa/human_review_queue.json")
    diagnostic_anomalies = read(diagnostic / "reports/automated_anomalies.json")
    review_manifest = read(diagnostic / "manifests/review_pack_manifest.json")
    build_manifest = read(compile_run / "manifests/build_manifest.json")
    compile_report = read(compile_run / "reports/compile_report.json")
    template_report = read(compile_run / "reports/template_integrity_final_report.json")
    semantic_manifest_path = semantic / "manifests/semantic_stage_manifest.json"
    if not semantic_manifest_path.exists():
        semantic_manifest_path = semantic / "manifests/spec04d_render_plan_stage_manifest.json"
    semantic_manifest = read(semantic_manifest_path)
    parent_ledger_path = coverage / "ledgers/canonical_block_ledger.jsonl"
    parent_ledger_manifest_path = coverage / "ledgers/ledger_manifest.json"
    parent_index_path = coverage / "decisions/canonical_decision_index.json"
    parent_rows = readl(parent_ledger_path)
    parent_header, source_rows = parent_rows[0], parent_rows[1:]
    parent_ledger_manifest = read(parent_ledger_manifest_path)
    parent_index = read(parent_index_path)

    final_pdf = compile_run / build_manifest["artifacts"]["final_pdf"]["path"]
    final_zip = compile_run / build_manifest["artifacts"]["formal_zip"]["path"]
    render_manifest_path = compile_run / build_manifest["artifacts"]["render_pack"]["path"]
    render_manifest = read(render_manifest_path)
    pdf_hash, zip_hash = sha(final_pdf), sha(final_zip)

    bindings = config["bindings"]
    require(config.get("all_pages_human_reviewed") is True, "review config must explicitly attest all-page visual review")
    require(bindings["source_pdf_sha256"] == diagnostic_page_review["source_pdf_sha256"], "source PDF binding mismatch")
    require(bindings["final_pdf_sha256"] == pdf_hash, "final PDF binding mismatch")
    require(bindings["final_zip_sha256"] == zip_hash, "final ZIP binding mismatch")
    require(bindings["build_id"] == build_manifest["build_id"], "build binding mismatch")
    require(bindings["render_coverage_ledger_snapshot_id"] == parent_ledger_manifest["snapshot_id"], "ledger binding mismatch")
    require(review_manifest["final_pdf_sha256"] == pdf_hash, "diagnostic review pack belongs to another PDF")
    require(review_manifest["summary"]["final_pages"] == compile_report["pdf"]["pages"] == render_manifest["page_count"], "page-count binding mismatch")
    require(semantic_manifest["status"] == "passed" and semantic_manifest.get("full_spec04_status", "passed") == "passed", "Spec 04 is not passed")
    require(compile_report["spec_status"] == "passed" and template_report["status"] == "passed", "Spec 05 is not passed")
    require(parent_ledger_manifest["spec_status"] == "passed" and parent_ledger_manifest["ledger_checkpoint"] == "render_coverage", "Spec 03 render_coverage is not passed")
    require(parent_index["summary"]["open"] == 0 and parent_index["summary"]["invalidated"] == 0, "parent decision index has unresolved decisions")

    contact_root = compile_run / "final_render_pack/contact_sheets"
    contact_pattern = "sheet-*.jpg"
    if not contact_root.is_dir():
        contact_root = visual / "all_pages"
        contact_pattern = "*.jpg"
    contact_files = exact_files(contact_root, contact_pattern)
    risk_files = exact_files(visual / "risk_pages", "*.jpg")
    mapping_files = exact_files(visual / "source_mapping", "*.jpg")
    require(sorted(config["reviewed_contact_sheet_files"]) == contact_files, "review config does not enumerate every contact sheet")
    require(sorted(config["reviewed_risk_board_files"]) == risk_files, "review config does not enumerate every risk board")
    require(sorted(config["reviewed_source_mapping_files"]) == mapping_files, "review config does not enumerate every source-mapping board")
    require(len(contact_files) > 0 and len(risk_files) > 0 and len(mapping_files) > 0, "visual evidence set is empty")
    require(config["reviewed_page_count"] == diagnostic_page_review["page_count"], "reviewed page count mismatch")
    require(config["reviewed_risk_page_count"] == len(diagnostic_page_review["risk_pages"]), "reviewed risk-page count mismatch")
    require(config["automatic_candidate_disposition"] == "false_positive_after_visual_review", "automatic candidates were not explicitly disposed")
    require(config.get("confirmed_v0_v1_count", config.get("confirmed_v0_v1_v2_count")) == 0, "confirmed V0/V1 defects remain")

    source_page_coverage = read(diagnostic / "reports/source_page_coverage.json")
    source_block_coverage = read(diagnostic / "reports/source_block_coverage.json")
    reading_order = read(diagnostic / "reports/reading_order_audit.json")
    formula_audit = read(diagnostic / "reports/formula_table_image_audit.json")
    semantic_audit = read(diagnostic / "reports/semantic_mapping_audit.json")
    toc_audit = read(diagnostic / "reports/toc_page_number_audit.json")
    mapping_corrections = apply_source_page_mapping_corrections(
        source_page_coverage,
        source_block_coverage,
        diagnostic_page_review,
        config.get("source_page_mapping_corrections", []),
    )
    semantic_resolutions = config.get("semantic_candidate_resolutions", [])
    resolution_by_node = {item["render_node_id"]: item for item in semantic_resolutions}
    unresolved_heading_candidates = []
    resolved_heading_candidates = []
    for candidate in semantic_audit["heading_orphan_candidates"]:
        resolution = resolution_by_node.get(candidate["render_node_id"])
        if not resolution:
            unresolved_heading_candidates.append(candidate)
            continue
        require(int(resolution["physical_page"]) == int(candidate["physical_page"]), "semantic candidate resolution page mismatch")
        require(resolution["classification"] in {"V2", "V3"} and resolution["status"] == "closed", "semantic candidate resolution is not closed as V2/V3")
        resolved_heading_candidates.append({**candidate, **resolution})
    require(not unresolved_heading_candidates, "semantic heading orphan remains unresolved")
    require(set(resolution_by_node) == {item["render_node_id"] for item in semantic_audit["heading_orphan_candidates"]}, "semantic resolution references an unknown candidate")
    semantic_audit["resolved_heading_orphan_candidates"] = resolved_heading_candidates
    semantic_audit["heading_orphan_candidates"] = []
    require(source_page_coverage["covered_source_pages"] == source_page_coverage["included_source_pages"], "source page coverage incomplete")
    require(source_block_coverage["summary"]["covered"] == source_block_coverage["summary"]["included_logical_atoms"], "source block coverage incomplete")
    require(not reading_order["anchor_order_inversions"] and not reading_order["source_page_mapping_inversions"], "reading-order inversion remains")
    require(formula_audit["asset_failures"] == 0 and formula_audit["open_media_reviews_from_render_coverage"] == 0, "media closure incomplete")
    require(toc_audit["passed"] == toc_audit["toc_nodes"] == toc_audit["outline_nodes"] and toc_audit["needs_review"] == 0, "TOC audit incomplete")
    require(semantic_audit["heading_orphan_candidates"] == [], "semantic heading orphan remains")

    decision_ids = {
        "all_pages": "DEC-FR6-PASS-001",
        "risk_media": "DEC-FR6-PASS-002",
        "mapping_order": "DEC-FR6-PASS-003",
        "anomalies": "DEC-FR6-PASS-004",
        "outcome": "DEC-FR6-PASS-005",
    }
    risk_pages = set(diagnostic_page_review["risk_pages"])
    finalized_pages = []
    for page in diagnostic_page_review["pages"]:
        refs = [decision_ids["all_pages"]]
        if page["physical_page"] in risk_pages:
            refs.append(decision_ids["risk_media"])
        if page["mapped_source_pages"]:
            refs.append(decision_ids["mapping_order"])
        findings = list(page["automatic_findings"])
        if findings:
            refs.append(decision_ids["anomalies"])
            findings = [f"{item}:false_positive_after_visual_review" for item in findings]
        finalized_pages.append({
            **page,
            "automatic_findings": findings,
            "page_status": "human_reviewed_passed",
            "human_review_status": "closed",
            "human_decision_refs": sorted(set(refs)),
            "confirmed_severity": None,
        })

    page_ledger_path = out / "reports/final_page_hash_ledger.jsonl"
    writel(page_ledger_path, finalized_pages)

    queue_items = []
    for item in diagnostic_queue["items"]:
        item = dict(item)
        if item["type"] == "source_region_formula_table_visual_review":
            refs = [decision_ids["risk_media"]]
            resolution = "source_regions_and_media_visually_verified"
        elif item["type"] == "source_page_mapping_review":
            refs = [decision_ids["mapping_order"]]
            resolution = "source_to_final_mapping_visually_verified"
        else:
            refs = [decision_ids["all_pages"], decision_ids["anomalies"]]
            resolution = "visual_review_passed_or_detector_false_positive"
        item.update({"status": "closed", "resolution": resolution, "decision_refs": refs})
        queue_items.append(item)
    queue = {
        "schema_version": "human-review-queue/1.0-finalized-passed",
        "generated_at": timestamp,
        "spec_status": "passed",
        "open_count": 0,
        "closed_count": len(queue_items),
        "resolution_counts": dict(Counter(item["resolution"] for item in queue_items)),
        "items": queue_items,
    }
    write(out / "qa/human_review_queue.json", queue)

    anomaly_rows = []
    for item in diagnostic_anomalies["anomalies"]:
        item = dict(item)
        item.update({
            "status": "false_positive",
            "human_decision_ref": decision_ids["anomalies"],
            "resolution_reason": "The candidate page and its source-region/mapping context were visually reviewed; no content, order, media, or readability defect was confirmed.",
        })
        anomaly_rows.append(item)
    anomalies = {
        **diagnostic_anomalies,
        "schema_version": "automated-anomalies/1.0-finalized-passed",
        "generated_at": timestamp,
        "spec_status": "passed",
        "human_review_open_count": 0,
        "confirmed_v0_v1_v2_count": 0,
        "summary": dict(Counter(item["status"] for item in anomaly_rows)),
        "anomalies": anomaly_rows,
    }
    write(out / "reports/automated_anomalies.json", anomalies)

    formula_audit.update({
        "generated_at": timestamp,
        "spec_status": "passed",
        "status": "passed",
        "visual_source_region_review": "passed",
        "reviewed_source_region_image_nodes": formula_audit["source_region_image_nodes"],
        "decision_ref": decision_ids["risk_media"],
    })
    semantic_audit.update({
        "generated_at": timestamp,
        "spec_status": "passed",
        "status": "passed",
        "visual_semantic_mapping_review": "passed",
        "semantic_candidate_resolutions": semantic_resolutions,
        "decision_ref": decision_ids["mapping_order"],
    })
    toc_audit.update({
        "generated_at": timestamp,
        "spec_status": "passed",
        "status": "passed",
        "visual_source_toc_comparison": "passed",
        "decision_ref": decision_ids["mapping_order"],
    })
    for name, value in (
        ("source_page_coverage.json", source_page_coverage),
        ("source_block_coverage.json", source_block_coverage),
        ("reading_order_audit.json", reading_order),
        ("formula_table_image_audit.json", formula_audit),
        ("semantic_mapping_audit.json", semantic_audit),
        ("toc_page_number_audit.json", toc_audit),
    ):
        write(out / "reports" / name, value)
    shutil.copy2(diagnostic / "review/page_contact_sheet.pdf", out / "review/page_contact_sheet.pdf")

    precommit_gates = [
        ("FR-H01", "all upstream specifications/checkpoints passed"),
        ("FR-H02", "PDF, ZIP, template, render pack, and ledger bind one build"),
        ("FR-H03", f"{len(finalized_pages)} contiguous page-ledger records for {render_manifest['page_count']} PDF pages"),
        ("FR-H04", "every page raster exists and its manifest hash was verified"),
        ("FR-H05", "no unexplained blank or duplicate page was confirmed"),
        ("FR-H06", "full-page and risk-board review found no blocking clipping, overlap, or unreadability"),
        ("FR-H07", f"all {source_page_coverage['included_source_pages']} included source pages are covered"),
        ("FR-H08", f"all {source_block_coverage['summary']['included_logical_atoms']} logical atoms are covered"),
        ("FR-H09", "no unsourced educational addition was confirmed"),
        ("FR-H10", "no unexplained omission or duplicate was confirmed"),
        ("FR-H11", f"{reading_order['unique_visible_anchors']} visible anchors have zero order inversions"),
        ("FR-H12", f"{formula_audit['source_asset_image_nodes']} asset nodes and {formula_audit['source_region_image_nodes']} source-region nodes are closed"),
        ("FR-H13", "semantic roles, boxes, headings, and visible answers were reviewed and are valid"),
        ("FR-H14", f"all {toc_audit['toc_nodes']} TOC/outline nodes match final page destinations"),
        ("FR-H15", "the final substantive source teaching item and body tail are present"),
        ("FR-H16", "no internal path, debug, Markdown, or HTML residue was observed"),
        ("FR-H17", "no confirmed V0/V1 and no unresolved V0/V1 candidate exists"),
        ("FR-H18", f"all {len(queue_items)} human-review items are closed"),
    ]
    gate_matrix = [{"gate": gate, "status": "passed", "reason": reason} for gate, reason in precommit_gates]

    page_review = {
        **diagnostic_page_review,
        "schema_version": "page-review/1.0-finalized-passed",
        "generated_at": timestamp,
        "spec_status": "passed",
        "acceptance_status": "ready_for_user_acceptance",
        "automatic_page_checks_complete": True,
        "all_pages_human_reviewed": True,
        "human_review_queue_open_count": 0,
        "confirmed_v0_v1_count": 0,
        "closed_v2_count": sum(item.get("classification") == "V2" for item in semantic_resolutions),
        "residual_v3_count": len(config.get("residual_v3_notes", [])),
        "residual_v3_notes": config.get("residual_v3_notes", []),
        "source_page_mapping_corrections": mapping_corrections,
        "semantic_candidate_resolutions": semantic_resolutions,
        "hard_gate_matrix": gate_matrix,
        "failure_codes": [],
        "pages": finalized_pages,
        "scope_limit": "Spec 06 passed for the exact bound build and is ready for user acceptance; human acceptance is not asserted.",
    }
    page_review_path = out / "reports/page_review.json"
    write(page_review_path, page_review)

    evidence = {
        "schema_version": "spec06-human-visual-evidence/1.0",
        "generated_at": timestamp,
        "reviewer": config["reviewer"],
        "bindings": bindings,
        "all_pages_human_reviewed": True,
        "reviewed_page_count": config["reviewed_page_count"],
        "reviewed_risk_page_count": config["reviewed_risk_page_count"],
        "contact_sheets": [{"path": rel(out, contact_root / name), "sha256": sha(contact_root / name)} for name in contact_files],
        "risk_boards": [{"path": rel(out, visual / "risk_pages" / name), "sha256": sha(visual / "risk_pages" / name)} for name in risk_files],
        "source_mapping_boards": [{"path": rel(out, visual / "source_mapping" / name), "sha256": sha(visual / "source_mapping" / name)} for name in mapping_files],
        "review_conclusion": config["review_conclusion"],
        "confirmed_v0_v1_count": 0,
        "closed_v2_count": sum(item.get("classification") == "V2" for item in semantic_resolutions),
        "residual_v3_notes": config.get("residual_v3_notes", []),
        "source_page_mapping_corrections": mapping_corrections,
        "semantic_candidate_resolutions": semantic_resolutions,
    }
    evidence_path = out / "reports/human_visual_review_evidence.json"
    write(evidence_path, evidence)

    decisions = [
        (decision_ids["all_pages"], "FR-H03/FR-H04/FR-H05/FR-H06/FR-H15/FR-H16", f"All {len(finalized_pages)} final pages were visually reviewed; no blocking page defect was confirmed."),
        (decision_ids["risk_media"], "FR-H06/FR-H12/FR-H17/FR-H18", f"All {len(risk_pages)} risk pages and all {formula_audit['source_region_image_nodes']} source-region nodes were reviewed and closed."),
        (decision_ids["mapping_order"], "FR-H07/FR-H08/FR-H11/FR-H13/FR-H14", f"Source-to-final mapping, reading order, semantic constructs, TOC, and page destinations were visually verified; {len(mapping_corrections)} source-page corrections and {len(semantic_resolutions)} semantic candidate resolutions are recorded."),
        (decision_ids["anomalies"], "FR-H05/FR-H06/FR-H17/FR-H18", f"All {len(anomaly_rows)} automated candidates were closed as false positives after visual review."),
        (decision_ids["outcome"], "FR-H01-FR-H21", "Spec 06 passes and the exact build is ready for user acceptance; human acceptance remains false until the user explicitly accepts."),
    ]
    decision_rows = [{
        "decision_id": decision_id,
        "event_type": "human_review_decision",
        "stage": "final_page_review",
        "status": "closed",
        "rule_id": rule_id,
        "decision": decision,
        "reason": "Evidence-bound final review under the approved workspace contract.",
        "decider": config["reviewer"],
        "decided_at": timestamp,
        "applies_to": bindings,
        "evidence_refs": [
            {"path": "reports/human_visual_review_evidence.json", "sha256": sha(evidence_path)},
            {"path": "reports/page_review.json", "sha256": sha(page_review_path)},
            {"path": "reports/final_page_hash_ledger.jsonl", "sha256": sha(page_ledger_path)},
        ],
        "supersedes": [],
        "invalidated_by": None,
    } for decision_id, rule_id, decision in decisions]
    decisions_path = out / "decisions/final_decisions.jsonl"
    writel(decisions_path, decision_rows)

    index_decisions = list(parent_index["decisions"]) + [{
        "decision_id": row["decision_id"],
        "event_file": "decisions/final_decisions.jsonl",
        "status": row["status"],
        "rule_id": row["rule_id"],
        "supersedes": [],
        "invalidated_by": None,
    } for row in decision_rows]
    decision_index = {
        "schema_version": parent_index["schema_version"],
        "snapshot_id": config["decision_index_snapshot_id"],
        "decision_index_id": parent_index["decision_index_id"],
        "version": parent_index["version"] + 1,
        "generated_at": timestamp,
        "spec_status": "passed",
        "parent_index_ref": rel(out, parent_index_path),
        "parent_index_hash": sha(parent_index_path),
        "evidence_committed_before_index": True,
        "acyclic_commit_rule": parent_index["acyclic_commit_rule"],
        "acceptance_bindings": {
            "build_id": build_manifest["build_id"],
            "final_pdf_sha256": pdf_hash,
            "final_zip_sha256": zip_hash,
            "render_manifest_sha256": sha(render_manifest_path),
            "page_ledger_sha256": sha(page_ledger_path),
            "page_review_sha256": sha(page_review_path),
            "human_visual_review_evidence_sha256": sha(evidence_path),
            "parent_render_coverage_ledger_sha256": sha(parent_ledger_path),
        },
        "decision_event_files": parent_index["decision_event_files"] + [{
            "path": "decisions/final_decisions.jsonl",
            "sha256": sha(decisions_path),
            "decision_ids": [row["decision_id"] for row in decision_rows],
        }],
        "decisions": index_decisions,
        "summary": {
            "closed": sum(item["status"] == "closed" for item in index_decisions),
            "open": sum(item["status"] == "open" for item in index_decisions),
            "superseded": sum(item["status"] == "superseded" for item in index_decisions),
            "invalidated": sum(item["status"] == "invalidated" for item in index_decisions),
        },
    }
    index_path = out / "decisions/canonical_decision_index.json"
    write(index_path, decision_index)
    require(decision_index["summary"]["open"] == 0 and decision_index["summary"]["invalidated"] == 0, "final decision index is not frozen cleanly")

    final_snapshot_id = config["final_verified_ledger_snapshot_id"]
    child_header = dict(parent_header)
    child_header.update({
        "generated_at": timestamp,
        "updated_at": timestamp,
        "ledger_checkpoint": "final_verified",
        "ledger_snapshot_id": final_snapshot_id,
        "ledger_version": parent_header["ledger_version"] + 1,
        "parent_ledger_ref": rel(out, parent_ledger_path),
        "parent_ledger_file_sha256": sha(parent_ledger_path),
        "parent_ledger_hash": parent_ledger_manifest["payload_hash"],
        "canonical_decision_index_ref": "decisions/canonical_decision_index.json",
        "canonical_decision_index_hash": sha(index_path),
        "current_ledger_hash": parent_ledger_manifest["payload_hash"],
        "final_page_review_ref": "reports/page_review.json",
        "final_page_review_sha256": sha(page_review_path),
        "final_page_hash_ledger_ref": "reports/final_page_hash_ledger.jsonl",
        "final_page_hash_ledger_sha256": sha(page_ledger_path),
        "final_render_manifest_ref": rel(out, render_manifest_path),
        "final_render_manifest_sha256": sha(render_manifest_path),
        "spec_status": "passed",
    })
    ledger_path = out / "ledgers/canonical_block_ledger.jsonl"
    writel(ledger_path, [child_header] + source_rows)
    ledger_manifest = {
        "schema_version": "ledger-manifest/2.0",
        "generated_at": timestamp,
        "ledger_id": child_header["ledger_id"],
        "snapshot_id": final_snapshot_id,
        "ledger_version": child_header["ledger_version"],
        "ledger_checkpoint": "final_verified",
        "spec_status": "passed",
        "parent_artifact_ref": rel(out, parent_ledger_path),
        "parent_artifact_sha256": sha(parent_ledger_path),
        "payload_hash": parent_ledger_manifest["payload_hash"],
        "artifact_path": "ledgers/canonical_block_ledger.jsonl",
        "artifact_sha256": sha(ledger_path),
        "decision_index_ref": "decisions/canonical_decision_index.json",
        "decision_index_hash": sha(index_path),
        "final_pdf_sha256": pdf_hash,
        "final_zip_sha256": zip_hash,
        "page_review_sha256": sha(page_review_path),
        "page_ledger_sha256": sha(page_ledger_path),
        "immutable_after_publication": True,
    }
    ledger_manifest_path = out / "ledgers/ledger_manifest.json"
    write(ledger_manifest_path, ledger_manifest)

    gate_matrix.extend([
        {"gate": "FR-H19", "status": "passed", "reason": "final decision index D is frozen with no open or invalidated decision and does not reference child ledger L"},
        {"gate": "FR-H20", "status": "passed", "reason": "final_verified ledger L is an immutable child of the render_coverage snapshot and binds D"},
        {"gate": "FR-H21", "status": "passed", "reason": "final acceptance commit M binds D, L, PDF, ZIP, render manifest, and page review"},
    ])
    page_review["hard_gate_matrix"] = gate_matrix
    # Record stable identities only here.  Hashes are committed by M; embedding
    # D/L hashes in a report already hashed by D would create a cycle.
    page_review["final_decision_index"] = {"snapshot_id": decision_index["snapshot_id"]}
    page_review["final_verified_ledger"] = {"snapshot_id": final_snapshot_id}
    write(page_review_path, page_review)

    # page_review changed only by adding D/L bindings; refresh D and L hashes that bind it.
    decision_index["acceptance_bindings"]["page_review_sha256"] = sha(page_review_path)
    write(index_path, decision_index)
    child_header["canonical_decision_index_hash"] = sha(index_path)
    child_header["final_page_review_sha256"] = sha(page_review_path)
    writel(ledger_path, [child_header] + source_rows)
    ledger_manifest.update({
        "artifact_sha256": sha(ledger_path),
        "decision_index_hash": sha(index_path),
        "page_review_sha256": sha(page_review_path),
    })
    write(ledger_manifest_path, ledger_manifest)

    acceptance = {
        "schema_version": "final-acceptance-commit/1.0",
        "generated_at": timestamp,
        "manifest_kind": "spec06_acceptance_commit_M",
        "commit_id": f"accept-{pdf_hash[:12]}-{sha(ledger_path)[:12]}",
        "spec_status": "passed",
        "acceptance_status": "ready_for_user_acceptance",
        "reason_code": "ACCEPTANCE_PENDING",
        "build_id": build_manifest["build_id"],
        "source_pdf_sha256": bindings["source_pdf_sha256"],
        "final_pdf_sha256": pdf_hash,
        "final_zip_sha256": zip_hash,
        "render_manifest": {"path": rel(out, render_manifest_path), "sha256": sha(render_manifest_path)},
        "template_contract_sha256": build_manifest["artifacts"]["template_contract"]["sha256"],
        "template_integrity_sha256": build_manifest["artifacts"]["template_integrity"]["sha256"],
        "page_review": {"path": "reports/page_review.json", "sha256": sha(page_review_path)},
        "page_ledger": {"path": "reports/final_page_hash_ledger.jsonl", "sha256": sha(page_ledger_path)},
        "decision_index_D": {"path": "decisions/canonical_decision_index.json", "snapshot_id": decision_index["snapshot_id"], "sha256": sha(index_path)},
        "final_verified_ledger_L": {"path": "ledgers/canonical_block_ledger.jsonl", "snapshot_id": final_snapshot_id, "sha256": sha(ledger_path)},
        "final_verified_ledger_manifest": {"path": "ledgers/ledger_manifest.json", "sha256": sha(ledger_manifest_path)},
        "human_accepted": False,
        "user_acceptance_record": None,
    }
    acceptance_path = out / "final_acceptance.json"
    write(acceptance_path, acceptance)

    html_rows = []
    for page in finalized_pages:
        html_rows.append(
            "<tr>" +
            f"<td>{page['physical_page']}</td><td>{html.escape(str(page['page_label']))}</td>" +
            f"<td>{html.escape(page['page_status'])}</td><td>{html.escape(', '.join(page['automatic_findings']) or 'none')}</td>" +
            f"<td><a href=\"{html.escape(page['raster_ref'])}\">raster</a></td></tr>"
        )
    (out / "review/page_review.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>Spec 06 passed final review</title>"
        "<style>body{font-family:sans-serif}table{border-collapse:collapse}td,th{border:1px solid #aaa;padding:4px;vertical-align:top}</style>"
        f"<h1>Spec 06 final review: passed</h1><p>PDF: {pdf_hash}</p><p>All {len(finalized_pages)} pages reviewed; ready for user acceptance.</p>"
        "<table><thead><tr><th>Physical page</th><th>Label</th><th>Status</th><th>Findings</th><th>Evidence</th></tr></thead><tbody>" +
        "".join(html_rows) + "</tbody></table>", encoding="utf-8"
    )

    report_lines = [
        "# Spec 06 final page review — passed",
        "",
        f"- Final PDF SHA-256: `{pdf_hash}`",
        f"- Final ZIP SHA-256: `{zip_hash}`",
        f"- Build: `{build_manifest['build_id']}`",
        f"- Full-page review: `{len(finalized_pages)}/{len(finalized_pages)}` pages passed.",
        f"- High-risk pages: `{len(risk_pages)}/{len(risk_pages)}` closed.",
        f"- Human review queue: `0` open of `{len(queue_items)}` items.",
        f"- Source coverage: `{source_page_coverage['covered_source_pages']}/{source_page_coverage['included_source_pages']}` pages; `{source_block_coverage['summary']['covered']}/{source_block_coverage['summary']['included_logical_atoms']}` logical atoms.",
        f"- Reading-order anchors: `{reading_order['unique_visible_anchors']}` with `0` inversions.",
        f"- TOC/outline: `{toc_audit['passed']}/{toc_audit['toc_nodes']}` passed.",
        f"- Human source-page mapping corrections: `{len(mapping_corrections)}`.",
        f"- Closed semantic candidates: `{len(semantic_resolutions)}`; residual V3 notes: `{len(config.get('residual_v3_notes', []))}`.",
        "- Spec status: `passed`.",
        "- Acceptance status: `ready_for_user_acceptance`.",
        "- Human accepted: `false` (reserved for the user's explicit decision).",
        "",
        "## Commit chain",
        "",
        f"- D: `{decision_index['snapshot_id']}` / `{sha(index_path)}`",
        f"- L: `{final_snapshot_id}` / `{sha(ledger_path)}`",
        f"- M: `{acceptance['commit_id']}`",
        "",
    ]
    report_text = "\n".join(report_lines)
    (out / "reports/final_review_report.md").write_text(report_text, encoding="utf-8")
    (out / "final_acceptance.md").write_text(report_text, encoding="utf-8")

    manifest = {
        "schema_version": "spec06-passed-review-manifest/1.0",
        "generated_at": timestamp,
        "run_id": args.output_run,
        "spec_status": "passed",
        "acceptance_status": "ready_for_user_acceptance",
        "build_id": build_manifest["build_id"],
        "source_pdf_sha256": bindings["source_pdf_sha256"],
        "final_pdf_sha256": pdf_hash,
        "final_zip_sha256": zip_hash,
        "render_manifest_sha256": sha(render_manifest_path),
        "render_coverage_parent_snapshot_id": parent_ledger_manifest["snapshot_id"],
        "final_verified_ledger_snapshot_id": final_snapshot_id,
        "summary": {
            "final_pages": len(finalized_pages),
            "human_reviewed_pages": len(finalized_pages),
            "risk_pages": len(risk_pages),
            "open_human_reviews": 0,
            "confirmed_v0_v1": 0,
            "closed_v2": sum(item.get("classification") == "V2" for item in semantic_resolutions),
            "residual_v3": len(config.get("residual_v3_notes", [])),
            "hard_gates_passed": 21,
            "human_accepted": False,
        },
        "commit_chain": {
            "D": {"path": "decisions/canonical_decision_index.json", "sha256": sha(index_path)},
            "L": {"path": "ledgers/canonical_block_ledger.jsonl", "sha256": sha(ledger_path)},
            "M": {"path": "final_acceptance.json", "sha256": sha(acceptance_path)},
        },
        "inputs": {
            "review_config": {"path": rel(out, config_path), "sha256": sha(config_path)},
            "diagnostic_review_pack": {"path": rel(out, diagnostic / "manifests/review_pack_manifest.json"), "sha256": sha(diagnostic / "manifests/review_pack_manifest.json")},
            "visual_evidence": {"path": rel(out, visual / "manifest.json"), "sha256": sha(visual / "manifest.json")},
            "parent_render_coverage_ledger": {"path": rel(out, parent_ledger_path), "sha256": sha(parent_ledger_path)},
        },
        "files": [],
    }
    manifest_path = out / "manifests/final_review_manifest.json"
    write(manifest_path, manifest)
    manifest["files"] = [{
        "path": path.relative_to(out).as_posix(), "sha256": sha(path), "size": path.stat().st_size
    } for path in sorted(out.rglob("*")) if path.is_file() and path != manifest_path]
    write(manifest_path, manifest)
    print(json.dumps({"run": str(out), "spec_status": "passed", "acceptance_status": "ready_for_user_acceptance", "summary": manifest["summary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
