#!/usr/bin/env python3
"""Independently validate an immutable user-acceptance commit."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--final-review-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--acceptance-run", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    review = sample / "runs" / args.final_review_run
    compile_run = sample / "runs" / args.compile_run
    accepted_run = sample / "runs" / args.acceptance_run
    parent_path = review / "final_acceptance.json"
    parent = read(parent_path)
    accepted = read(accepted_run / "final_acceptance.json")
    manifest = read(accepted_run / "manifest.json")
    build = read(compile_run / "manifests/build_manifest.json")
    pdf = compile_run / build["artifacts"]["final_pdf"]["path"]
    project_zip = compile_run / build["artifacts"]["formal_zip"]["path"]

    checks: list[dict[str, str]] = []

    def check(check_id: str, condition: bool, evidence: str) -> None:
        checks.append({"check_id": check_id, "status": "passed" if condition else "failed", "evidence": evidence})

    check("UA-H01-PARENT", parent["acceptance_status"] == "ready_for_user_acceptance" and accepted["parent_acceptance_hash"] == sha(parent_path), "accepted commit is a child of the exact ready-for-user M")
    check("UA-H02-STATUS", accepted["spec_status"] == "passed" and accepted["acceptance_status"] == "human_accepted" and accepted["human_accepted"] is True, "acceptance state is explicit")
    check("UA-H03-ARTIFACTS", accepted["final_pdf_sha256"] == sha(pdf) and accepted["final_zip_sha256"] == sha(project_zip), "live PDF and ZIP hashes match")
    check("UA-H04-TEMPLATE", accepted["template_contract_sha256"] == parent["template_contract_sha256"] and accepted["template_integrity_sha256"] == parent["template_integrity_sha256"], "template evidence hashes are inherited unchanged")
    check("UA-H05-D", accepted["decision_index_D"]["sha256"] == parent["decision_index_D"]["sha256"] == sha((accepted_run / accepted["decision_index_D"]["path"]).resolve()), "decision index D is hash-bound")
    check("UA-H06-L", accepted["final_verified_ledger_L"]["sha256"] == parent["final_verified_ledger_L"]["sha256"] == sha((accepted_run / accepted["final_verified_ledger_L"]["path"]).resolve()), "final_verified ledger L is hash-bound")
    check("UA-H07-PAGES", accepted["page_ledger"]["sha256"] == parent["page_ledger"]["sha256"] == sha((accepted_run / accepted["page_ledger"]["path"]).resolve()), "final page ledger is hash-bound")
    user_record = accepted.get("user_acceptance_record") or {}
    check("UA-H08-USER", bool(user_record.get("accepted_by")) and bool(user_record.get("accepted_at")) and bool(user_record.get("statement")), "user acceptance record is complete")
    file_results = []
    for item in manifest["files"]:
        path = accepted_run / item["path"]
        file_results.append(path.is_file() and sha(path) == item["sha256"] and path.stat().st_size == item["size"])
    check("UA-H09-MANIFEST", all(file_results), f"{sum(file_results)}/{len(file_results)} committed files match")

    failed = [item["check_id"] for item in checks if item["status"] != "passed"]
    report = {
        "schema_version": "user-acceptance-independent-validation/1.0",
        "acceptance_run": args.acceptance_run,
        "spec_status": "passed" if not failed else "failed",
        "acceptance_status": accepted["acceptance_status"],
        "checks": checks,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_checks": failed},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
