#!/usr/bin/env python3
"""Independent validation for a stable ElegantBookCompiler release snapshot."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    manifest = load(args.manifest)
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "passed" if condition else "failed", "detail": detail})

    check("schema", manifest.get("schema_version") == "elegantbookcompiler-stable-release/1.0", manifest.get("schema_version"))
    check("stable_identity", manifest.get("release") == "v1.0.0" and manifest.get("status") == "stable_release", {"release": manifest.get("release"), "status": manifest.get("status")})
    check("immutable", manifest.get("immutable_after_creation") is True, manifest.get("immutable_after_creation"))
    check("not_false_mature", manifest.get("project_mature") is False, manifest.get("project_mature"))
    check("all_gates", bool(manifest.get("gates")) and all(manifest.get("gates", {}).values()), manifest.get("gates"))
    totals = manifest.get("test_totals", {})
    check("tests", totals.get("tests", 0) > 0 and totals.get("failures") == 0 and totals.get("errors") == 0, totals)
    template = workspace / manifest.get("fixed_template", {}).get("path", "")
    check("fixed_template", template.is_file() and sha256(template) == manifest.get("fixed_template", {}).get("sha256"), manifest.get("fixed_template"))

    evidence_failures = []
    for name, item in manifest.get("evidence", {}).items():
        path = workspace / item.get("path", "")
        if not path.is_file() or sha256(path) != item.get("sha256"):
            evidence_failures.append(name)
    check("evidence_hashes", not evidence_failures, evidence_failures)

    package_ref = manifest.get("portable_package", {})
    package = args.manifest.parent / package_ref.get("path", "")
    package_ok = package.is_file() and sha256(package) == package_ref.get("sha256")
    check("portable_package_hash", package_ok, package_ref)
    inventory_failures: list[str] = []
    cli_version = ""
    if package_ok:
        with zipfile.ZipFile(package) as bundle:
            names = bundle.namelist()
            safe = all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in names)
            check("portable_package_safe_paths", safe, len(names))
            package_manifest = json.loads(bundle.read("PACKAGE-MANIFEST.json"))
            for item in package_manifest.get("files", []):
                data = bundle.read(item["path"])
                if hashlib.sha256(data).hexdigest() != item["sha256"]:
                    inventory_failures.append(item["path"])
            cli_text = bundle.read("workspace/scripts/elegantbookcompiler.py").decode("utf-8")
            cli_version = 'VERSION = "1.0.0"' if 'VERSION = "1.0.0"' in cli_text else "missing"
    else:
        check("portable_package_safe_paths", False, "package missing or hash mismatch")
    check("portable_package_inventory", not inventory_failures, inventory_failures)
    check("stable_cli_version", cli_version == 'VERSION = "1.0.0"', cli_version)

    accepted = manifest.get("sample_qualification", [])
    check("four_human_accepted_samples", len(accepted) == 4 and all(item.get("human_accepted") is True and item.get("acceptance_status") == "human_accepted" for item in accepted), accepted)
    failed = [item["name"] for item in checks if item["status"] == "failed"]
    report = {
        "schema_version": "elegantbookcompiler-stable-release-validation/1.0",
        "release": manifest.get("release"),
        "status": "passed" if not failed else "failed",
        "manifest_sha256": sha256(args.manifest),
        "checks": checks,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_checks": failed},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
