#!/usr/bin/env python3
"""Promote an accepted RC into an immutable, portable stable release."""

from __future__ import annotations

import argparse
import hashlib
import json
import stat
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


RELEASE = "v1.0.0"
PACKAGE_NAME = "elegantbookcompiler-v1.0.0.zip"
SKIP_PARTS = {"__pycache__", ".pytest_cache", ".DS_Store"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SystemExit(f"JSON root must be an object: {path}")
    return value


def dump(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def relative_ref(path: Path, workspace: Path) -> dict[str, str]:
    return {"path": path.resolve().relative_to(workspace).as_posix(), "sha256": sha256(path)}


def junit_counts(path: Path) -> dict[str, int]:
    import xml.etree.ElementTree as ET

    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
    return {
        key: sum(int(suite.attrib.get(key, "0")) for suite in suites)
        for key in ("tests", "failures", "errors", "skipped")
    }


def iter_skill_files(skill_root: Path) -> Iterable[Path]:
    for path in sorted(item for item in skill_root.rglob("*") if item.is_file()):
        if any(part in SKIP_PARTS for part in path.relative_to(skill_root).parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        yield path


def package_entries(
    workspace: Path,
    code_surface: dict[str, Any],
    architecture: dict[str, Any],
    requirements_lock: Path,
    dependency_requirements: Path,
) -> list[tuple[Path, str]]:
    entries: dict[str, Path] = {}

    def add(source: Path, archive_name: str) -> None:
        if not source.is_file():
            raise SystemExit(f"release package input is missing: {source}")
        normalized = Path(archive_name).as_posix().lstrip("/")
        if normalized in entries and entries[normalized] != source:
            raise SystemExit(f"duplicate release package path: {normalized}")
        entries[normalized] = source

    for raw in code_surface.get("workspace_files", []):
        add(workspace / raw, f"workspace/{raw}")
    for path in sorted((workspace / "specs").glob("*.md")):
        add(path, f"workspace/specs/{path.name}")
    for path in sorted((workspace / "profiles").glob("*.json")):
        add(path, f"workspace/profiles/{path.name}")
    add(workspace / "AGENTS.md", "workspace/AGENTS.md")
    add(workspace / "2025教材模版新版.zip", "workspace/2025教材模版新版.zip")
    add(requirements_lock, "workspace/release/requirements-v1.lock")
    add(dependency_requirements, "workspace/release/dependency_requirements.json")
    for skill_name, snapshot in sorted(architecture.get("skill_snapshots", {}).items()):
        skill_file = Path(snapshot["path"]).resolve()
        skill_root = skill_file.parent
        for path in iter_skill_files(skill_root):
            add(path, f"skills/{skill_name}/{path.relative_to(skill_root).as_posix()}")
    return [(source, name) for name, source in sorted(entries.items())]


def build_package(package_path: Path, entries: list[tuple[Path, str]]) -> dict[str, Any]:
    inventory = [
        {"path": archive_name, "sha256": sha256(source), "bytes": source.stat().st_size}
        for source, archive_name in entries
    ]
    package_manifest = {
        "schema_version": "elegantbookcompiler-portable-package/1.0",
        "release": RELEASE,
        "files": inventory,
    }
    with zipfile.ZipFile(package_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for source, archive_name in entries:
            info = zipfile.ZipInfo(archive_name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            bundle.writestr(info, source.read_bytes())
        info = zipfile.ZipInfo("PACKAGE-MANIFEST.json", date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        bundle.writestr(info, json.dumps(package_manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return package_manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--candidate-current", type=Path, required=True)
    parser.add_argument("--candidate-manifest", type=Path, required=True)
    parser.add_argument("--candidate-validation", type=Path, required=True)
    parser.add_argument("--acceptance", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--matrix-validation", type=Path, required=True)
    parser.add_argument("--scope", type=Path, required=True)
    parser.add_argument("--architecture", type=Path, required=True)
    parser.add_argument("--code-surface", type=Path, required=True)
    parser.add_argument("--requirements-lock", type=Path, required=True)
    parser.add_argument("--dependency-requirements", type=Path, required=True)
    parser.add_argument("--dependency-validation", type=Path, required=True)
    parser.add_argument("--hardcoding-report", type=Path, required=True)
    parser.add_argument("--recompile-report", type=Path, required=True)
    parser.add_argument("--workspace-tests", type=Path, required=True)
    parser.add_argument("--spec01-04-tests", type=Path, required=True)
    parser.add_argument("--spec05-tests", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    output = args.output_dir.resolve()
    if output.exists() and any(output.iterdir()):
        raise SystemExit(f"refusing to overwrite stable release snapshot: {output}")
    output.mkdir(parents=True, exist_ok=True)

    current = load(args.candidate_current)
    candidate = load(args.candidate_manifest)
    candidate_validation = load(args.candidate_validation)
    acceptance = load(args.acceptance)
    matrix = load(args.matrix)
    matrix_validation = load(args.matrix_validation)
    scope = load(args.scope)
    architecture = load(args.architecture)
    code_surface = load(args.code_surface)
    dependency_validation = load(args.dependency_validation)
    hardcoding = load(args.hardcoding_report)
    recompile = load(args.recompile_report)

    tests = {
        "workspace": junit_counts(args.workspace_tests),
        "spec01_04": junit_counts(args.spec01_04_tests),
        "spec05": junit_counts(args.spec05_tests),
    }
    totals = {
        key: sum(report[key] for report in tests.values())
        for key in ("tests", "failures", "errors", "skipped")
    }
    accepted_samples = [
        sample for sample in matrix.get("samples", [])
        if sample.get("expected", {}).get("acceptance_status") == "human_accepted"
        and sample.get("expected", {}).get("human_accepted") is True
    ]
    prerequisites = {
        "candidate_current_accepted": current.get("human_acceptance_claim") is True,
        "candidate_manifest_validated": candidate_validation.get("status") == "passed",
        "candidate_release_matches": candidate.get("release") == "v1.0.0-rc1",
        "release_acceptance": acceptance.get("acceptance_status") == "human_accepted_as_v1_capability_baseline",
        "four_samples_human_accepted": len(accepted_samples) == 4,
        "matrix_validation": matrix_validation.get("status") == "passed" and matrix_validation.get("summary", {}).get("failed") == 0,
        "scope_frozen": scope.get("requirements_status") == "frozen",
        "architecture_approved": architecture.get("status") == "approved_by_evidence_for_release_engineering",
        "dependency_validation": dependency_validation.get("status") == "passed",
        "hardcoding": hardcoding.get("status") == "passed" and hardcoding.get("summary", {}).get("violations") == 0,
        "recompile": recompile.get("status") == "passed" and recompile.get("summary", {}).get("failed") == 0,
        "tests": totals["tests"] > 0 and totals["failures"] == 0 and totals["errors"] == 0,
    }
    if not all(prerequisites.values()):
        raise SystemExit(f"stable release prerequisites not passed: {prerequisites}")

    template = workspace / "2025教材模版新版.zip"
    if sha256(template) != matrix.get("fixed_template", {}).get("sha256"):
        raise SystemExit("fixed template hash does not match accepted regression matrix")

    entries = package_entries(workspace, code_surface, architecture, args.requirements_lock, args.dependency_requirements)
    package_path = output / PACKAGE_NAME
    package_manifest = build_package(package_path, entries)
    package_inventory_path = output / "package_inventory.json"
    dump(package_inventory_path, package_manifest)

    evidence_paths = {
        "candidate_current": args.candidate_current,
        "candidate_manifest": args.candidate_manifest,
        "candidate_validation": args.candidate_validation,
        "release_acceptance": args.acceptance,
        "accepted_regression_matrix": args.matrix,
        "accepted_regression_validation": args.matrix_validation,
        "support_scope": args.scope,
        "architecture_ruling": args.architecture,
        "code_surface": args.code_surface,
        "requirements_lock": args.requirements_lock,
        "dependency_requirements": args.dependency_requirements,
        "dependency_validation": args.dependency_validation,
        "hardcoding_report": args.hardcoding_report,
        "recompile_report": args.recompile_report,
        "workspace_tests": args.workspace_tests,
        "spec01_04_tests": args.spec01_04_tests,
        "spec05_tests": args.spec05_tests,
        "package_inventory": package_inventory_path,
    }
    manifest = {
        "schema_version": "elegantbookcompiler-stable-release/1.0",
        "release": RELEASE,
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "status": "stable_release",
        "published": False,
        "project_mature": False,
        "fixed_template": matrix["fixed_template"],
        "support_scope_id": scope.get("scope_id"),
        "support_scope_status": "stable_within_frozen_v1_scope",
        "sample_qualification": [
            {
                "sample_id": sample["sample_id"],
                "family": sample["family"],
                "language": sample["language"],
                "pipeline_class": sample["pipeline_class"],
                "acceptance_status": sample["expected"]["acceptance_status"],
                "human_accepted": sample["expected"]["human_accepted"],
            }
            for sample in matrix["samples"]
        ],
        "gates": prerequisites,
        "test_totals": totals,
        "portable_package": {"path": PACKAGE_NAME, "sha256": sha256(package_path), "bytes": package_path.stat().st_size},
        "evidence": {name: relative_ref(path, workspace) for name, path in evidence_paths.items()},
        "unsupported_or_unverified": scope.get("unsupported_in_v1", []) + scope.get("experimental_or_unverified", []),
        "claim_boundary": "Stable and production-publishable only within the frozen v1 support scope. Stable does not imply project_mature or support for unverified material families, languages, layouts, or throughput.",
        "immutable_after_creation": True,
    }
    dump(output / "release_manifest.json", manifest)
    (output / "release_notes.md").write_text(
        "\n".join(
            [
                "# ElegantBookCompiler v1.0.0",
                "",
                "Status: `stable_release` within the frozen v1 support scope.",
                "",
                f"- Fixed template SHA-256: `{matrix['fixed_template']['sha256']}`",
                f"- Human-accepted representative samples: {len(accepted_samples)}",
                f"- Tests: {totals['tests']} passed, {totals['failures']} failures, {totals['errors']} errors",
                f"- Portable package SHA-256: `{sha256(package_path)}`",
                "- The stable release does not by itself establish `project_mature`.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
