#!/usr/bin/env python3
"""Capture and validate the exact Python, host, TeX, template, and skill runtime."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(argv: list[str]) -> dict[str, Any]:
    result = subprocess.run(argv, text=True, capture_output=True, check=False)
    return {
        "argv": argv,
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def parse_lock(path: Path) -> dict[str, str]:
    packages = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "==" not in line:
            raise ValueError(f"unlocked requirement: {line}")
        name, version = line.split("==", 1)
        packages[name] = version
    return packages


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--requirements", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    expected = json.loads(args.requirements.read_text(encoding="utf-8"))
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "passed" if condition else "failed", "detail": detail})

    py_expected = expected["python"]
    python_actual = {
        "executable": sys.executable,
        "implementation": platform.python_implementation(),
        "version": platform.python_version(),
        "version_detail": sys.version,
    }
    check("python_runtime", python_actual["implementation"] == py_expected["implementation"] and python_actual["version"] == py_expected["version"], python_actual)

    package_lock = workspace / expected["packages_lock"]
    locked = parse_lock(package_lock)
    actual_packages = {}
    package_mismatches = []
    for name, version in locked.items():
        try:
            actual = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual = None
        actual_packages[name] = actual
        if actual != version:
            package_mismatches.append({"package": name, "expected": version, "actual": actual})
    check("python_packages", not package_mismatches, package_mismatches)

    tool_commands = {
        "pdfinfo": ["pdfinfo", "-v"],
        "pdftocairo": ["pdftocairo", "-v"],
        "pdftoppm": ["pdftoppm", "-v"],
        "docker": ["docker", "--version"],
    }
    tools = {}
    for name, argv in tool_commands.items():
        executable = shutil.which(argv[0])
        result = run(argv) if executable else {"returncode": 127, "stdout": "", "stderr": "not found", "argv": argv}
        combined = "\n".join(item for item in (result["stdout"], result["stderr"]) if item)
        tools[name] = {"path": executable, "version_output": combined, "returncode": result["returncode"]}
        check(f"host_tool:{name}", result["returncode"] == 0 and expected["host_tools"][name] in combined, tools[name])

    compile_expected = expected["compile_runtime"]
    image = run(["docker", "inspect", "--format", "{{.Image}}", compile_expected["container"]])
    xelatex = run(["docker", "exec", compile_expected["container"], "sh", "-lc", "xelatex --version | head -2"])
    latexmk = run(["docker", "exec", compile_expected["container"], "sh", "-lc", "latexmk -v | head -2"])
    check("container_image", image["returncode"] == 0 and image["stdout"] == compile_expected["image_id"], image)
    check("container_xelatex", xelatex["returncode"] == 0 and compile_expected["xelatex_contains"] in xelatex["stdout"], xelatex)
    check("container_latexmk", latexmk["returncode"] == 0 and compile_expected["latexmk_contains"] in latexmk["stdout"], latexmk)

    template = workspace / expected["fixed_template"]["path"]
    check("fixed_template", template.is_file() and sha256(template) == expected["fixed_template"]["sha256"], expected["fixed_template"])
    architecture_path = workspace / expected["architecture_ruling"]
    architecture = json.loads(architecture_path.read_text(encoding="utf-8"))
    skill_failures = []
    for name, item in architecture.get("skill_snapshots", {}).items():
        path = Path(item["path"])
        if not path.is_file() or sha256(path) != item["sha256"]:
            skill_failures.append(name)
    check("skill_snapshots", not skill_failures, skill_failures)

    failed = [item["name"] for item in checks if item["status"] == "failed"]
    output = {
        "schema_version": "elegantbookcompiler-dependency-lock/1.0",
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "status": "passed" if not failed else "failed",
        "requirements": {"path": str(args.requirements.resolve()), "sha256": sha256(args.requirements)},
        "packages_lock": {"path": str(package_lock), "sha256": sha256(package_lock), "packages": actual_packages},
        "python": python_actual,
        "host_tools": tools,
        "compile_runtime": {"container": compile_expected["container"], "image": image, "xelatex": xelatex, "latexmk": latexmk},
        "template": expected["fixed_template"],
        "skill_snapshots": architecture.get("skill_snapshots", {}),
        "checks": checks,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_checks": failed},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
