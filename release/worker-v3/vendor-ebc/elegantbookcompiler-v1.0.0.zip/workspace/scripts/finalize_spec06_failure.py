#!/usr/bin/env python3
"""Freeze an evidence-bound failed Spec 06 review.

This finalizer is intentionally conservative: it closes human review decisions
without turning confirmed defects into waivers.  It creates neither a
``final_verified`` ledger nor an acceptance commit.
"""

from __future__ import annotations

import argparse
import html
import json
import shutil
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from finalize_spec06_pass import (
    apply_source_page_mapping_corrections,
    exact_files,
    read,
    rel,
    require,
    sha,
    write,
    writel,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--diagnostic-run", required=True)
    parser.add_argument("--visual-run", required=True)
    parser.add_argument("--semantic-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--coverage-run", required=True)
    parser.add_argument("--review-config", required=True, type=Path)
    parser.add_argument("--output-run", required=True)
    parser.add_argument("--decision-index-snapshot-id")
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    diagnostic = sample / "runs" / args.diagnostic_run
    visual = sample / "runs" / args.visual_run
    semantic = sample / "runs" / args.semantic_run
    compile_run = sample / "runs" / args.compile_run
    coverage = sample / "runs" / args.coverage_run
    config_path = args.review_config.resolve()
    out = sample / "runs" / args.output_run
    require(not out.exists(), f"immutable output already exists: {out}")
    for directory in ("decisions", "reports", "qa", "review", "manifests"):
        (out / directory).mkdir(parents=True, exist_ok=False)

    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    config = read(config_path)
    diagnostic_page_review = read(diagnostic / "reports/page_review.json")
    diagnostic_queue = read(diagnostic / "qa/human_review_queue.json")
    diagnostic_anomalies = read(diagnostic / "reports/automated_anomalies.json")
    review_manifest = read(diagnostic / "manifests/review_pack_manifest.json")
    build_manifest = read(compile_run / "manifests/build_manifest.json")
    compile_report = read(compile_run / "reports/compile_report.json")
    template_report = read(compile_run / "reports/template_integrity_final_report.json")
    semantic_manifest_path = semantic / "manifests/semantic_stage_manifest.json"
    if not semantic_manifest_path.exists():
        semantic_manifest_path = semantic / "manifests/spec04d_render_plan_stage_manifest.json"
    semantic_manifest = read(semantic_manifest_path)
    parent_index_path = coverage / "decisions/canonical_decision_index.json"
    parent_ledger_manifest_path = coverage / "ledgers/ledger_manifest.json"
    parent_index = read(parent_index_path)
    parent_ledger_manifest = read(parent_ledger_manifest_path)

    final_pdf = compile_run / build_manifest["artifacts"]["final_pdf"]["path"]
    final_zip = compile_run / build_manifest["artifacts"]["formal_zip"]["path"]
    render_manifest_path = compile_run / build_manifest["artifacts"]["render_pack"]["path"]
    render_manifest = read(render_manifest_path)
    pdf_hash, zip_hash = sha(final_pdf), sha(final_zip)
    bindings = config["bindings"]

    require(config.get("review_outcome") == "failed", "failure finalizer requires review_outcome=failed")
    require(config.get("all_pages_human_reviewed") is True, "all-page human review attestation is required")
    require(bindings["source_pdf_sha256"] == diagnostic_page_review["source_pdf_sha256"], "source binding mismatch")
    require(bindings["final_pdf_sha256"] == pdf_hash, "final PDF binding mismatch")
    require(bindings["final_zip_sha256"] == zip_hash, "final ZIP binding mismatch")
    require(bindings["build_id"] == build_manifest["build_id"], "build binding mismatch")
    require(bindings["render_coverage_ledger_snapshot_id"] == parent_ledger_manifest["snapshot_id"], "ledger binding mismatch")
    require(review_manifest["final_pdf_sha256"] == pdf_hash, "diagnostic review pack belongs to another PDF")
    require(review_manifest["summary"]["final_pages"] == compile_report["pdf"]["pages"] == render_manifest["page_count"], "page-count binding mismatch")
    require(semantic_manifest["status"] == "passed" and semantic_manifest.get("full_spec04_status", "passed") == "passed", "input Spec 04 snapshot is not passed")
    require(compile_report["spec_status"] == "passed" and template_report["status"] == "passed", "input Spec 05 is not passed")
    require(parent_ledger_manifest["spec_status"] == "passed" and parent_ledger_manifest["ledger_checkpoint"] == "render_coverage", "input render coverage is not passed")
    require(parent_index["summary"]["open"] == 0 and parent_index["summary"]["invalidated"] == 0, "parent decision index is unresolved")

    contact_root = compile_run / "final_render_pack/contact_sheets"
    if contact_root.is_dir():
        contact_files = exact_files(contact_root, "sheet-*.jpg")
    else:
        contact_root = visual / "all_pages"
        contact_files = exact_files(contact_root, "pages-*.jpg")
    risk_files = exact_files(visual / "risk_pages", "*.jpg")
    mapping_files = exact_files(visual / "source_mapping", "*.jpg")
    require(sorted(config["reviewed_contact_sheet_files"]) == contact_files, "contact-sheet review enumeration mismatch")
    require(sorted(config["reviewed_risk_board_files"]) == risk_files, "risk-board review enumeration mismatch")
    require(sorted(config["reviewed_source_mapping_files"]) == mapping_files, "source-mapping review enumeration mismatch")
    require(config["reviewed_page_count"] == diagnostic_page_review["page_count"], "reviewed page count mismatch")
    require(config["reviewed_risk_page_count"] == len(diagnostic_page_review["risk_pages"]), "reviewed risk-page count mismatch")

    source_page_coverage = read(diagnostic / "reports/source_page_coverage.json")
    source_block_coverage = read(diagnostic / "reports/source_block_coverage.json")
    source_by_page = {item["source_pdf_page"]: item for item in source_page_coverage["pages"]}
    final_by_page = {item["physical_page"]: item for item in diagnostic_page_review["pages"]}
    reading_order = read(diagnostic / "reports/reading_order_audit.json")
    formula_audit = read(diagnostic / "reports/formula_table_image_audit.json")
    semantic_audit = read(diagnostic / "reports/semantic_mapping_audit.json")
    toc_audit = read(diagnostic / "reports/toc_page_number_audit.json")
    mapping_corrections = apply_source_page_mapping_corrections(
        source_page_coverage,
        source_block_coverage,
        diagnostic_page_review,
        config.get("source_page_mapping_corrections", []),
    )

    semantic_resolutions = config.get("semantic_candidate_resolutions", [])
    resolution_by_node = {item["render_node_id"]: item for item in semantic_resolutions}
    resolved_semantic = []
    for candidate in semantic_audit["heading_orphan_candidates"]:
        resolution = resolution_by_node.get(candidate["render_node_id"])
        require(resolution is not None, f"semantic candidate is unresolved: {candidate['render_node_id']}")
        require(resolution["status"] == "closed" and resolution["classification"] in {"V2", "V3"}, "invalid semantic candidate resolution")
        resolved_semantic.append({**candidate, **resolution})
    require(set(resolution_by_node) == {item["render_node_id"] for item in semantic_audit["heading_orphan_candidates"]}, "semantic resolution references an unknown candidate")
    semantic_audit["resolved_heading_orphan_candidates"] = resolved_semantic
    semantic_audit["heading_orphan_candidates"] = []

    confirmed = config["confirmed_defects"]
    require(confirmed, "at least one confirmed defect is required")
    toc_by_node = {entry["render_node_id"]: entry for entry in toc_audit["entries"]}
    confirmed_toc = []
    confirmed_source_fidelity = []
    supported_source_defect_types = {
        "source_visual_region_missing",
        "media_crop_contamination",
        "composite_media_reading_order_violation",
    }
    for defect in confirmed:
        require(defect["severity"] in {"V0", "V1", "V2"}, "only blocking defects belong in a failed Spec 06 snapshot")
        require(defect["status"] == "confirmed", "confirmed defect status is required")
        if defect["type"] == "missing_toc_entries":
            for node_id in defect["render_node_ids"]:
                require(node_id in toc_by_node, f"unknown TOC node: {node_id}")
                require(toc_by_node[node_id]["status"] == "needs_review", f"TOC node is no longer missing: {node_id}")
                confirmed_toc.append({
                    **toc_by_node[node_id],
                    "status": "failed_confirmed_v1",
                    "decision_ref": "DEC-FR6-FAIL-002",
                    "confirmed_defect_id": defect["defect_id"],
                })
        elif defect["type"] in supported_source_defect_types:
            source_pages = defect.get("source_pdf_pages", [])
            final_pages = defect.get("final_pdf_pages", [])
            require(source_pages and final_pages, f"{defect['type']} requires source_pdf_pages and final_pdf_pages")
            require(all(page in source_by_page for page in source_pages), f"unknown source page in {defect['defect_id']}")
            require(all(page in final_by_page for page in final_pages), f"unknown final page in {defect['defect_id']}")
            require(defect.get("owner_stage"), f"missing owner_stage in {defect['defect_id']}")
            require(defect.get("reason"), f"missing reason in {defect['defect_id']}")
            require(defect.get("evidence_refs"), f"missing evidence_refs in {defect['defect_id']}")
            confirmed_source_fidelity.append(defect)
        else:
            raise SystemExit(f"unsupported confirmed defect type: {defect['type']}")
    require(confirmed_toc or confirmed_source_fidelity, "the configured failure has no supported confirmed defect")

    if confirmed_toc and not confirmed_source_fidelity:
        blocker_rule = "FR-H14"
        blocker_decision = f"Confirmed {len(confirmed_toc)} source-required TOC entries absent from both the visible final TOC and PDF outline."
    else:
        blocker_rule = "SPEC06-CONFIRMED-SOURCE-FIDELITY"
        blocker_decision = f"Confirmed {len(confirmed_source_fidelity)} source-fidelity defect families after all-page visual review."
    blocker_reason = " | ".join(f"{item['defect_id']}: {item['reason']}" for item in confirmed)
    blocker_evidence = [
        {"defect_id": item["defect_id"], **ref}
        for item in confirmed
        for ref in item["evidence_refs"]
    ]

    decision_rows = [
        {
            "decision_id": "DEC-FR6-FAIL-001",
            "event_type": "human_review_decision",
            "stage": "final_page_review",
            "status": "closed",
            "rule_id": "SPEC06-ALL-PAGES",
            "decision": f"All {diagnostic_page_review['page_count']} final pages and every enumerated risk/source board were reviewed.",
            "reason": "Evidence-bound visual review under the workspace contract.",
            "decider": config["reviewer"],
            "decided_at": timestamp,
            "applies_to": {"build_id": build_manifest["build_id"], "final_pdf_sha256": pdf_hash, "final_zip_sha256": zip_hash},
            "evidence_refs": [{"path": rel(out, visual / "manifest.json"), "sha256": sha(visual / "manifest.json")}],
            "supersedes": [],
            "invalidated_by": None,
        },
        {
            "decision_id": "DEC-FR6-FAIL-002",
            "event_type": "human_review_decision",
            "stage": "final_page_review",
            "status": "closed",
            "rule_id": blocker_rule,
            "decision": blocker_decision,
            "reason": blocker_reason,
            "decider": config["reviewer"],
            "decided_at": timestamp,
            "applies_to": {
                "build_id": build_manifest["build_id"],
                "final_pdf_sha256": pdf_hash,
                "render_node_ids": [item["render_node_id"] for item in confirmed_toc],
                "source_pdf_pages": sorted({page for item in confirmed_source_fidelity for page in item["source_pdf_pages"]}),
                "final_pdf_pages": sorted({page for item in confirmed_source_fidelity for page in item["final_pdf_pages"]}),
            },
            "evidence_refs": blocker_evidence,
            "supersedes": [],
            "invalidated_by": None,
        },
        {
            "decision_id": "DEC-FR6-FAIL-003",
            "event_type": "human_review_decision",
            "stage": "final_page_review",
            "status": "closed",
            "rule_id": "SPEC06-OUTCOME",
            "decision": "Spec 06 is failed; final_verified ledger and acceptance commit are prohibited for this build.",
            "reason": "At least one confirmed blocking final-product defect remains.",
            "decider": config["reviewer"],
            "decided_at": timestamp,
            "applies_to": {"build_id": build_manifest["build_id"], "final_pdf_sha256": pdf_hash},
            "evidence_refs": [{"path": "reports/toc_page_number_audit.json"}],
            "supersedes": [],
            "invalidated_by": None,
        },
    ]
    decisions_path = out / "decisions/final_decisions.jsonl"
    writel(decisions_path, decision_rows)

    finalized_pages = []
    risk_pages = set(diagnostic_page_review["risk_pages"])
    confirmed_final_pages = {
        page: defect
        for defect in confirmed_source_fidelity
        for page in defect["final_pdf_pages"]
    }
    for page in diagnostic_page_review["pages"]:
        refs = ["DEC-FR6-FAIL-001"]
        findings = list(page["automatic_findings"])
        if int(page["physical_page"]) in risk_pages:
            findings = [f"{item}:visually_reviewed_nonblocking" for item in findings]
        confirmed_defect = confirmed_final_pages.get(int(page["physical_page"]))
        if confirmed_defect:
            refs.append("DEC-FR6-FAIL-002")
            findings.append(f"confirmed:{confirmed_defect['defect_id']}")
        finalized_pages.append({
            **page,
            "automatic_findings": findings,
            "page_status": "failed_confirmed_blocker" if confirmed_defect else "human_reviewed_no_additional_blocker",
            "human_review_status": "closed",
            "human_decision_refs": refs,
            "confirmed_severity": confirmed_defect["severity"] if confirmed_defect else None,
            "confirmed_defect_id": confirmed_defect["defect_id"] if confirmed_defect else None,
        })
    page_ledger_path = out / "reports/final_page_hash_ledger.jsonl"
    writel(page_ledger_path, finalized_pages)

    queue_items = []
    for item in diagnostic_queue["items"]:
        row = dict(item)
        if row["type"] == "toc_and_bookmark_review" and confirmed_toc:
            row.update({"status": "closed", "resolution": "confirmed_v1_missing_toc_entries", "decision_refs": ["DEC-FR6-FAIL-002"]})
        elif row["type"] == "source_page_mapping_review" and mapping_corrections:
            row.update({"status": "closed", "resolution": "human_visual_mapping_correction_applied", "decision_refs": ["DEC-FR6-FAIL-001"]})
        else:
            row.update({"status": "closed", "resolution": "visually_reviewed_no_additional_blocker", "decision_refs": ["DEC-FR6-FAIL-001"]})
        queue_items.append(row)
    for defect in confirmed_source_fidelity:
        queue_items.append({
            "item_id": f"confirmed::{defect['defect_id']}",
            "type": "confirmed_source_fidelity_defect",
            "status": "closed",
            "resolution": "confirmed_blocking_defect_routed_to_owner_stage",
            "severity": defect["severity"],
            "source_pdf_pages": defect["source_pdf_pages"],
            "final_pdf_pages": defect["final_pdf_pages"],
            "owner_stage": defect["owner_stage"],
            "decision_refs": ["DEC-FR6-FAIL-002"],
        })
    queue = {
        "schema_version": "human-review-queue/1.0-finalized-failed",
        "generated_at": timestamp,
        "spec_status": "failed",
        "open_count": 0,
        "closed_count": len(queue_items),
        "resolution_counts": dict(Counter(item["resolution"] for item in queue_items)),
        "items": queue_items,
    }
    write(out / "qa/human_review_queue.json", queue)

    if confirmed_toc:
        for entry in toc_audit["entries"]:
            if entry["render_node_id"] in {item["render_node_id"] for item in confirmed_toc}:
                entry["status"] = "failed_confirmed_v1"
                entry["decision_ref"] = "DEC-FR6-FAIL-002"
        toc_audit.update({
            "generated_at": timestamp,
            "spec_status": "failed",
            "status": "failed",
            "needs_review": 0,
            "failed": len(confirmed_toc),
            "confirmed_missing_entries": confirmed_toc,
        })
        semantic_audit.update({
            "generated_at": timestamp,
            "spec_status": "failed",
            "status": "failed",
            "semantic_candidate_resolutions": semantic_resolutions,
            "confirmed_template_capability_conflicts": [item for item in confirmed if item["type"] == "missing_toc_entries"],
        })
    else:
        toc_audit.update({"generated_at": timestamp, "spec_status": "passed", "status": "passed", "needs_review": 0, "failed": 0})
        semantic_audit.update({
            "generated_at": timestamp,
            "spec_status": "passed",
            "status": "passed",
            "semantic_candidate_resolutions": semantic_resolutions,
        })

    if confirmed_source_fidelity:
        source_page_coverage.update({
            "spec_status": "failed",
            "status": "failed",
            "confirmed_visual_source_omissions": [item for item in confirmed_source_fidelity if item["type"] == "source_visual_region_missing"],
        })
        source_block_coverage.update({
            "spec_status": "failed",
            "status": "failed",
            "source_ledger_completeness_invalidated_by_visual_review": True,
            "confirmed_source_fidelity_defects": confirmed_source_fidelity,
        })
        formula_audit.update({
            "generated_at": timestamp,
            "spec_status": "failed",
            "status": "failed",
            "visual_source_region_review": "failed",
            "confirmed_source_fidelity_defects": confirmed_source_fidelity,
        })
        if any(item.get("impairs_reading_relationships") for item in confirmed_source_fidelity):
            reading_order.update({
                "spec_status": "failed",
                "status": "failed",
                "confirmed_visual_relationship_defects": [item for item in confirmed_source_fidelity if item.get("impairs_reading_relationships")],
            })
    else:
        formula_audit.update({"generated_at": timestamp, "spec_status": "passed", "status": "passed", "visual_source_region_review": "passed"})
    for name, value in (
        ("source_page_coverage.json", source_page_coverage),
        ("source_block_coverage.json", source_block_coverage),
        ("reading_order_audit.json", reading_order),
        ("formula_table_image_audit.json", formula_audit),
        ("semantic_mapping_audit.json", semantic_audit),
        ("toc_page_number_audit.json", toc_audit),
    ):
        write(out / "reports" / name, value)

    anomalies = {
        **diagnostic_anomalies,
        "schema_version": "automated-anomalies/1.0-finalized-failed",
        "generated_at": timestamp,
        "spec_status": "failed",
        "human_review_open_count": 0,
        "confirmed_v1_count": sum(item["severity"] == "V1" for item in confirmed),
        "anomalies": [
            *[{**item, "status": "visually_reviewed_nonblocking", "human_decision_ref": "DEC-FR6-FAIL-001"} for item in diagnostic_anomalies["anomalies"]],
            *(
                [{"anomaly_id": "CONF-TOC-CAPABILITY-001", "candidate_severity": "V1", "status": "confirmed", "finding": "source-required level-2 TOC entries are hidden by the frozen template tocdepth", "render_node_ids": [item["render_node_id"] for item in confirmed_toc], "decision_ref": "DEC-FR6-FAIL-002"}]
                if confirmed_toc else []
            ),
            *[
                {
                    "anomaly_id": f"CONF-{item['defect_id']}",
                    "candidate_severity": item["severity"],
                    "status": "confirmed",
                    "finding": item["reason"],
                    "source_pdf_pages": item["source_pdf_pages"],
                    "final_pdf_pages": item["final_pdf_pages"],
                    "owner_stage": item["owner_stage"],
                    "decision_ref": "DEC-FR6-FAIL-002",
                }
                for item in confirmed_source_fidelity
            ],
        ],
    }
    write(out / "reports/automated_anomalies.json", anomalies)

    configured_failed_gates = set(config.get("failed_hard_gates", []))
    if not configured_failed_gates:
        configured_failed_gates = {"FR-H01", "FR-H13", "FR-H14", "FR-H17"}
    allowed_failed_gates = {f"FR-H{number:02d}" for number in range(1, 19)}
    require(configured_failed_gates <= allowed_failed_gates, "failed_hard_gates contains an invalid or post-decision gate")
    gate_reason = config.get("hard_gate_failure_reason", blocker_reason)
    gate_matrix = []
    for number in range(1, 22):
        gate = f"FR-H{number:02d}"
        if gate in configured_failed_gates:
            status = "failed"
            reason = gate_reason
        elif gate in {"FR-H19", "FR-H20", "FR-H21"}:
            status = "not_created"
            reason = "failed prerequisites prohibit final decision freeze, final_verified ledger, and acceptance commit"
        else:
            status = "passed"
            reason = "bound diagnostic and completed human review found no blocker for this gate"
        gate_matrix.append({"gate": gate, "status": status, "reason": reason})

    page_review = {
        **diagnostic_page_review,
        "schema_version": "page-review/1.0-finalized-failed",
        "generated_at": timestamp,
        "spec_status": "failed",
        "acceptance_status": "not_ready",
        "all_pages_human_reviewed": True,
        "human_review_queue_open_count": 0,
        "confirmed_v1_defect_families": sum(item["severity"] == "V1" for item in confirmed),
        "confirmed_defects": confirmed,
        "residual_v3_notes": config.get("residual_v3_notes", []),
        "hard_gate_matrix": gate_matrix,
        "failure_codes": config.get("failure_codes", ["FINAL_TOC_SOURCE_STRUCTURE_MISSING", "FINAL_SEMANTIC_TEMPLATE_CAPABILITY_CONFLICT"]),
        "pages": finalized_pages,
        "scope_limit": "Failed review for the exact bound build; no final_verified ledger or acceptance commit exists.",
    }
    page_review_path = out / "reports/page_review.json"
    write(page_review_path, page_review)
    shutil.copy2(diagnostic / "review/page_contact_sheet.pdf", out / "review/page_contact_sheet.pdf")

    index_decisions = list(parent_index["decisions"]) + [
        {"decision_id": row["decision_id"], "event_file": "decisions/final_decisions.jsonl", "status": row["status"], "rule_id": row["rule_id"], "supersedes": [], "invalidated_by": None}
        for row in decision_rows
    ]
    decision_index = {
        "schema_version": parent_index["schema_version"],
        "snapshot_id": args.decision_index_snapshot_id or config["decision_index_snapshot_id"],
        "decision_index_id": config["decision_index_id"],
        "version": parent_index["version"] + 1,
        "generated_at": timestamp,
        "spec_status": "failed",
        "parent_index_ref": rel(out, parent_index_path),
        "parent_index_hash": sha(parent_index_path),
        "evidence_committed_before_index": True,
        "acyclic_commit_rule": parent_index["acyclic_commit_rule"],
        "decision_event_files": parent_index["decision_event_files"] + [{"path": "decisions/final_decisions.jsonl", "sha256": sha(decisions_path)}],
        "decisions": index_decisions,
        "summary": {
            "closed": sum(item["status"] == "closed" for item in index_decisions),
            "open": sum(item["status"] == "open" for item in index_decisions),
            "superseded": sum(item["status"] == "superseded" for item in index_decisions),
            "invalidated": sum(item["status"] == "invalidated" for item in index_decisions),
        },
    }
    index_path = out / "decisions/canonical_decision_index.json"
    write(index_path, decision_index)

    acceptance = {
        "schema_version": "final-acceptance-status/1.0",
        "generated_at": timestamp,
        "manifest_kind": "failure_status_not_acceptance_commit",
        "spec_status": "failed",
        "acceptance_status": "not_ready",
        "reason_code": config.get("acceptance_reason_code", "CONFIRMED_BLOCKING_SPEC06_DEFECT"),
        "build_id": build_manifest["build_id"],
        "source_pdf_sha256": bindings["source_pdf_sha256"],
        "final_pdf_sha256": pdf_hash,
        "final_zip_sha256": zip_hash,
        "render_coverage_ledger_snapshot_id": parent_ledger_manifest["snapshot_id"],
        "review_decision_index": {"snapshot_id": decision_index["snapshot_id"], "sha256": sha(index_path)},
        "page_review_sha256": sha(page_review_path),
        "final_decision_index_frozen_for_acceptance": False,
        "final_verified_ledger_created": False,
        "acceptance_commit_created": False,
        "human_accepted": False,
    }
    acceptance_path = out / "final_acceptance.json"
    write(acceptance_path, acceptance)

    failed_gates = [item for item in gate_matrix if item["status"] == "failed"]
    blocker_lines = [
        f"- `{item['defect_id']}` ({item['severity']}, `{item['type']}`), owner `{item['owner_stage']}`: {item['reason']}"
        for item in confirmed
    ]
    return_routes = config.get("required_return_route", [])
    if not return_routes:
        return_routes = [
            f"Return `{item['defect_id']}` to {item['owner_stage']}; do not patch the final LaTeX to hide the upstream defect."
            for item in confirmed
        ]
    report_lines = [
        "# Spec 06 final page review — failed",
        "",
        f"- Final PDF SHA-256: `{pdf_hash}`",
        f"- Final ZIP SHA-256: `{zip_hash}`",
        f"- Build: `{build_manifest['build_id']}`",
        f"- All {len(finalized_pages)} final pages and all {len(risk_files)} risk boards were reviewed.",
        "- Human review queue: `0` open items.",
        "- Acceptance: `not_ready`.",
        "",
        "## Confirmed blocker",
        "",
        *blocker_lines,
        "",
        "## Failed hard gates",
        "",
        *[f"- `{item['gate']}`: {item['reason']}" for item in failed_gates],
        "",
        "## Required return route",
        "",
        *[f"{index}. {item}" for index, item in enumerate(return_routes, start=1)],
        "",
        "No `final_verified` ledger and no acceptance commit were created.",
        "",
    ]
    report_text = "\n".join(report_lines)
    report_path = out / "reports/final_review_report.md"
    report_path.write_text(report_text, encoding="utf-8")
    (out / "final_acceptance.md").write_text(report_text, encoding="utf-8")

    html_rows = "".join(
        f"<tr><td>{page['physical_page']}</td><td>{html.escape(str(page['page_label']))}</td><td>{html.escape(page['page_status'])}</td></tr>"
        for page in finalized_pages
    )
    (out / "review/page_review.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>Spec 06 failed review</title>"
        "<style>body{font-family:sans-serif}table{border-collapse:collapse}td,th{border:1px solid #aaa;padding:4px}</style>"
        f"<h1>Spec 06: failed</h1><p>PDF: {pdf_hash}</p><p>All {len(finalized_pages)} pages reviewed; acceptance is not ready.</p>"
        f"<table><tr><th>Page</th><th>Label</th><th>Status</th></tr>{html_rows}</table>",
        encoding="utf-8",
    )

    manifest = {
        "schema_version": "spec06-failed-review-manifest/2.0",
        "generated_at": timestamp,
        "run_id": args.output_run,
        "spec_status": "failed",
        "acceptance_status": "not_ready",
        "build_id": build_manifest["build_id"],
        "source_pdf_sha256": bindings["source_pdf_sha256"],
        "final_pdf_sha256": pdf_hash,
        "final_zip_sha256": zip_hash,
        "render_manifest_sha256": sha(render_manifest_path),
        "render_coverage_ledger_snapshot_id": parent_ledger_manifest["snapshot_id"],
        "inputs": {
            "review_config": {"path": rel(out, config_path), "sha256": sha(config_path)},
            "diagnostic_review_pack": {"path": rel(out, diagnostic / "manifests/review_pack_manifest.json"), "sha256": sha(diagnostic / "manifests/review_pack_manifest.json")},
            "visual_evidence": {"path": rel(out, visual / "manifest.json"), "sha256": sha(visual / "manifest.json")},
            "parent_decision_index": {"path": rel(out, parent_index_path), "sha256": sha(parent_index_path)},
        },
        "summary": {
            "final_pages": len(finalized_pages),
            "human_reviewed_pages": len(finalized_pages),
            "open_human_reviews": 0,
            "confirmed_v1_defect_families": sum(item["severity"] == "V1" for item in confirmed),
            "confirmed_defect_families": len(confirmed),
            "failed_hard_gates": [item["gate"] for item in failed_gates],
            "final_verified_ledger_created": False,
            "acceptance_commit_created": False,
        },
        "files": [],
    }
    manifest_path = out / "manifests/failure_return_manifest.json"
    write(manifest_path, manifest)
    manifest["files"] = [
        {"path": path.relative_to(out).as_posix(), "sha256": sha(path), "size": path.stat().st_size}
        for path in sorted(out.rglob("*")) if path.is_file() and path != manifest_path
    ]
    write(manifest_path, manifest)
    print(json.dumps({"run": str(out), "spec_status": "failed", "acceptance_status": "not_ready", "summary": manifest["summary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
