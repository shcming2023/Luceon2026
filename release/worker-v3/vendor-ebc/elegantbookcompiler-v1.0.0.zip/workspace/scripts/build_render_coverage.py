#!/usr/bin/env python3
"""Create an immutable Spec 03 render_coverage checkpoint from frozen artifacts."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def chash(value: Any) -> str:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def rel(origin: Path, target: Path) -> str:
    return Path(os.path.relpath(target, origin)).as_posix()


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def writel(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def gate(value: bool, evidence: str) -> dict[str, Any]:
    return {"status": "passed" if value else "failed", "evidence": evidence}


def source_supported_virtual_structure(
    node: dict[str, Any],
    by_block: dict[str, dict[str, Any]],
    logical_ids: set[str],
    appearances: dict[str, list[str]],
) -> bool:
    """Accept a source-backed structural node that intentionally emits no atom.

    A structural title can be supported by a scope-excluded source title while an
    included body/media anchor is emitted separately.  Requiring the anchor to be
    media-only incorrectly rejects assessment and worksheet structures.  The
    invariant is instead that the visible title is source-supported and every
    included evidence atom is explicitly delegated and emitted exactly once.
    """
    payload = node.get("payload", {})
    evidence_ids = payload.get("source_evidence_block_ids", [])
    delegated_ids = set(payload.get("separate_body_block_ids", [])) | set(
        payload.get("media_evidence_block_ids", [])
    )
    if not (
        node.get("node_kind") == "book_structure"
        and not node.get("source_block_ids")
        and payload.get("structure_node_id")
        and evidence_ids
        and all(block_id in by_block for block_id in evidence_ids)
        and delegated_ids
        and delegated_ids.issubset(set(evidence_ids))
    ):
        return False

    included_evidence_ids = {block_id for block_id in evidence_ids if block_id in logical_ids}
    if included_evidence_ids != delegated_ids:
        return False
    if not all(len(appearances.get(block_id, [])) == 1 for block_id in delegated_ids):
        return False

    def normalized(value: Any) -> str:
        return " ".join(str(value or "").split()).casefold()

    title = normalized(payload.get("title"))
    title_fragments = [normalized(value) for value in payload.get("title_source_fragments", [])]
    evidence_texts = [normalized(by_block[block_id].get("raw_content")) for block_id in evidence_ids]
    return bool(title and (title in evidence_texts or title == " ".join(value for value in title_fragments if value)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--semantic-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--output-run", required=True)
    parser.add_argument("--ledger-snapshot-id", required=True)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    semantic = sample / "runs" / args.semantic_run
    compile_run = sample / "runs" / args.compile_run
    out = sample / "runs" / args.output_run
    if out.exists():
        raise SystemExit(f"immutable output already exists: {out}")
    for directory in ("decisions", "evidence", "ledgers", "manifests", "reports", "qa"):
        (out / directory).mkdir(parents=True, exist_ok=False)

    timestamp = now()
    parent_rows = read_jsonl(semantic / "ledgers/canonical_block_ledger.jsonl")
    parent_header, source_rows = parent_rows[0], parent_rows[1:]
    plan = read(semantic / "render/render_plan.json")
    spec04d_plan = plan.get("schema_version") == "render-plan/2.0"
    execution = read(compile_run / "reports/render_execution_report.json")
    asset_report = read(compile_run / "reports/asset_materialization_report.json")
    build = read(compile_run / "manifests/build_manifest.json")
    spec05_stage_candidates = [
        compile_run / "manifests/spec05_native_stage_manifest.json",
        compile_run / "manifests/spec05_stage_manifest.json",
    ]
    spec05_stage_path = next((path for path in spec05_stage_candidates if path.is_file()), None)
    if spec05_stage_path is None:
        raise SystemExit("missing supported Spec 05 stage manifest")
    spec05 = read(spec05_stage_path)
    parent_index_path = compile_run / "decisions/canonical_decision_index.json"
    parent_index = read(parent_index_path)

    by_block = {row["block_id"]: row for row in source_rows}
    logical_rows = [row for row in source_rows if row.get("scope_status") == "included" and (spec04d_plan or row.get("terminal_state") != "merged_duplicate_evidence")]
    duplicate_rows = [row for row in source_rows if row.get("terminal_state") == "merged_duplicate_evidence"]
    excluded_rows = [row for row in source_rows if row.get("scope_status") == "excluded"]
    plan_nodes = plan["nodes"]
    emissions = execution["emissions"]
    plan_by_id = {node["render_node_id"]: node for node in plan_nodes}
    emission_by_id = {item["render_node_id"]: item for item in emissions}

    appearances: dict[str, list[str]] = defaultdict(list)
    for node in plan_nodes:
        for block_id in node["source_block_ids"]:
            appearances[block_id].append(node["render_node_id"])

    project = compile_run / ("build/clean-src" if spec04d_plan else "formal_project")
    copied_assets = asset_report["copied_assets"]
    asset_nodes: list[dict[str, Any]] = []
    region_nodes: list[dict[str, Any]] = []
    asset_failures: list[str] = []
    def materialized_name(node: dict[str, Any]) -> str:
        payload = node["payload"]
        if payload.get("source_path"):
            stem = re.sub(r"[^A-Za-z0-9_-]+", "-", node["render_node_id"]).strip("-")
            return f"media-{stem}{Path(payload['source_path']).suffix.lower()}"
        return Path(payload["asset_ref"]).name
    for node in plan_nodes:
        construct = node["target_construct"]
        if construct == "source_asset_image":
            source_ref = node["payload"].get("source_path", node["payload"].get("asset_ref"))
            name = materialized_name(node)
            target = project / "images" / name
            report_item = copied_assets.get(name)
            binding = node.get("media_binding") or node["payload"].get("media_binding", {})
            ok = bool(target.exists() and report_item and sha(target) == report_item["sha256"] and (not binding or sha(target) == binding["artifact_sha256"]))
            asset_nodes.append({
                "render_node_id": node["render_node_id"],
                "source_block_ids": node["source_block_ids"],
                "representation": "source_asset_image",
                "output_ref": rel(out, target),
                "output_sha256": sha(target) if target.exists() else None,
                "source_asset_ref": source_ref,
                "status": "closed" if ok else "failed",
            })
            if not ok:
                asset_failures.append(node["render_node_id"])
        elif construct == "source_region_image":
            if node["payload"].get("source_path"):
                name = materialized_name(node); target = project / "images" / name
                binding = node["payload"].get("media_binding", {})
                ok = target.exists() and copied_assets.get(name, {}).get("sha256") == sha(target) and binding.get("artifact_sha256") == sha(target)
            else:
                target = project / "images" / f"crop-{node['render_node_id']}.png"; binding = node.get("media_binding", {}); ok = target.exists()
            region_nodes.append({
                "render_node_id": node["render_node_id"],
                "source_block_ids": node["source_block_ids"],
                "representation": "source_region_image",
                "source_pdf_sha256": node["payload"].get("source_pdf_sha256"),
                "source_pdf_page": node["payload"].get("pdf_physical_page", node.get("pdf_physical_pages", [None])[0]),
                "source_bbox": node["payload"].get("bbox"),
                "media_binding": binding,
                "output_ref": rel(out, target),
                "output_sha256": sha(target) if ok else None,
                "status": "closed" if ok else "failed",
            })
            if not ok:
                asset_failures.append(node["render_node_id"])

    coverage_records: list[dict[str, Any]] = []
    mapping_ids: set[str] = set()
    for row in source_rows:
        block_id = row["block_id"]
        if row.get("scope_status") == "excluded":
            coverage_records.append({
                "block_id": block_id,
                "scope_status": "excluded",
                "mapping_type": "scope_excluded",
                "terminal_state": "scope_excluded",
                "terminal_reason": row.get("scope_reason"),
                "output_events": [],
                "verification_status": "closed",
            })
            continue
        if row.get("terminal_state") == "merged_duplicate_evidence" and not spec04d_plan:
            anchor = (row.get("relationship_anchor") or {}).get("block_id")
            anchor_nodes = appearances.get(anchor, [])
            coverage_records.append({
                "block_id": block_id,
                "scope_status": "included",
                "mapping_type": "merged_duplicate_evidence",
                "merged_into_block_id": anchor,
                "output_events": anchor_nodes,
                "verification_status": "closed" if len(anchor_nodes) == 1 else "failed",
                "reason": row.get("terminal_reason"),
            })
            continue
        node_ids = appearances.get(block_id, [])
        node_id = node_ids[0] if len(node_ids) == 1 else None
        node = plan_by_id.get(node_id) if node_id else None
        emission = emission_by_id.get(node_id) if node_id else None
        mapping_type = "merge" if node and len(node["source_block_ids"]) > 1 else "one_to_one"
        mapping_id = f"map-{node_id}" if node_id else f"map-missing-{block_id}"
        mapping_ids.add(mapping_id)
        output_object_hash = chash({
            "render_node_id": node_id,
            "payload_hash": node.get("payload_hash") if node else None,
            "target_construct": node.get("target_construct") if node else None,
            "latex_lines": [emission.get("latex_start_line"), emission.get("latex_end_line")] if emission else None,
            "rendered_body_sha256": execution["rendered_body"]["sha256"],
        })
        coverage_records.append({
            "block_id": block_id,
            "source_span": "entire_atomic_block",
            "source_content_sha256": row.get("raw_content_sha256"),
            "scope_status": "included",
            "mapping_id": mapping_id,
            "mapping_type": mapping_type,
            "output_events": [node_id] if node_id else [],
            "target_construct": node.get("target_construct") if node else None,
            "output_payload_sha256": node.get("payload_hash") if node else None,
            "output_object_sha256": output_object_hash if node and emission else None,
            "latex_anchor": {
                "file": execution["rendered_body"]["path"],
                "start_line": emission.get("latex_start_line") if emission else None,
                "end_line": emission.get("latex_end_line") if emission else None,
            },
            "transformation_audit": {
                "rule_id": (node.get("profile_rule_id") or "/".join(node.get("decision_refs", []))) if node else None,
                "rule_version": node.get("profile_version") if node else None,
                "before_sha256": row.get("raw_content_sha256"),
                "after_sha256": node.get("payload_hash") if node else None,
                "visible_representation_changed": bool(node and node.get("target_construct") in {"source_region_image", "source_asset_image"}),
                "reason": node.get("mapping_reason", node.get("node_kind")) if node else None,
            },
            "verification_status": "closed" if len(node_ids) == 1 and emission and emission.get("payload_hash") == node.get("payload_hash") else "failed",
        })

    logical_ids = {row["block_id"] for row in logical_rows}
    plan_source_ids = [block_id for node in plan_nodes for block_id in node["source_block_ids"]]
    plan_source_set = set(plan_source_ids)
    emission_ids = set(emission_by_id)
    plan_ids = set(plan_by_id)
    output_without_source = [
        node["render_node_id"]
        for node in plan_nodes
        if (
            (not node["source_block_ids"] and not source_supported_virtual_structure(node, by_block, logical_ids, appearances))
            or any(block_id not in logical_ids for block_id in node["source_block_ids"])
        )
    ]
    virtual_structure_nodes = [
        node for node in plan_nodes
        if source_supported_virtual_structure(node, by_block, logical_ids, appearances)
    ]
    unexpected_project_images = sorted(
        path.name for path in (project / "images").iterdir()
        if path.is_file() and path.name not in copied_assets and not path.name.startswith("crop-render-")
    )
    all_closed = all(item["verification_status"] == "closed" for item in coverage_records)
    first_atom = min(logical_rows, key=lambda row: row["candidate_final_order"])
    last_atom = max(logical_rows, key=lambda row: row["candidate_final_order"])
    source_pages = sorted({row["pdf_physical_page"] for row in logical_rows})
    media_source_types = {"image", "chart", "table", "equation", "image_caption", "table_caption", "image_footnote"}
    media_records = [row for row in logical_rows if row.get("source_type") in media_source_types]
    media_closed = all(len(appearances.get(row["block_id"], [])) == 1 for row in media_records) and not asset_failures
    declared_source_records = parent_header["summary"].get(
        "source_evidence_records",
        parent_header["summary"].get("source_records"),
    )

    gate_results = {
        "CV-H01": gate(parent_header["ledger_id"] == read(semantic / "ledgers/ledger_manifest.json")["ledger_id"] and sha(semantic / "ledgers/canonical_block_ledger.jsonl") == read(semantic / "ledgers/ledger_manifest.json")["artifact_sha256"], "parent ledger identity and immutable artifact hash"),
        "CV-H02": gate(declared_source_records == len(source_rows) and len({row["block_id"] for row in source_rows}) == len(source_rows), "all parent-declared source evidence records retain stable unique IDs"),
        "CV-H03": gate(bool(parent_header.get("source_scope_ledger_hash") and parent_header.get("reading_order_ledger_hash")), "scope and reading-order hashes retained from passed parent"),
        "CV-H04": gate(bool(media_records) and len(media_records) == sum(1 for row in logical_rows if row.get("source_type") in media_source_types), "media inventory derived from every included logical atom"),
        "CV-H05": gate(all(row.get("pdf_physical_page") and row.get("bbox") is not None and row.get("upstream_block_ref") for row in source_rows), "page, bbox, and upstream provenance retained"),
        "CV-H06": gate(all((semantic / "ledgers/canonical_block_ledger.jsonl").exists() for _ in [0]), "parent evidence retained; no source pruning performed"),
        "CV-H07": gate(parent_header["spec_status"] == "passed" and parent_index["summary"]["open"] == 0, "upstream source and decision reviews closed"),
        "CV-H08": gate(plan_source_set == logical_ids and all(len(appearances[block_id]) == 1 for block_id in logical_ids), "every included logical atom appears in exactly one planned output event"),
        "CV-H09": gate(not (logical_ids - plan_source_set) and all_closed, "no untracked logical source drop"),
        "CV-H10": gate(len(plan_source_ids) == len(set(plan_source_ids)), "no logical source atom is covered twice"),
        "CV-H11": gate(not output_without_source, f"every teaching-content node has valid source atoms; {len(virtual_structure_nodes)} source-supported virtual structure nodes reference included atoms emitted exactly once elsewhere"),
        "CV-H12": gate(all(item.get("output_payload_sha256") and item.get("output_object_sha256") for item in coverage_records if item.get("mapping_id")), "payload and output object hashes recorded"),
        "CV-H13": gate(not asset_failures and not unexpected_project_images and len(asset_nodes) == sum(node["target_construct"] == "source_asset_image" for node in plan_nodes), "source teaching image references and materialized project assets close bidirectionally"),
        "CV-H14": gate(media_closed and all(len(appearances[row["block_id"]]) == 1 for row in logical_rows if row.get("source_type") in {"table", "equation"}), "all included tables and formulas have a final representation"),
        "CV-H15": gate(not asset_failures and plan_ids == emission_ids, "all formal output asset and emission references resolve"),
        "CV-H16": gate(bool(appearances[first_atom["block_id"]]) and bool(appearances[last_atom["block_id"]]) and source_pages == list(range(min(source_pages), max(source_pages) + 1)), "body head, every included source page, and substantive tail have emissions"),
        "CV-H17": gate(all(item.get("transformation_audit", {}).get("rule_id") for item in coverage_records if item.get("mapping_id")), "all output transformations retain before/after hashes and rule identity"),
        "CV-H18": gate(plan.get("open_reviews") == 0 and parent_index["summary"]["open"] == 0 and not asset_failures and all_closed, "no output coverage review remains open"),
    }
    failures = [name for name, result in gate_results.items() if result["status"] != "passed"]
    spec_status = "passed" if not failures else "failed"

    evidence = {
        "schema_version": "render-coverage-evidence/1.0",
        "generated_at": timestamp,
        "ledger_checkpoint": "render_coverage",
        "spec_status": spec_status,
        "inputs": {
            "parent_ledger": {"path": rel(out, semantic / "ledgers/canonical_block_ledger.jsonl"), "sha256": sha(semantic / "ledgers/canonical_block_ledger.jsonl"), "payload_hash": parent_header["current_ledger_hash"]},
            "render_plan": {"path": rel(out, semantic / "render/render_plan.json"), "sha256": sha(semantic / "render/render_plan.json")},
            "render_execution": {"path": rel(out, compile_run / "reports/render_execution_report.json"), "sha256": sha(compile_run / "reports/render_execution_report.json")},
            "build_manifest": {"path": rel(out, compile_run / "manifests/build_manifest.json"), "sha256": sha(compile_run / "manifests/build_manifest.json"), "build_id": build["build_id"]},
            "spec05_stage_manifest": {"path": rel(out, spec05_stage_path), "sha256": sha(spec05_stage_path)},
        },
        "counts": {
            "source_evidence_records": len(source_rows),
            "scope_excluded": len(excluded_rows),
            "included_evidence_records": sum(row.get("scope_status") == "included" for row in source_rows),
            "included_logical_atoms": len(logical_rows),
            "merged_duplicate_evidence_records": len(duplicate_rows),
            "render_nodes": len(plan_nodes),
            "source_supported_virtual_structure_nodes": len(virtual_structure_nodes),
            "actual_emissions": len(emissions),
            "source_asset_image_nodes": len(asset_nodes),
            "source_region_image_nodes": len(region_nodes),
            "unique_copied_assets": len(copied_assets),
            "source_pages_with_included_content": len(source_pages),
        },
        "head_tail": {
            "first": {"block_id": first_atom["block_id"], "source_page": first_atom["pdf_physical_page"], "render_node_id": appearances[first_atom["block_id"]][0]},
            "last": {"block_id": last_atom["block_id"], "source_page": last_atom["pdf_physical_page"], "render_node_id": appearances[last_atom["block_id"]][0]},
        },
        "gate_results": gate_results,
        "failure_codes": failures,
        "open_reviews": 0 if spec_status == "passed" else len(failures),
    }
    evidence_path = out / "evidence/render_coverage_evidence.json"
    write(evidence_path, evidence)

    decision_id = "DEC-CV-" + chash({"parent": parent_header["current_ledger_hash"], "build": build["build_id"]})[:12].upper()
    event = {
        "decision_id": decision_id,
        "event_type": "automatic_gate_commit",
        "stage": "render_coverage",
        "status": "closed" if spec_status == "passed" else "open",
        "rule_id": "SPEC03-CV-H01-H18",
        "decision": "render_coverage gates passed" if spec_status == "passed" else "render_coverage gates failed",
        "reason": "Deterministic source-span, render-node, actual-emission, asset, and hash reconciliation.",
        "evidence_refs": [{"path": "evidence/render_coverage_evidence.json", "sha256": sha(evidence_path)}],
        "applies_to": {"build_id": build["build_id"], "final_zip_sha256": spec05.get("delivery_zip", spec05.get("final_zip"))["sha256"], "final_pdf_sha256": spec05["final_pdf"]["sha256"]},
        "decider": "deterministic validator",
        "decided_at": timestamp,
    }
    event_path = out / "decisions/evidence_decisions.jsonl"
    writel(event_path, [event])

    decisions = copy.deepcopy(parent_index["decisions"])
    decisions.append({"decision_id": decision_id, "event_file": "decisions/evidence_decisions.jsonl", "rule_id": event["rule_id"], "status": event["status"], "supersedes": [], "invalidated_by": None})
    index = {
        "schema_version": "canonical-decision-index/1.0",
        "decision_index_id": parent_index.get("decision_index_id", parent_index.get("snapshot_id")),
        "snapshot_id": args.output_run + "-decision-index",
        "version": parent_index["version"] + 1,
        "generated_at": timestamp,
        "parent_index_ref": rel(out / "decisions", parent_index_path),
        "parent_index_hash": sha(parent_index_path),
        "acyclic_commit_rule": "existing evidence and parent ledger then decision index D then child ledger L then stage commit M",
        "evidence_committed_before_index": [{"path": "evidence/render_coverage_evidence.json", "sha256": sha(evidence_path)}],
        "decision_event_files": [{"path": "decisions/evidence_decisions.jsonl", "sha256": sha(event_path), "decision_ids": [decision_id]}],
        "decisions": decisions,
        "summary": {
            "closed": sum(item["status"] == "closed" for item in decisions),
            "superseded": sum(item["status"] == "superseded" for item in decisions),
            "open": sum(item["status"] == "open" for item in decisions),
            "invalidated": sum(item["status"] == "invalidated" for item in decisions),
        },
        "spec_status": spec_status,
    }
    index_path = out / "decisions/canonical_decision_index.json"
    write(index_path, index)
    decision_hash = sha(index_path)

    child_rows = copy.deepcopy(source_rows)
    coverage_by_block = {item["block_id"]: item for item in coverage_records}
    for row in child_rows:
        coverage = coverage_by_block[row["block_id"]]
        if row.get("scope_status") == "excluded":
            continue
        if row.get("terminal_state") == "merged_duplicate_evidence":
            row["render_status"] = "covered_by_primary_emission"
            row["output_coverage"] = coverage
        else:
            row["render_status"] = "emitted"
            row["terminal_state"] = "render_covered"
            row["terminal_reason"] = "Bound to one formal output event and verified against the exact Spec 05 delivery build."
            row["output_coverage"] = coverage
        row["human_decision_refs"] = sorted(set(row.get("human_decision_refs", [])) | {decision_id})

    payload_hash = chash(child_rows)
    header = copy.deepcopy(parent_header)
    header.update({
        "generated_at": timestamp,
        "updated_at": timestamp,
        "ledger_checkpoint": "render_coverage",
        "ledger_version": parent_header["ledger_version"] + 1,
        "ledger_snapshot_id": args.ledger_snapshot_id,
        "parent_ledger_ref": rel(out / "ledgers", semantic / "ledgers/canonical_block_ledger.jsonl"),
        "parent_ledger_file_sha256": sha(semantic / "ledgers/canonical_block_ledger.jsonl"),
        "parent_ledger_hash": parent_header["current_ledger_hash"],
        "current_ledger_hash": payload_hash,
        "canonical_decision_index_ref": "decisions/canonical_decision_index.json",
        "canonical_decision_index_hash": decision_hash,
        "build_id": build["build_id"],
        "final_zip_sha256": spec05.get("delivery_zip", spec05.get("final_zip"))["sha256"],
        "final_pdf_sha256": spec05["final_pdf"]["sha256"],
        "render_execution_sha256": sha(compile_run / "reports/render_execution_report.json"),
        "spec_status": spec_status,
        "gate_status": {name: result["status"] for name, result in gate_results.items()},
        "summary": {**evidence["counts"], "open_output_reviews": evidence["open_reviews"]},
    })
    ledger_path = out / "ledgers/canonical_block_ledger.jsonl"
    writel(ledger_path, [header, *child_rows])
    ledger_file_hash = sha(ledger_path)

    block_coverage = {
        "schema_version": "block-coverage-ledger/4.0",
        "generated_at": timestamp,
        "ledger_checkpoint": "render_coverage",
        "spec_status": spec_status,
        "canonical_ledger_ref": "ledgers/canonical_block_ledger.jsonl",
        "canonical_ledger_hash": ledger_file_hash,
        "canonical_ledger_payload_hash": payload_hash,
        "decision_index_ref": "decisions/canonical_decision_index.json",
        "decision_index_hash": decision_hash,
        "build_id": build["build_id"],
        "rendered_body_sha256": execution["rendered_body"]["sha256"],
        "summary": evidence["counts"],
        "source_spans": coverage_records,
    }
    coverage_path = out / "ledgers/block_coverage_ledger.json"
    write(coverage_path, block_coverage)

    media_ledger = {
        "schema_version": "media-ledger/4.0",
        "generated_at": timestamp,
        "ledger_checkpoint": "render_coverage",
        "spec_status": spec_status,
        "canonical_ledger_ref": "ledgers/canonical_block_ledger.jsonl",
        "canonical_ledger_hash": ledger_file_hash,
        "decision_index_ref": "decisions/canonical_decision_index.json",
        "decision_index_hash": decision_hash,
        "build_id": build["build_id"],
        "summary": {
            "included_media_atoms": len(media_records),
            "source_asset_image_nodes": len(asset_nodes),
            "unique_copied_assets": len(copied_assets),
            "source_region_image_nodes": len(region_nodes),
            "asset_failures": len(asset_failures),
            "open_media_reviews": 0 if media_closed else len(asset_failures),
        },
        "source_asset_outputs": asset_nodes,
        "source_region_outputs": region_nodes,
        "source_type_counts": dict(Counter(row["source_type"] for row in media_records)),
    }
    media_path = out / "ledgers/media_ledger.json"
    write(media_path, media_ledger)

    report = {
        "schema_version": "completeness-report/4.0",
        "generated_at": timestamp,
        "ledger_checkpoint": "render_coverage",
        "spec_status": spec_status,
        "build_id": build["build_id"],
        "ledger_snapshot_id": args.ledger_snapshot_id,
        "counts": evidence["counts"],
        "gate_results": gate_results,
        "failure_codes": failures,
        "open_reviews": evidence["open_reviews"],
        "scope_limit": "Logical render coverage is proven. Final PDF visibility and page-level source fidelity remain Spec 06 work.",
    }
    report_path = out / "reports/completeness_report.json"
    write(report_path, report)
    (out / "reports/completeness_report.md").write_text(
        "# Render coverage completeness report\n\n"
        f"- checkpoint: `render_coverage`\n- spec_status: `{spec_status}`\n- build_id: `{build['build_id']}`\n"
        f"- included logical atoms: {len(logical_rows)}\n- render nodes/emissions: {len(plan_nodes)}/{len(emissions)}\n"
        f"- source asset nodes: {len(asset_nodes)}\n- source region nodes: {len(region_nodes)}\n- open reviews: {evidence['open_reviews']}\n\n"
        "This checkpoint proves logical output coverage and asset/hash closure. It does not claim final PDF page-level fidelity or user acceptance.\n",
        encoding="utf-8",
    )
    qa = {
        "schema_version": "render-coverage-review-queue/1.0",
        "generated_at": timestamp,
        "spec_status": spec_status,
        "items": [] if spec_status == "passed" else [{"gate": name, "status": "open", "evidence": gate_results[name]["evidence"]} for name in failures],
        "open_count": evidence["open_reviews"],
    }
    qa_path = out / "qa/render_coverage_review_queue.json"
    write(qa_path, qa)

    manifest = {
        "schema_version": "ledger-manifest/2.0",
        "generated_at": timestamp,
        "ledger_id": header["ledger_id"],
        "ledger_version": header["ledger_version"],
        "snapshot_id": header["ledger_snapshot_id"],
        "artifact_path": "ledgers/canonical_block_ledger.jsonl",
        "artifact_sha256": ledger_file_hash,
        "payload_hash": payload_hash,
        "parent_artifact_ref": rel(out / "ledgers", semantic / "ledgers/canonical_block_ledger.jsonl"),
        "parent_artifact_sha256": sha(semantic / "ledgers/canonical_block_ledger.jsonl"),
        "decision_index_ref": "decisions/canonical_decision_index.json",
        "decision_index_hash": decision_hash,
        "spec_status": spec_status,
        "ledger_checkpoint": "render_coverage",
        "immutable_after_publication": True,
    }
    manifest_path = out / "ledgers/ledger_manifest.json"
    write(manifest_path, manifest)

    bound_paths = [coverage_path, media_path, report_path, out / "reports/completeness_report.md", qa_path]
    stage = {
        "schema_version": "stage-commit-manifest/1.0",
        "generated_at": timestamp,
        "stage": "render_coverage",
        "spec_status": spec_status,
        "build_id": build["build_id"],
        "decision_index_D": {"path": "decisions/canonical_decision_index.json", "sha256": decision_hash},
        "ledger_L": {"path": "ledgers/canonical_block_ledger.jsonl", "sha256": ledger_file_hash, "payload_hash": payload_hash},
        "final_zip": spec05.get("delivery_zip", spec05.get("final_zip")),
        "final_pdf": spec05["final_pdf"],
        "render_manifest": spec05.get("render_pack", {"path": "final_render_pack/manifest.json", "sha256": sha(compile_run / "final_render_pack/manifest.json")}),
        "bound_artifacts": [{"path": path.relative_to(out).as_posix(), "sha256": sha(path)} for path in bound_paths],
        "scope_limit": "Spec 03 render_coverage only; final PDF visibility, full-page review, and human acceptance are not claimed.",
    }
    stage_path = out / "manifests/render_coverage_commit.json"
    write(stage_path, stage)

    run_manifest = {
        "schema_version": "run-manifest/1.0",
        "generated_at": timestamp,
        "run_id": args.output_run,
        "stage": "render_coverage",
        "spec_status": spec_status,
        "ledger_checkpoint": "render_coverage",
        "files": [
            {"path": path.relative_to(out).as_posix(), "sha256": sha(path), "size": path.stat().st_size}
            for path in sorted(out.rglob("*")) if path.is_file()
        ],
    }
    write(out / "manifests/run_manifest.json", run_manifest)
    print(json.dumps({"run": str(out), "spec_status": spec_status, "ledger_checkpoint": "render_coverage", "counts": evidence["counts"], "failures": failures}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
