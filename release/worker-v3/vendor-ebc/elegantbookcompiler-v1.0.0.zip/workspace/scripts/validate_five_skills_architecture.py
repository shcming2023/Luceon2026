#!/usr/bin/env python3
"""Independently validate the frozen five-skill formal-v1 architecture."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


REQUIRED_SKILLS = {
    "luceon-popo-to-refined-elegantbook",
    "pdf-clean-markdown-rebuild",
    "material-semantic-annotator",
    "cleanlatex-to-elegantbook",
    "refine-elegantbook-latex",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--ruling", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--scope", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    ruling = load(args.ruling)
    matrix = load(args.matrix)
    scope = load(args.scope)
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "passed" if condition else "failed", "detail": detail})

    skills = ruling.get("skills", {})
    check("exact_five_skills", set(skills) == REQUIRED_SKILLS, sorted(skills))

    owners: dict[str, list[str]] = {}
    for skill, role in skills.items():
        for stage in role.get("authoritative_stages", []):
            owners.setdefault(stage, []).append(skill)
    check(
        "single_authority_per_formal_stage",
        owners == {
            "spec01": ["luceon-popo-to-refined-elegantbook"],
            "spec02": ["luceon-popo-to-refined-elegantbook"],
            "spec03": ["luceon-popo-to-refined-elegantbook"],
            "spec04": ["luceon-popo-to-refined-elegantbook"],
            "spec05": ["cleanlatex-to-elegantbook"],
        },
        owners,
    )
    check("no_skill_claims_spec06", "spec06" not in owners, owners.get("spec06", []))
    check("no_giant_skill_consolidation", ruling.get("decision", {}).get("consolidate_skills") is False, ruling.get("decision"))

    snapshots = ruling.get("skill_snapshots", {})
    snapshot_failures = []
    marker_failures = []
    for name in REQUIRED_SKILLS:
        item = snapshots.get(name, {})
        path = Path(item.get("path", ""))
        if not path.is_file() or sha256(path) != item.get("sha256"):
            snapshot_failures.append(name)
        marker = skills[name].get("boundary_marker")
        if marker and (not path.is_file() or marker not in path.read_text(encoding="utf-8")):
            marker_failures.append(name)
    check("live_skill_hashes", not snapshot_failures, snapshot_failures)
    check("formal_boundary_markers", not marker_failures, marker_failures)

    evidence_failures = []
    for name, item in ruling.get("evidence", {}).items():
        path = workspace / item.get("path", "")
        if not path.is_file() or sha256(path) != item.get("sha256"):
            evidence_failures.append(name)
    check("evidence_hashes", not evidence_failures, evidence_failures)

    blind = ruling.get("blind_sample_result", {})
    check(
        "blind_spec06_qualified_without_fake_acceptance",
        blind.get("spec_status") == "passed"
        and blind.get("acceptance_status") in {"ready_for_user_acceptance", "human_accepted"}
        and blind.get("human_accepted") is False
        and blind.get("independent_checks_failed") == 0,
        blind,
    )

    check("matrix_v16_frozen", matrix.get("schema_version") == "five-skills-gap-matrix-delta/16.0" and matrix.get("decision", {}).get("shared_skill_architecture_frozen") is True, matrix.get("status"))
    check("scope_v2_rc_qualified", scope.get("schema_version") == "elegantbookcompiler-v1-support-scope/2.0" and scope.get("release_qualification_status") == "qualified_for_release_candidate_engineering", scope.get("release_qualification_status"))
    check("fixed_template_only", scope.get("target_template", {}).get("policy") == "single_fixed_template_only" and scope.get("target_template", {}).get("alternate_templates_supported") is False, scope.get("target_template"))
    check("formal_full_source_required", set(scope.get("formal_input_contract", {}).get("required", [])) >= {"original_source_pdf", "complete_mineru_artifacts", "complete_mineru_popo_artifacts"}, scope.get("formal_input_contract"))
    blind_rows = [
        row for row in scope.get("current_qualification", [])
        if row.get("language") == "zh"
        and row.get("family") == "workbook_or_exercise_book"
        and row.get("pipeline_class") == "formal_native"
        and row.get("qualifies_formal_native_claim") is True
        and row.get("human_accepted") is False
    ]
    check("blind_scope_row", len(blind_rows) == 1 and blind_rows[0].get("qualifies_formal_native_claim") is True and blind_rows[0].get("human_accepted") is False, blind_rows)

    failed = [item["name"] for item in checks if item["status"] == "failed"]
    report = {
        "schema_version": "five-skills-architecture-validation/1.0",
        "status": "passed" if not failed else "failed",
        "checks": checks,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_checks": failed},
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
