#!/usr/bin/env python3
"""Manifest-driven ElegantBookCompiler pipeline runner.

This CLI is intentionally a thin execution boundary. It validates a stage DAG,
binds inputs and outputs by hash, runs argv without a shell, and resumes only
when the recorded fingerprint and output hashes still match. It does not make
content, semantic, template, or acceptance decisions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


VERSION = "1.0.0"
SCHEMA_VERSION = "elegantbookcompiler-pipeline/1.0"
STATE_SCHEMA = "elegantbookcompiler-run-state/1.0"
ALLOWED_MODES = {"execute", "verify_only"}


class ManifestError(RuntimeError):
    pass


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hash_path(path: Path) -> str:
    if path.is_file():
        return sha256_file(path)
    if path.is_dir():
        digest = hashlib.sha256()
        for item in sorted(candidate for candidate in path.rglob("*") if candidate.is_file()):
            relative = item.relative_to(path).as_posix().encode("utf-8")
            digest.update(len(relative).to_bytes(8, "big"))
            digest.update(relative)
            digest.update(bytes.fromhex(sha256_file(item)))
        return digest.hexdigest()
    raise ManifestError(f"artifact does not exist: {path}")


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManifestError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ManifestError(f"top-level JSON must be an object: {path}")
    return value


def expand(value: str, *, workspace: Path, python: Path, skills_root: Path) -> str:
    replacements = {
        "${WORKSPACE}": str(workspace),
        "${PYTHON}": str(python),
        "${SKILLS_ROOT}": str(skills_root),
    }
    for key, replacement in replacements.items():
        value = value.replace(key, replacement)
    if "${" in value:
        raise ManifestError(f"unknown placeholder in value: {value}")
    return value


def artifact_path(item: dict[str, Any], *, workspace: Path, python: Path, skills_root: Path) -> Path:
    raw = item.get("path")
    if not isinstance(raw, str) or not raw:
        raise ManifestError("artifact path must be a non-empty string")
    expanded = Path(expand(raw, workspace=workspace, python=python, skills_root=skills_root))
    return expanded if expanded.is_absolute() else workspace / expanded


def validate_manifest(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "passed" if condition else "failed", "detail": detail})

    check("schema", manifest.get("schema_version") == SCHEMA_VERSION, manifest.get("schema_version"))
    check("pipeline_id", isinstance(manifest.get("pipeline_id"), str) and bool(manifest.get("pipeline_id")), manifest.get("pipeline_id"))
    fixed_template = manifest.get("fixed_template")
    check("fixed_template", isinstance(fixed_template, dict) and isinstance(fixed_template.get("path"), str) and isinstance(fixed_template.get("sha256"), str), fixed_template)
    stages = manifest.get("stages")
    check("stages_nonempty", isinstance(stages, list) and bool(stages), len(stages) if isinstance(stages, list) else None)
    if not isinstance(stages, list):
        return checks
    ids = [stage.get("stage_id") for stage in stages if isinstance(stage, dict)]
    check("unique_stage_ids", len(ids) == len(stages) == len(set(ids)) and all(isinstance(item, str) and item for item in ids), ids)
    known = set(ids)
    edges: dict[str, list[str]] = {}
    stage_shape_ok = True
    no_external_write = True
    for stage in stages:
        if not isinstance(stage, dict):
            stage_shape_ok = False
            continue
        requires = stage.get("requires", [])
        edges[stage.get("stage_id")] = requires if isinstance(requires, list) else []
        resources = stage.get("resources", {})
        command = stage.get("command_argv")
        inputs = stage.get("inputs", [])
        input_shape_ok = isinstance(inputs, list) and all(
            isinstance(item, dict)
            and isinstance(item.get("path"), str)
            and (
                isinstance(item.get("sha256"), str)
                or (isinstance(item.get("from_stage"), str) and item.get("from_stage") in requires)
            )
            for item in inputs
        )
        stage_shape_ok = stage_shape_ok and (
            stage.get("execution_mode") in ALLOWED_MODES
            and isinstance(stage.get("owner"), str)
            and bool(stage.get("owner"))
            and isinstance(requires, list)
            and all(isinstance(item, str) and item in known for item in requires)
            and isinstance(command, list)
            and bool(command)
            and all(isinstance(item, str) and item for item in command)
            and input_shape_ok
            and isinstance(stage.get("outputs", []), list)
        )
        no_external_write = no_external_write and isinstance(resources, dict) and resources.get("external_write", False) is False
    check("stage_shape", stage_shape_ok, "mode, owner, requires, argv, inputs, and outputs")
    check("external_writes_forbidden", no_external_write, "every stage must declare or default external_write=false")

    visiting: set[str] = set()
    visited: set[str] = set()
    cyclic = False

    def visit(node: str) -> None:
        nonlocal cyclic
        if node in visiting:
            cyclic = True
            return
        if node in visited:
            return
        visiting.add(node)
        for parent in edges.get(node, []):
            visit(parent)
        visiting.remove(node)
        visited.add(node)

    for node in known:
        visit(node)
    check("acyclic", not cyclic, edges)
    return checks


def require_valid_manifest(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    checks = validate_manifest(manifest)
    failed = [item for item in checks if item["status"] == "failed"]
    if failed:
        raise ManifestError("manifest validation failed: " + ", ".join(item["name"] for item in failed))
    return checks


def topological_stages(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    by_id = {stage["stage_id"]: stage for stage in manifest["stages"]}
    ordered: list[dict[str, Any]] = []
    visited: set[str] = set()

    def visit(stage_id: str) -> None:
        if stage_id in visited:
            return
        for parent in by_id[stage_id].get("requires", []):
            visit(parent)
        visited.add(stage_id)
        ordered.append(by_id[stage_id])

    for stage in manifest["stages"]:
        visit(stage["stage_id"])
    return ordered


def current_artifacts(
    items: list[dict[str, Any]], *, workspace: Path, python: Path, skills_root: Path, require_expected_hash: bool
) -> list[dict[str, Any]]:
    result = []
    for item in items:
        path = artifact_path(item, workspace=workspace, python=python, skills_root=skills_root).resolve()
        if not path.exists():
            raise ManifestError(f"missing artifact: {path}")
        actual = hash_path(path)
        expected = item.get("sha256")
        if require_expected_hash and not isinstance(expected, str):
            raise ManifestError(f"input artifact must declare sha256: {path}")
        if isinstance(expected, str) and actual != expected:
            raise ManifestError(f"artifact hash mismatch: {path}: expected {expected}, got {actual}")
        result.append({"path": str(path), "sha256": actual, "kind": "directory" if path.is_dir() else "file"})
    return result


def current_stage_inputs(
    stage: dict[str, Any], state: dict[str, Any], *, workspace: Path, python: Path, skills_root: Path
) -> list[dict[str, Any]]:
    resolved = []
    for item in stage.get("inputs", []):
        effective = dict(item)
        from_stage = item.get("from_stage")
        if from_stage:
            parent = state.get("stages", {}).get(from_stage, {})
            path = artifact_path(item, workspace=workspace, python=python, skills_root=skills_root).resolve()
            matches = [output for output in parent.get("outputs", []) if Path(output["path"]).resolve() == path]
            if len(matches) != 1:
                raise ManifestError(f"input {path} is not a unique recorded output of {from_stage}")
            effective["sha256"] = matches[0]["sha256"]
        resolved.extend(
            current_artifacts([effective], workspace=workspace, python=python, skills_root=skills_root, require_expected_hash=True)
        )
    return resolved


def stage_fingerprint(stage: dict[str, Any], inputs: list[dict[str, Any]]) -> str:
    return sha256_bytes(canonical_json({"stage": stage, "inputs": inputs, "cli_version": VERSION}))


def outputs_match(recorded: list[dict[str, Any]]) -> bool:
    for item in recorded:
        path = Path(item["path"])
        if not path.exists() or hash_path(path) != item["sha256"]:
            return False
    return True


def run_pipeline(args: argparse.Namespace, manifest: dict[str, Any]) -> int:
    workspace = args.workspace.resolve()
    # Preserve virtual-environment launcher semantics. Path.resolve() follows the
    # venv symlink to the base interpreter and silently drops the venv prefix.
    python = Path(os.path.abspath(args.python))
    skills_root = args.skills_root.resolve()
    template = artifact_path(manifest["fixed_template"], workspace=workspace, python=python, skills_root=skills_root)
    if not template.is_file() or sha256_file(template) != manifest["fixed_template"]["sha256"]:
        raise ManifestError("fixed template is missing or drifted")

    state_path = args.state.resolve()
    state = load_json(state_path) if state_path.exists() else {
        "schema_version": STATE_SCHEMA,
        "pipeline_id": manifest["pipeline_id"],
        "manifest_sha256": sha256_bytes(canonical_json(manifest)),
        "created_at": now_iso(),
        "status": "running",
        "stages": {},
    }
    if state.get("pipeline_id") != manifest["pipeline_id"]:
        raise ManifestError("state belongs to a different pipeline")
    manifest_hash = sha256_bytes(canonical_json(manifest))
    if state.get("manifest_sha256") != manifest_hash:
        raise ManifestError("manifest changed; start a new immutable run state")

    logs_dir = state_path.parent / (state_path.stem + ".logs")
    logs_dir.mkdir(parents=True, exist_ok=True)
    for stage in topological_stages(manifest):
        stage_id = stage["stage_id"]
        for required in stage.get("requires", []):
            if state["stages"].get(required, {}).get("status") != "passed":
                raise ManifestError(f"dependency {required} is not passed before {stage_id}")
        resources = stage.get("resources", {})
        if resources.get("llm", False) and not args.allow_llm:
            raise ManifestError(f"stage {stage_id} requires LLM; rerun only with explicit --allow-llm")
        if resources.get("gpu", False) and not args.allow_gpu:
            raise ManifestError(f"stage {stage_id} requires GPU; rerun only with explicit --allow-gpu")
        if resources.get("external_write", False):
            raise ManifestError(f"stage {stage_id} requests a forbidden external write")

        inputs = current_stage_inputs(stage, state, workspace=workspace, python=python, skills_root=skills_root)
        fingerprint = stage_fingerprint(stage, inputs)
        previous = state["stages"].get(stage_id)
        if args.resume and previous and previous.get("status") == "passed":
            if previous.get("fingerprint") != fingerprint:
                raise ManifestError(f"cannot resume {stage_id}: input or stage fingerprint drifted")
            if not outputs_match(previous.get("outputs", [])):
                raise ManifestError(f"cannot resume {stage_id}: output missing or drifted")
            previous["resume_action"] = "verified_and_skipped"
            atomic_json(state_path, state)
            continue

        if stage.get("execution_mode") == "execute" and stage.get("immutable_outputs", True):
            for item in stage.get("outputs", []):
                path = artifact_path(item, workspace=workspace, python=python, skills_root=skills_root)
                if path.exists():
                    raise ManifestError(f"refusing to overwrite immutable output for {stage_id}: {path}")

        command = [expand(item, workspace=workspace, python=python, skills_root=skills_root) for item in stage["command_argv"]]
        cwd_raw = expand(stage.get("cwd", "${WORKSPACE}"), workspace=workspace, python=python, skills_root=skills_root)
        cwd = Path(cwd_raw)
        cwd = cwd if cwd.is_absolute() else workspace / cwd
        started_at = now_iso()
        start = time.monotonic()
        result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
        duration = round(time.monotonic() - start, 6)
        stdout_path = logs_dir / f"{stage_id}.stdout.log"
        stderr_path = logs_dir / f"{stage_id}.stderr.log"
        stdout_path.write_text(result.stdout, encoding="utf-8")
        stderr_path.write_text(result.stderr, encoding="utf-8")
        record: dict[str, Any] = {
            "status": "failed" if result.returncode else "running",
            "execution_mode": stage["execution_mode"],
            "owner": stage["owner"],
            "fingerprint": fingerprint,
            "inputs": inputs,
            "command_argv": command,
            "started_at": started_at,
            "finished_at": now_iso(),
            "duration_seconds": duration,
            "returncode": result.returncode,
            "stdout": {"path": str(stdout_path), "sha256": sha256_file(stdout_path)},
            "stderr": {"path": str(stderr_path), "sha256": sha256_file(stderr_path)},
        }
        state["stages"][stage_id] = record
        if result.returncode:
            state["status"] = "failed"
            atomic_json(state_path, state)
            return result.returncode
        try:
            outputs = current_artifacts(stage.get("outputs", []), workspace=workspace, python=python, skills_root=skills_root, require_expected_hash=False)
        except ManifestError as exc:
            record["status"] = "failed"
            record["output_validation_error"] = str(exc)
            state["status"] = "failed"
            atomic_json(state_path, state)
            return 2
        record["outputs"] = outputs
        record["status"] = "passed"
        atomic_json(state_path, state)

    state["status"] = "passed"
    state["finished_at"] = now_iso()
    state["summary"] = {"passed": len(state["stages"]), "failed": 0}
    atomic_json(state_path, state)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="elegantbookcompiler")
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("validate", "plan", "run", "status"):
        child = subparsers.add_parser(name)
        child.add_argument("--manifest", type=Path, required=name != "status")
        child.add_argument("--workspace", type=Path, required=True)
        child.add_argument("--python", type=Path, default=Path(sys.executable))
        child.add_argument("--skills-root", type=Path, default=Path.home() / ".codex" / "skills")
        if name in {"run", "status"}:
            child.add_argument("--state", type=Path, required=True)
        if name == "run":
            child.add_argument("--resume", action="store_true")
            child.add_argument("--allow-llm", action="store_true")
            child.add_argument("--allow-gpu", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "status":
            state = load_json(args.state)
            print(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True))
            return 0 if state.get("status") == "passed" else 1
        manifest = load_json(args.manifest)
        checks = require_valid_manifest(manifest)
        if args.command == "validate":
            print(json.dumps({"status": "passed", "checks": checks}, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        if args.command == "plan":
            plan = [
                {
                    "stage_id": stage["stage_id"],
                    "owner": stage["owner"],
                    "execution_mode": stage["execution_mode"],
                    "requires": stage.get("requires", []),
                    "resources": stage.get("resources", {}),
                }
                for stage in topological_stages(manifest)
            ]
            print(json.dumps({"pipeline_id": manifest["pipeline_id"], "stages": plan}, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        return run_pipeline(args, manifest)
    except ManifestError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
