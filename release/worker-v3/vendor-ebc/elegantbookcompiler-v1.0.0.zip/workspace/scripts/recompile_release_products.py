#!/usr/bin/env python3
"""Clean-recompile every release product ZIP in the locked TeX runtime."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shlex
import stat
import subprocess
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pypdf import PdfReader
import fitz


COMPILE_COMMAND = ["latexmk", "-xelatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error", "main.tex"]
COMPILE_ENVIRONMENT = {"FORCE_SOURCE_DATE": "1", "SOURCE_DATE_EPOCH": "1752508800"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_extract(archive: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive) as bundle:
        root = destination.resolve()
        for member in bundle.infolist():
            target = (destination / member.filename).resolve()
            if target != root and root not in target.parents:
                raise ValueError(f"unsafe ZIP path: {member.filename}")
            mode = (member.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise ValueError(f"ZIP symlink is forbidden: {member.filename}")
        bundle.extractall(destination)


def run(argv: list[str], *, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    return subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=False)


def pdf_equivalence_signature(path: Path) -> dict[str, Any]:
    document = fitz.open(path)
    page_sizes = []
    page_text_hashes = []
    page_raster_hashes = []
    link_counts = []
    for page in document:
        page_sizes.append([round(page.rect.width, 4), round(page.rect.height, 4)])
        page_text_hashes.append(hashlib.sha256(page.get_text("text").encode("utf-8")).hexdigest())
        pixmap = page.get_pixmap(matrix=fitz.Matrix(1.0, 1.0), colorspace=fitz.csRGB, alpha=False)
        raster_payload = (
            pixmap.width.to_bytes(4, "big")
            + pixmap.height.to_bytes(4, "big")
            + pixmap.stride.to_bytes(4, "big")
            + pixmap.samples
        )
        page_raster_hashes.append(hashlib.sha256(raster_payload).hexdigest())
        link_counts.append(len(page.get_links()))
    toc = document.get_toc(simple=True)
    document.close()

    def canonical(value: Any) -> str:
        return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    return {
        "pages": len(page_sizes),
        "page_sizes_sha256": canonical(page_sizes),
        "page_text_sha256": canonical(page_text_hashes),
        "page_raster_sha256": canonical(page_raster_hashes),
        "link_counts_sha256": canonical(link_counts),
        "toc_sha256": canonical(toc),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--container", default="sharelatex")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    matrix = json.loads(args.matrix.read_text(encoding="utf-8"))
    results = []
    failures = []

    for sample in matrix["samples"]:
        sample_id = sample["sample_id"]
        archive = workspace / sample["final_zip"]["path"]
        accepted_pdf = workspace / sample["final_pdf"]["path"]
        token = hashlib.sha256((sample_id + sample["final_zip"]["sha256"]).encode()).hexdigest()[:20]
        remote = f"/tmp/ebc-release-recompile-{token}"
        started = time.monotonic()
        with tempfile.TemporaryDirectory(prefix="ebc-release-recompile-") as temporary:
            local = Path(temporary)
            source = local / "source"
            source.mkdir()
            safe_extract(archive, source)
            if not (source / "main.tex").is_file():
                raise SystemExit(f"{sample_id}: ZIP has no main.tex")
            mkdir = run(["docker", "exec", args.container, "mkdir", "-p", remote], timeout=60)
            if mkdir.returncode:
                raise SystemExit(f"{sample_id}: cannot create container workdir: {mkdir.stderr}")
            try:
                copied = run(["docker", "cp", f"{source}/.", f"{args.container}:{remote}/"])
                if copied.returncode:
                    raise SystemExit(f"{sample_id}: docker cp failed: {copied.stderr}")
                shell = shlex.join(["env", *[f"{key}={value}" for key, value in sorted(COMPILE_ENVIRONMENT.items())], *COMPILE_COMMAND])
                compiled = run(["docker", "exec", "-w", remote, args.container, "sh", "-lc", shell])
                local_pdf = local / "main.pdf"
                local_log = local / "main.log"
                if compiled.returncode == 0:
                    copy_pdf = run(["docker", "cp", f"{args.container}:{remote}/main.pdf", str(local_pdf)])
                    copy_log = run(["docker", "cp", f"{args.container}:{remote}/main.log", str(local_log)])
                else:
                    copy_pdf = subprocess.CompletedProcess([], 1, "", "compile failed")
                    copy_log = run(["docker", "cp", f"{args.container}:{remote}/main.log", str(local_log)], timeout=60)
            finally:
                run(["docker", "exec", args.container, "rm", "-rf", remote], timeout=60)

            produced_hash = sha256(local_pdf) if local_pdf.is_file() else None
            accepted_hash = sha256(accepted_pdf) if accepted_pdf.is_file() else None
            pages = len(PdfReader(str(local_pdf)).pages) if local_pdf.is_file() else None
            accepted_pages = len(PdfReader(str(accepted_pdf)).pages) if accepted_pdf.is_file() else None
            exact = (
                compiled.returncode == 0
                and copy_pdf.returncode == 0
                and produced_hash == accepted_hash == sample["final_pdf"]["sha256"]
                and pages == accepted_pages
            )
            accepted_signature = None
            recompiled_signature = None
            migration_equivalent = False
            if not exact and sample["pipeline_class"] == "migration_compatibility" and local_pdf.is_file() and accepted_pdf.is_file():
                accepted_signature = pdf_equivalence_signature(accepted_pdf)
                recompiled_signature = pdf_equivalence_signature(local_pdf)
                migration_equivalent = accepted_signature == recompiled_signature
            passed = exact or migration_equivalent
            result = {
                "sample_id": sample_id,
                "pipeline_class": sample["pipeline_class"],
                "status": "passed" if passed else "failed",
                "zip_sha256": sha256(archive),
                "accepted_pdf_sha256": accepted_hash,
                "recompiled_pdf_sha256": produced_hash,
                "accepted_pages": accepted_pages,
                "recompiled_pages": pages,
                "compile_exit_code": compiled.returncode,
                "compile_stdout_sha256": hashlib.sha256(compiled.stdout.encode()).hexdigest(),
                "compile_stderr_sha256": hashlib.sha256(compiled.stderr.encode()).hexdigest(),
                "log_sha256": sha256(local_log) if local_log.is_file() else None,
                "duration_seconds": round(time.monotonic() - started, 6),
                "exact_pdf_reproduction": exact,
                "migration_visual_text_structure_equivalent": migration_equivalent,
                "accepted_equivalence_signature": accepted_signature,
                "recompiled_equivalence_signature": recompiled_signature,
                "reproduction_level": "exact_bytes" if exact else ("migration_visual_text_structure_equivalent" if migration_equivalent else "failed"),
            }
            results.append(result)
            if not passed:
                failures.append(sample_id)

    report = {
        "schema_version": "release-product-recompile-validation/1.0",
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "status": "passed" if not failures else "failed",
        "container": args.container,
        "compile_command": COMPILE_COMMAND,
        "compile_environment_keys": sorted(COMPILE_ENVIRONMENT),
        "matrix_sha256": sha256(args.matrix),
        "samples": results,
        "summary": {"passed": len(results) - len(failures), "failed": len(failures), "failed_samples": failures},
        "claim_boundary": "Formal-native products require exact PDF bytes after clean recompilation. Migration-compatibility products may pass only when every page raster, extracted text, page size, link count, and TOC signature is identical. No semantic stage or accepted snapshot is altered.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
