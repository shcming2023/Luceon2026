#!/usr/bin/env python3
"""Independent validator for a Spec 03 render_coverage run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def readl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def chash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--semantic-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--coverage-run", required=True)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    sample = args.sample_dir.resolve()
    semantic = sample / "runs" / args.semantic_run
    compile_run = sample / "runs" / args.compile_run
    run = sample / "runs" / args.coverage_run
    errors: list[str] = []

    ledger_rows = readl(run / "ledgers/canonical_block_ledger.jsonl")
    header, rows = ledger_rows[0], ledger_rows[1:]
    parent_rows = readl(semantic / "ledgers/canonical_block_ledger.jsonl")
    parent_header = parent_rows[0]
    plan = read(semantic / "render/render_plan.json")
    execution = read(compile_run / "reports/render_execution_report.json")
    coverage = read(run / "ledgers/block_coverage_ledger.json")
    media = read(run / "ledgers/media_ledger.json")
    report = read(run / "reports/completeness_report.json")
    index = read(run / "decisions/canonical_decision_index.json")
    manifest = read(run / "ledgers/ledger_manifest.json")
    commit = read(run / "manifests/render_coverage_commit.json")

    if header["ledger_checkpoint"] != "render_coverage" or header["spec_status"] != "passed": errors.append("ledger checkpoint/status")
    if header["parent_ledger_hash"] != parent_header["current_ledger_hash"]: errors.append("parent payload hash")
    if header["parent_ledger_file_sha256"] != sha(semantic / "ledgers/canonical_block_ledger.jsonl"): errors.append("parent file hash")
    if header["current_ledger_hash"] != chash(rows): errors.append("child payload hash")
    if header["canonical_decision_index_hash"] != sha(run / "decisions/canonical_decision_index.json"): errors.append("decision binding")
    if manifest["artifact_sha256"] != sha(run / "ledgers/canonical_block_ledger.jsonl") or manifest["payload_hash"] != header["current_ledger_hash"]: errors.append("ledger manifest")
    if index["summary"]["open"] or index["spec_status"] != "passed": errors.append("open decisions")
    if commit["decision_index_D"]["sha256"] != sha(run / "decisions/canonical_decision_index.json"): errors.append("commit D")
    if commit["ledger_L"]["sha256"] != sha(run / "ledgers/canonical_block_ledger.jsonl"): errors.append("commit L")
    if any(item["status"] != "passed" for item in report["gate_results"].values()): errors.append("failed CV gate")

    spec04d_plan = plan.get("schema_version") == "render-plan/2.0"
    included = [row for row in rows if row.get("scope_status") == "included" and (spec04d_plan or row.get("terminal_state") != "merged_duplicate_evidence")]
    expected_included = sum(row.get("scope_status") == "included" for row in parent_rows[1:]) if spec04d_plan else parent_header["summary"]["included_logical_atoms"]
    covered = [item for item in coverage["source_spans"] if item.get("mapping_id")]
    if len(included) != expected_included or len(covered) != len(included): errors.append("included coverage count")
    if len({item["block_id"] for item in covered}) != len(covered): errors.append("duplicate covered block")
    if any(item["verification_status"] != "closed" for item in coverage["source_spans"]): errors.append("unclosed coverage record")
    if len(plan["nodes"]) != len(execution["emissions"]) or {x["render_node_id"] for x in plan["nodes"]} != {x["render_node_id"] for x in execution["emissions"]}: errors.append("plan emission mismatch")
    if media["summary"]["asset_failures"] or media["summary"]["open_media_reviews"]: errors.append("media closure")

    for item in commit["bound_artifacts"]:
        path = run / item["path"]
        if not path.exists() or sha(path) != item["sha256"]: errors.append("commit artifact " + item["path"])
    run_manifest = read(run / "manifests/run_manifest.json")
    for item in run_manifest["files"]:
        path = run / item["path"]
        if not path.exists() or sha(path) != item["sha256"] or path.stat().st_size != item["size"]: errors.append("run manifest " + item["path"])

    result = {
        "schema_version": "render-coverage-independent-validation/1.0",
        "status": "passed" if not errors else "failed",
        "errors": errors,
        "checks": {
            "ledger_snapshot_id": header["ledger_snapshot_id"],
            "ledger_payload_sha256": header["current_ledger_hash"],
            "included_logical_atoms": len(included),
            "render_nodes": len(plan["nodes"]),
            "actual_emissions": len(execution["emissions"]),
            "coverage_records": len(coverage["source_spans"]),
            "source_asset_image_nodes": media["summary"]["source_asset_image_nodes"],
            "source_region_image_nodes": media["summary"]["source_region_image_nodes"],
            "cv_hard_gates": len(report["gate_results"]),
            "open_decisions": index["summary"]["open"],
            "run_manifest_files_verified": len(run_manifest["files"]),
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == "__main__":
    main()
