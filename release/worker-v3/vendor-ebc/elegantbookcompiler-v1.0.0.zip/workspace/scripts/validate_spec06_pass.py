#!/usr/bin/env python3
"""Independently validate a passed Spec 06 D -> L -> M evidence package."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def readl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def confirmed_blocking_count(value: dict[str, Any]) -> int:
    """Read the blocking-defect count across compatible Spec 06 schemas."""
    if "confirmed_v0_v1_count" in value:
        return int(value["confirmed_v0_v1_count"])
    return int(value.get("confirmed_v0_v1_v2_count", 0))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--review-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--coverage-run", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    review = sample / "runs" / args.review_run
    compile_run = sample / "runs" / args.compile_run
    coverage = sample / "runs" / args.coverage_run
    output = args.output.resolve()
    checks: list[dict[str, Any]] = []

    def check(gate: str, condition: bool, evidence: str) -> None:
        checks.append({"gate": gate, "status": "passed" if condition else "failed", "evidence": evidence})

    manifest = read(review / "manifests/final_review_manifest.json")
    acceptance = read(review / "final_acceptance.json")
    page_review = read(review / "reports/page_review.json")
    page_rows = readl(review / "reports/final_page_hash_ledger.jsonl")
    queue = read(review / "qa/human_review_queue.json")
    anomalies = read(review / "reports/automated_anomalies.json")
    source_pages = read(review / "reports/source_page_coverage.json")
    source_blocks = read(review / "reports/source_block_coverage.json")
    order = read(review / "reports/reading_order_audit.json")
    media = read(review / "reports/formula_table_image_audit.json")
    semantic = read(review / "reports/semantic_mapping_audit.json")
    toc = read(review / "reports/toc_page_number_audit.json")
    evidence = read(review / "reports/human_visual_review_evidence.json")
    index = read(review / "decisions/canonical_decision_index.json")
    decisions = readl(review / "decisions/final_decisions.jsonl")
    ledger_rows = readl(review / "ledgers/canonical_block_ledger.jsonl")
    ledger_header = ledger_rows[0]
    ledger_manifest = read(review / "ledgers/ledger_manifest.json")
    build = read(compile_run / "manifests/build_manifest.json")
    compile_report = read(compile_run / "reports/compile_report.json")
    template_report = read(compile_run / "reports/template_integrity_final_report.json")
    render_manifest = read(compile_run / "final_render_pack/manifest.json")
    parent_ledger = coverage / "ledgers/canonical_block_ledger.jsonl"
    parent_ledger_manifest = read(coverage / "ledgers/ledger_manifest.json")
    parent_index = coverage / "decisions/canonical_decision_index.json"
    final_pdf = compile_run / build["artifacts"]["final_pdf"]["path"]
    final_zip = compile_run / build["artifacts"]["formal_zip"]["path"]

    check("FR-H01", compile_report["spec_status"] == "passed" and template_report["status"] == "passed" and parent_ledger_manifest["spec_status"] == "passed" and parent_ledger_manifest["ledger_checkpoint"] == "render_coverage", "Spec 05 and render_coverage are passed")
    check("FR-H02", acceptance["build_id"] == build["build_id"] and acceptance["final_pdf_sha256"] == sha(final_pdf) and acceptance["final_zip_sha256"] == sha(final_zip), "build/PDF/ZIP bindings match live files")
    physical = [row["physical_page"] for row in page_rows]
    check("FR-H03", len(page_rows) == render_manifest["page_count"] == compile_report["pdf"]["pages"] and physical == list(range(1, len(page_rows) + 1)), f"{len(page_rows)} contiguous page records")
    raster_ok = all(row["raster_hash_verified"] and (compile_run / "final_render_pack/pages" / f"page-{row['physical_page']:03d}.png").is_file() and sha(compile_run / "final_render_pack/pages" / f"page-{row['physical_page']:03d}.png") == row["raster_sha256"] for row in page_rows)
    check("FR-H04", raster_ok, "every raster exists and matches its page-ledger hash")
    check("FR-H05", all(row["page_status"] == "human_reviewed_passed" for row in page_rows), "all page decisions passed; no unexplained blank or duplicate")
    check("FR-H06", confirmed_blocking_count(page_review) == 0 and page_review["all_pages_human_reviewed"], "full visual review confirmed no blocking clipping/overlap")
    check("FR-H07", source_pages["covered_source_pages"] == source_pages["included_source_pages"], f"{source_pages['covered_source_pages']}/{source_pages['included_source_pages']} source pages")
    check("FR-H08", source_blocks["summary"]["covered"] == source_blocks["summary"]["included_logical_atoms"], f"{source_blocks['summary']['covered']}/{source_blocks['summary']['included_logical_atoms']} logical atoms")
    check("FR-H09", anomalies["confirmed_v0_v1_v2_count"] == 0, "no confirmed unsourced addition")
    check("FR-H10", source_blocks["summary"]["covered"] == source_blocks["summary"]["included_logical_atoms"] and confirmed_blocking_count(manifest["summary"]) == 0, "no confirmed omission or duplication")
    check("FR-H11", not order["anchor_order_inversions"] and not order["source_page_mapping_inversions"] and order["render_orders_contiguous"], f"{order['unique_visible_anchors']} anchors and zero inversions")
    check("FR-H12", media["status"] == "passed" and media["visual_source_region_review"] == "passed" and media["asset_failures"] == 0, f"{media['source_asset_image_nodes']} assets and {media['source_region_image_nodes']} regions closed")
    check("FR-H13", semantic["status"] == "passed" and semantic["visual_semantic_mapping_review"] == "passed" and not semantic["heading_orphan_candidates"], "semantic mapping and visible answers passed")
    check("FR-H14", toc["status"] == "passed" and toc["passed"] == toc["toc_nodes"] == toc["outline_nodes"] and toc["needs_review"] == 0, f"{toc['passed']}/{toc['toc_nodes']} TOC nodes")
    check("FR-H15", page_rows[-1]["mapped_source_pages"] and page_rows[-1]["page_status"] == "human_reviewed_passed", "substantive final body tail is mapped and reviewed")
    check("FR-H16", confirmed_blocking_count(page_review) == 0 and all(row["page_status"] == "human_reviewed_passed" for row in page_rows), "no visible internal residue confirmed")
    check("FR-H17", anomalies["human_review_open_count"] == 0 and anomalies["confirmed_v0_v1_v2_count"] == 0 and all(row["status"] == "false_positive" for row in anomalies["anomalies"]), f"{len(anomalies['anomalies'])} candidates closed; no V0/V1")
    check("FR-H18", queue["open_count"] == 0 and queue["closed_count"] == len(queue["items"]) and evidence["all_pages_human_reviewed"] and evidence["reviewed_page_count"] == len(page_rows), f"{queue['closed_count']} queue items closed and {len(page_rows)} pages reviewed")

    d_no_l_ref = "final_verified" not in json.dumps(index, ensure_ascii=False)
    check("FR-H19", index["spec_status"] == "passed" and index["summary"]["open"] == 0 and index["summary"]["invalidated"] == 0 and index["parent_index_hash"] == sha(parent_index) and d_no_l_ref and sha(review / "decisions/final_decisions.jsonl") == index["decision_event_files"][-1]["sha256"] and len(decisions) == 5, "decision index D is frozen, clean, and acyclic")
    check("FR-H20", ledger_header["ledger_checkpoint"] == "final_verified" and ledger_header["spec_status"] == "passed" and ledger_header["parent_ledger_file_sha256"] == sha(parent_ledger) and ledger_header["canonical_decision_index_hash"] == sha(review / "decisions/canonical_decision_index.json") and ledger_manifest["artifact_sha256"] == sha(review / "ledgers/canonical_block_ledger.jsonl"), "final_verified child ledger L binds parent and D")
    check("FR-H21", acceptance["manifest_kind"] == "spec06_acceptance_commit_M" and acceptance["decision_index_D"]["sha256"] == sha(review / "decisions/canonical_decision_index.json") and acceptance["final_verified_ledger_L"]["sha256"] == sha(review / "ledgers/canonical_block_ledger.jsonl") and acceptance["page_review"]["sha256"] == sha(review / "reports/page_review.json") and acceptance["page_ledger"]["sha256"] == sha(review / "reports/final_page_hash_ledger.jsonl"), "acceptance commit M binds D, L, page evidence, PDF, and ZIP")

    file_checks = []
    for item in manifest["files"]:
        path = review / item["path"]
        ok = path.is_file() and sha(path) == item["sha256"] and path.stat().st_size == item["size"]
        file_checks.append(ok)
    check("MANIFEST", all(file_checks), f"{sum(file_checks)}/{len(file_checks)} immutable run files match manifest")
    check("ACCEPTANCE_BOUNDARY", acceptance["spec_status"] == "passed" and acceptance["acceptance_status"] == "ready_for_user_acceptance" and acceptance["human_accepted"] is False and acceptance["user_acceptance_record"] is None, "ready for user acceptance without claiming human acceptance")

    failed = [item["gate"] for item in checks if item["status"] != "passed"]
    report = {
        "schema_version": "spec06-independent-validation/1.0",
        "review_run": args.review_run,
        "spec_status": "passed" if not failed else "failed",
        "acceptance_status": acceptance["acceptance_status"],
        "human_accepted": acceptance["human_accepted"],
        "checks": checks,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_gates": failed},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
