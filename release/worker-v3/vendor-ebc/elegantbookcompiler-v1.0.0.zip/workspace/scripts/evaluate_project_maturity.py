#!/usr/bin/env python3
"""Evaluate the evidence-defined project_mature gate without changing it."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stable-manifest", type=Path, required=True)
    parser.add_argument("--stable-validation", type=Path, required=True)
    parser.add_argument("--scope", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--hardcoding-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-mature", action="store_true")
    args = parser.parse_args()
    stable = load(args.stable_manifest)
    validation = load(args.stable_validation)
    scope = load(args.scope)
    matrix = load(args.matrix)
    hardcoding = load(args.hardcoding_report)

    samples = matrix.get("samples", [])
    families = sorted({item.get("family") for item in samples if item.get("family")})
    languages = sorted({item.get("language") for item in samples if item.get("language")})
    formal_native = [item for item in samples if item.get("pipeline_class") == "formal_native"]
    unsupported = list(scope.get("unsupported_in_v1", []))
    unverified = list(scope.get("experimental_or_unverified", []))
    criteria = {
        "stable_release_independently_validated": validation.get("status") == "passed" and stable.get("status") == "stable_release",
        "representative_cross_type_cross_language_sample_set": len(families) >= 3 and {"zh", "en"}.issubset(languages),
        "all_release_samples_human_accepted": len(samples) >= 4 and all(item.get("expected", {}).get("human_accepted") is True for item in samples),
        "no_sample_hardcoding": hardcoding.get("status") == "passed" and hardcoding.get("summary", {}).get("violations") == 0,
        "all_target_material_types_and_languages_covered": False,
        "no_unresolved_hard_gates_or_unverified_target_areas": not unsupported and not unverified,
        "all_representative_products_formal_native": len(formal_native) == len(samples),
        "large_scale_operational_evidence": "very large batch throughput" not in unverified,
    }
    project_mature = all(criteria.values())
    blockers = [name for name, passed in criteria.items() if not passed]
    report = {
        "schema_version": "elegantbookcompiler-project-maturity-assessment/1.0",
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "status": "passed" if project_mature else "not_achieved",
        "project_mature": project_mature,
        "eligible_to_declare_project_mature": project_mature,
        "criteria": criteria,
        "blockers": blockers,
        "observed_coverage": {
            "sample_count": len(samples),
            "families": families,
            "languages": languages,
            "formal_native_samples": len(formal_native),
            "migration_compatibility_samples": len(samples) - len(formal_native),
        },
        "unverified_or_unsupported": unsupported + unverified,
        "evidence": {
            "stable_manifest": {"path": str(args.stable_manifest), "sha256": sha256(args.stable_manifest)},
            "stable_validation": {"path": str(args.stable_validation), "sha256": sha256(args.stable_validation)},
            "support_scope": {"path": str(args.scope), "sha256": sha256(args.scope)},
            "regression_matrix": {"path": str(args.matrix), "sha256": sha256(args.matrix)},
            "hardcoding_report": {"path": str(args.hardcoding_report), "sha256": sha256(args.hardcoding_report)},
        },
        "claim_boundary": "A user authorization can initiate this evaluation but cannot replace missing product evidence. Stable release and production publication are not synonyms for project_mature.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 1 if args.require_mature and not project_mature else 0


if __name__ == "__main__":
    raise SystemExit(main())
