#!/usr/bin/env python3
"""Build a diagnostic Spec 06 all-page review pack without making acceptance decisions."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import re
import subprocess
import tempfile
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageChops, ImageDraw, JpegImagePlugin  # noqa: F401 - registers PDF JPEG encoder

try:
    from pypdf import PdfReader
except ImportError:  # Keep the review gate usable in the bundled PyMuPDF runtime.
    PdfReader = None
    import fitz


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def readl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def chash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def rel(origin: Path, target: Path) -> str:
    return Path(os.path.relpath(target, origin)).as_posix()


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def writel(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def norm(text: str) -> str:
    return "".join(
        char.lower() for char in text
        if char.isalnum() or "\u3400" <= char <= "\u9fff" or char in "□■○△▲"
    )


def node_candidates(node: dict[str, Any]) -> list[str]:
    payload = node.get("payload", {})
    values: list[str] = []
    for key in ("text", "title", "raw_content"):
        if isinstance(payload.get(key), str):
            values.append(payload[key])
    if isinstance(payload.get("segments"), list):
        values.extend(item for item in payload["segments"] if isinstance(item, str))
    if isinstance(payload.get("body"), list):
        values.extend(item.get("raw_content") for item in payload["body"] if isinstance(item, dict) and isinstance(item.get("raw_content"), str))
    return sorted({norm(value) for value in values if len(norm(value)) >= 8}, key=len, reverse=True)


def flatten_outline(reader: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []

    def walk(items: list[Any], level: int = 0) -> None:
        for item in items:
            if isinstance(item, list):
                walk(item, level + 1)
            else:
                result.append({
                    "title": item.title,
                    "level": level,
                    "physical_page": reader.get_destination_page_number(item) + 1,
                    "top": float(item.get("/Top")) if item.get("/Top") is not None else None,
                })

    walk(reader.outline)
    return result


def pdf_navigation(path: Path) -> tuple[list[str], list[dict[str, Any]], int]:
    """Read page labels and outline without weakening either review assertion."""
    if PdfReader is not None:
        reader = PdfReader(path)
        return reader.page_labels, flatten_outline(reader), len(reader.pages)

    document = fitz.open(path)
    try:
        labels = [document[index].get_label() for index in range(len(document))]
        outline = []
        for level, title, physical_page, destination in document.get_toc(simple=False):
            point = destination.get("to") if isinstance(destination, dict) else None
            outline.append({
                "title": title,
                "level": level - 1,
                "physical_page": physical_page,
                "top": float(point.y) if point is not None else None,
            })
        return labels, outline, len(document)
    finally:
        document.close()


def average_hash(image: Image.Image, size: int = 8) -> str:
    gray = image.convert("L").resize((size, size))
    pixels = list(gray.get_flattened_data())
    mean = sum(pixels) / len(pixels)
    bits = "".join("1" if value < mean else "0" for value in pixels)
    return f"{int(bits, 2):0{size * size // 4}x}"


def escalate(current: str, candidate: str) -> str:
    rank = {"V3": 0, "V2": 1, "V1": 2, "V0": 3}
    return candidate if rank[candidate] > rank[current] else current


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--intake-run", required=True)
    parser.add_argument("--source-run", required=True)
    parser.add_argument("--semantic-run", required=True)
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--coverage-run", required=True)
    parser.add_argument("--output-run", required=True)
    parser.add_argument("--low-density-threshold", type=float, default=0.03)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    intake = sample / "runs" / args.intake_run
    source = sample / "runs" / args.source_run
    semantic = sample / "runs" / args.semantic_run
    compile_run = sample / "runs" / args.compile_run
    coverage_run = sample / "runs" / args.coverage_run
    out = sample / "runs" / args.output_run
    if out.exists():
        raise SystemExit(f"immutable output already exists: {out}")
    for directory in ("reports", "qa", "review", "manifests"):
        (out / directory).mkdir(parents=True, exist_ok=False)

    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    source_pdf = next((intake / "inputs/source").glob("*.pdf"))
    final_pdf = compile_run / "delivery/elegantbook-output.pdf"
    render_manifest_path = compile_run / "final_render_pack/manifest.json"
    render_manifest = read(render_manifest_path)
    render_config_sha256 = render_manifest.get("render_config_sha256") or chash(render_manifest.get("renderer", {}))
    source_render_ledger_path = source / "ledgers/source_page_render_ledger.jsonl"
    if not source_render_ledger_path.is_file():
        source_render_ledger_path = intake / "ledgers/source_page_render_ledger.jsonl"
    source_render_rows = readl(source_render_ledger_path)
    source_scope = read(source / "ledgers/source_scope_ledger.json")
    reading_order = read(source / "ledgers/reading_order_ledger.json")
    plan = read(semantic / "render/render_plan.json")
    semantic_mapping_path = semantic / "ledgers/semantic_mapping_ledger.json"
    if not semantic_mapping_path.is_file():
        semantic_mapping_path = semantic / "semantic/semantic_mapping_ledger.json"
    semantic_mapping = read(semantic_mapping_path)
    coverage_rows = readl(coverage_run / "ledgers/canonical_block_ledger.jsonl")
    coverage_header, block_rows = coverage_rows[0], coverage_rows[1:]
    block_coverage = read(coverage_run / "ledgers/block_coverage_ledger.json")
    media_coverage = read(coverage_run / "ledgers/media_ledger.json")
    compile_report = read(compile_run / "reports/compile_report.json")
    template_integrity = read(compile_run / "reports/template_integrity_final_report.json")
    build_manifest = read(compile_run / "manifests/build_manifest.json")

    if sha(final_pdf) != render_manifest["final_pdf"]["sha256"]:
        raise SystemExit("final PDF hash does not match the immutable render manifest")
    if sha(source_pdf) != coverage_header["material_identity"]["source_pdf_sha256"]:
        raise SystemExit("source PDF hash does not match the canonical ledger")

    with tempfile.NamedTemporaryFile(suffix=".txt") as temp:
        subprocess.run(["pdftotext", "-layout", str(final_pdf), temp.name], check=True)
        page_texts = Path(temp.name).read_text(encoding="utf-8").split("\f")
    if page_texts and not page_texts[-1].strip():
        page_texts.pop()
    normalized_pages = [norm(text) for text in page_texts]

    labels, outline, page_count = pdf_navigation(final_pdf)
    if page_count != len(render_manifest["pages"]) or page_count != len(page_texts):
        raise SystemExit("PDF, render manifest, or extracted-text page count mismatch")

    exact_anchor: dict[str, dict[str, Any]] = {}
    for node in plan["nodes"]:
        for candidate in node_candidates(node):
            hits = [index + 1 for index, text in enumerate(normalized_pages) if candidate in text]
            if len(hits) == 1:
                exact_anchor[node["render_node_id"]] = {"physical_page": hits[0], "anchor": candidate, "anchor_length": len(candidate)}
                break
    exact_pairs = [(node["render_order"], exact_anchor[node["render_node_id"]]["physical_page"], node["render_node_id"]) for node in plan["nodes"] if node["render_node_id"] in exact_anchor]
    exact_pairs.sort()
    inversions = [
        {"previous": exact_pairs[index - 1], "current": exact_pairs[index]}
        for index in range(1, len(exact_pairs)) if exact_pairs[index][1] < exact_pairs[index - 1][1]
    ]
    anchor_orders = [item[0] for item in exact_pairs]

    node_page: dict[str, dict[str, Any]] = {}
    for node in plan["nodes"]:
        node_id = node["render_node_id"]
        order = node["render_order"]
        if node_id in exact_anchor:
            node_page[node_id] = {**exact_anchor[node_id], "mapping_method": "unique_visible_text_anchor"}
            continue
        position = bisect_left(anchor_orders, order)
        if position == 0:
            estimated = exact_pairs[0][1]
        elif position == len(exact_pairs):
            estimated = exact_pairs[-1][1]
        else:
            left_order, left_page, _ = exact_pairs[position - 1]
            right_order, right_page, _ = exact_pairs[position]
            fraction = (order - left_order) / max(1, right_order - left_order)
            estimated = round(left_page + fraction * (right_page - left_page))
            estimated = max(left_page, min(right_page, estimated))
        node_page[node_id] = {"physical_page": estimated, "anchor": None, "anchor_length": 0, "mapping_method": "monotonic_interpolation_between_unique_anchors"}

    blocks_by_id = {row["block_id"]: row for row in block_rows}
    source_blocks: list[dict[str, Any]] = []
    source_pages: dict[int, dict[str, Any]] = {}
    nodes_by_source_page: dict[int, list[str]] = defaultdict(list)
    exact_nodes_by_source_page: dict[int, list[str]] = defaultdict(list)
    for node in plan["nodes"]:
        output_page = node_page[node["render_node_id"]]["physical_page"]
        for block_id in node["source_block_ids"]:
            source_page = blocks_by_id[block_id]["pdf_physical_page"]
            nodes_by_source_page[source_page].append(node["render_node_id"])
            if node["render_node_id"] in exact_anchor:
                exact_nodes_by_source_page[source_page].append(node["render_node_id"])
            source_blocks.append({
                "block_id": block_id,
                "source_pdf_page": source_page,
                "render_node_id": node["render_node_id"],
                "final_pdf_page": output_page,
                "final_page_label": labels[output_page - 1],
                "mapping_method": node_page[node["render_node_id"]]["mapping_method"],
                "target_construct": node["target_construct"],
                "status": "covered",
            })

    source_scope_entries = source_scope.get("page_entries", source_scope.get("pages", []))
    included_page_entries = [
        entry
        for entry in source_scope_entries
        if entry.get("page_scope_status", entry.get("status")) == "included"
    ]
    included_blocks_per_source_page = Counter(
        row["pdf_physical_page"] for row in block_rows if row.get("scope_status") == "included"
    )
    source_render_by_page = {row["physical_page"]: row for row in source_render_rows}
    render_order_by_id = {node["render_node_id"]: node["render_order"] for node in plan["nodes"]}
    for entry in included_page_entries:
        source_page = entry["physical_page"]
        source_render = source_render_by_page[source_page]
        source_raster_value = source_render.get("raster_path", source_render.get("raster_ref"))
        source_raster = Path(source_raster_value)
        if not source_raster.is_absolute():
            source_raster = source / source_raster
        node_ids = sorted(set(nodes_by_source_page[source_page]), key=render_order_by_id.__getitem__)
        output_pages = sorted({node_page[node_id]["physical_page"] for node_id in node_ids})
        exact_pages = sorted({node_page[node_id]["physical_page"] for node_id in exact_nodes_by_source_page[source_page]})
        source_pages[source_page] = {
            "source_pdf_page": source_page,
            "source_raster_ref": rel(out, source_raster),
            "source_raster_sha256": source_render["raster_sha256"],
            "included_block_count": entry.get("block_scope_counts", {}).get("included", included_blocks_per_source_page[source_page]),
            "render_node_count": len(node_ids),
            "final_pdf_pages": output_pages,
            "final_page_labels": [labels[page - 1] for page in output_pages],
            "unique_anchor_pages": exact_pages,
            "mapping_confidence": "exact_visible_anchor_on_source_page" if exact_pages else "inferred_from_monotonic_neighbor_anchors",
            "status": "covered" if output_pages else "uncovered",
        }

    source_page_sequence = [source_pages[entry["physical_page"]] for entry in included_page_entries]
    page_mapping_inversions = []
    last_min = 0
    for item in source_page_sequence:
        current = min(item["final_pdf_pages"]) if item["final_pdf_pages"] else 0
        if current < last_min:
            page_mapping_inversions.append({"source_pdf_page": item["source_pdf_page"], "previous_final_page": last_min, "current_final_page": current})
        last_min = max(last_min, current)

    anomalies: list[dict[str, Any]] = []
    page_records: list[dict[str, Any]] = []
    exact_raster_hashes: dict[str, list[int]] = defaultdict(list)
    ahashes: dict[str, list[int]] = defaultdict(list)
    internal_patterns = re.compile(r"(render_node_id|source_block_id|/Users/|golden-sample|TODO|FIXME|```|<html|\\begin\{|Markdown)", re.I)
    markdown_table_separator = re.compile(r"\|\s*\|\s*:?-{3,}:?\s*\||\|\s*:?-{3,}:?\s*\|", re.I)
    framework_pages = {1, 2, 3}
    source_pages_by_final: dict[int, set[int]] = defaultdict(set)
    blocks_by_final: dict[int, list[str]] = defaultdict(list)
    for item in source_blocks:
        source_pages_by_final[item["final_pdf_page"]].add(item["source_pdf_page"])
        blocks_by_final[item["final_pdf_page"]].append(item["block_id"])
    source_region_final_pages = sorted({node_page[node["render_node_id"]]["physical_page"] for node in plan["nodes"] if node["target_construct"] == "source_region_image"})

    for manifest_page in render_manifest["pages"]:
        index = manifest_page["index"]
        raster = compile_run / "final_render_pack" / manifest_page["raster_path"]
        raster_ok = raster.exists() and sha(raster) == manifest_page["raster_sha256"]
        with Image.open(raster) as image:
            rgb = image.convert("RGB")
            gray = rgb.convert("L")
            mask = gray.point(lambda value: 255 if value < 248 else 0)
            bbox = mask.getbbox()
            content_bbox = list(bbox) if bbox else None
            histogram = gray.histogram()
            measured_nonwhite_ratio = sum(histogram[:248]) / max(1, image.width * image.height)
            edge_touch = bool(index not in framework_pages and bbox and (bbox[0] <= 2 or bbox[1] <= 2 or bbox[2] >= image.width - 2 or bbox[3] >= image.height - 2))
            ahash = average_hash(rgb)
        exact_raster_hashes[manifest_page["raster_sha256"]].append(index)
        ahashes[ahash].append(index)
        text = page_texts[index - 1]
        issues: list[str] = []
        risk = "V3"
        if not raster_ok:
            issues.append("render_hash_or_path_mismatch")
            risk = "V0"
        nonwhite_ratio = manifest_page.get("nonwhite_ratio_thumbnail", measured_nonwhite_ratio)
        if nonwhite_ratio < args.low_density_threshold and index not in framework_pages:
            issues.append("low_content_density_candidate")
            risk = escalate(risk, "V2")
        if edge_touch:
            issues.append("content_touches_page_edge_candidate")
            risk = "V1"
        if "\ufffd" in text or "�" in text:
            issues.append("replacement_character_candidate")
            risk = "V1"
        residues = sorted(set(match.group(0) for match in internal_patterns.finditer(text)))
        if markdown_table_separator.search(text):
            residues.append("markdown_table_separator")
        if residues:
            issues.append("visible_internal_residue_candidate")
            risk = "V1"
        mapped_source_pages = sorted(source_pages_by_final[index])
        if index > 3 and not mapped_source_pages:
            issues.append("body_page_without_source_mapping_candidate")
            risk = escalate(risk, "V2")
        if index in source_region_final_pages:
            issues.append("high_risk_source_region_representation")
            risk = escalate(risk, "V2")
        status = "human_review_required" if risk in {"V0", "V1", "V2"} else "automatic_pass"
        record = {
            "physical_page": index,
            "page_label": labels[index - 1],
            "pdf_sha256": sha(final_pdf),
            "render_config_sha256": render_config_sha256,
            "raster_ref": rel(out, raster),
            "raster_sha256": manifest_page["raster_sha256"],
            "raster_hash_verified": raster_ok,
            "raster_width_px": manifest_page["raster_width_px"],
            "raster_height_px": manifest_page["raster_height_px"],
            "page_width_pt": manifest_page["pdf_width_pt"],
            "page_height_pt": manifest_page["pdf_height_pt"],
            "rotation": manifest_page["rotation"],
            "nonwhite_ratio": nonwhite_ratio,
            "content_bbox_px": content_bbox,
            "perceptual_average_hash": ahash,
            "extracted_text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "extracted_text_length": len(norm(text)),
            "mapped_source_pages": mapped_source_pages,
            "mapped_source_blocks": sorted(set(blocks_by_final[index])),
            "automatic_findings": issues,
            "candidate_severity": risk,
            "page_status": status,
            "human_decision_refs": [],
        }
        page_records.append(record)
        for issue in issues:
            anomalies.append({
                "anomaly_id": f"AUTO-P{index:03d}-{issue}",
                "physical_page": index,
                "page_label": labels[index - 1],
                "detector": "spec06-review-pack/1.0",
                "candidate_severity": risk,
                "status": "detected_candidate",
                "finding": issue,
                "evidence_refs": [record["raster_ref"]],
            })

    for digest, pages in exact_raster_hashes.items():
        if len(pages) > 1:
            anomalies.append({"anomaly_id": "AUTO-DUP-SHA-" + digest[:12], "physical_pages": pages, "detector": "exact-raster-sha256/1.0", "candidate_severity": "V1", "status": "detected_candidate", "finding": "exact_duplicate_page_raster", "evidence_refs": [page_records[page - 1]["raster_ref"] for page in pages]})
    for digest, pages in ahashes.items():
        if len(pages) > 1 and len({page_records[page - 1]["raster_sha256"] for page in pages}) > 1:
            anomalies.append({"anomaly_id": "AUTO-DUP-AHASH-" + digest, "physical_pages": pages, "detector": "average-hash/1.0", "candidate_severity": "V2", "status": "detected_candidate", "finding": "visually_similar_page_candidate", "evidence_refs": [page_records[page - 1]["raster_ref"] for page in pages]})

    body_text_norm = "".join(normalized_pages[3:])
    excluded_leaks: list[dict[str, Any]] = []
    for row in block_rows:
        if row.get("scope_status") != "excluded":
            continue
        candidate = norm(row.get("raw_content", ""))
        if len(candidate) >= 24 and candidate in body_text_norm:
            excluded_leaks.append({"block_id": row["block_id"], "source_pdf_page": row["pdf_physical_page"], "normalized_excerpt": candidate[:80]})

    toc_nodes = [node for node in plan["nodes"] if node["construct_parameters"].get("toc") is True]
    outline_by_title: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in outline:
        outline_by_title[norm(item["title"])].append(item)
    toc_lines = page_texts[1].splitlines() + page_texts[2].splitlines()
    toc_audit: list[dict[str, Any]] = []
    for node in toc_nodes:
        title = node["payload"]["title"]
        matches = outline_by_title[norm(title)]
        destination = matches[0] if len(matches) == 1 else None
        destination_label = labels[destination["physical_page"] - 1] if destination else None
        line_matches = [line for line in toc_lines if norm(title) in norm(line)]
        number_matches = bool(destination_label and any(re.search(rf"(?:^|\s){re.escape(destination_label)}\s*$", line) for line in line_matches))
        body_title_present = bool(destination and norm(title) in normalized_pages[destination["physical_page"] - 1])
        toc_audit.append({
            "render_node_id": node["render_node_id"],
            "title": title,
            "outline_match_count": len(matches),
            "destination_physical_page": destination["physical_page"] if destination else None,
            "destination_page_label": destination_label,
            "toc_line": line_matches[0].strip() if line_matches else None,
            "toc_page_number_matches_destination_label": number_matches,
            "title_present_on_destination_page": body_title_present,
            "status": "passed" if len(matches) == 1 and number_matches and body_title_present else "needs_review",
        })

    heading_orphans: list[dict[str, Any]] = []
    for node in plan["nodes"]:
        if node["target_construct"] not in {"chapter*", "section*", "subsection*", "subsubsection*"}:
            continue
        title = norm(node["payload"].get("title", ""))
        mapped = node_page[node["render_node_id"]]["physical_page"]
        page_norm = normalized_pages[mapped - 1]
        if title and page_norm.endswith(title):
            heading_orphans.append({"render_node_id": node["render_node_id"], "title": node["payload"]["title"], "physical_page": mapped})

    risk_pages = sorted({item.get("physical_page") for item in anomalies if item.get("physical_page") and item["candidate_severity"] in {"V0", "V1", "V2"}})
    risk_pages.extend(page for page in range(4, page_count + 1) if not any(pair[1] == page for pair in exact_pairs))
    risk_pages = sorted(set(risk_pages))
    source_pages_without_exact_anchor = [item["source_pdf_page"] for item in source_page_sequence if not item["unique_anchor_pages"]]

    final_page_ledger_path = out / "reports/final_page_hash_ledger.jsonl"
    writel(final_page_ledger_path, page_records)
    source_page_coverage = {
        "schema_version": "source-page-coverage/1.0",
        "generated_at": timestamp,
        "source_pdf_sha256": sha(source_pdf),
        "final_pdf_sha256": sha(final_pdf),
        "included_source_pages": len(source_page_sequence),
        "covered_source_pages": sum(item["status"] == "covered" for item in source_page_sequence),
        "pages_with_unique_visible_anchor": sum(bool(item["unique_anchor_pages"]) for item in source_page_sequence),
        "pages_inferred_from_neighbor_anchors": source_pages_without_exact_anchor,
        "page_mapping_inversions": page_mapping_inversions,
        "pages": source_page_sequence,
    }
    write(out / "reports/source_page_coverage.json", source_page_coverage)
    write(out / "reports/source_block_coverage.json", {
        "schema_version": "source-block-final-page-coverage/1.0",
        "generated_at": timestamp,
        "canonical_ledger_snapshot_id": coverage_header["ledger_snapshot_id"],
        "canonical_ledger_payload_hash": coverage_header["current_ledger_hash"],
        "final_pdf_sha256": sha(final_pdf),
        "summary": {"included_logical_atoms": len(source_blocks), "covered": sum(item["status"] == "covered" for item in source_blocks), "unique_visible_anchor_nodes": len(exact_anchor), "interpolated_nodes": len(plan["nodes"]) - len(exact_anchor)},
        "blocks": source_blocks,
    })
    write(out / "reports/reading_order_audit.json", {
        "schema_version": "reading-order-final-audit/1.0",
        "generated_at": timestamp,
        "source_reading_order_sha256": sha(source / "ledgers/reading_order_ledger.json"),
        "render_plan_sha256": sha(semantic / "render/render_plan.json"),
        "unique_visible_anchors": len(exact_pairs),
        "anchor_order_inversions": inversions,
        "source_page_mapping_inversions": page_mapping_inversions,
        "render_orders_contiguous": [node["render_order"] for node in plan["nodes"]] == list(range(1, len(plan["nodes"]) + 1)),
        "status": "passed" if not inversions and not page_mapping_inversions else "failed",
    })
    write(out / "reports/formula_table_image_audit.json", {
        "schema_version": "formula-table-image-final-audit/1.0",
        "generated_at": timestamp,
        "media_coverage_sha256": sha(coverage_run / "ledgers/media_ledger.json"),
        "final_pdf_sha256": sha(final_pdf),
        "source_type_counts": media_coverage["source_type_counts"],
        "source_asset_image_nodes": media_coverage["summary"]["source_asset_image_nodes"],
        "source_region_image_nodes": media_coverage["summary"]["source_region_image_nodes"],
        "source_region_final_pages": source_region_final_pages,
        "asset_failures": media_coverage["summary"]["asset_failures"],
        "open_media_reviews_from_render_coverage": media_coverage["summary"]["open_media_reviews"],
        "status": "passed_mechanically_pending_visual_risk_closure",
    })
    answer_nodes = [node for node in plan["nodes"] if (node.get("role") or node.get("payload", {}).get("semantic_role")) == "visible_answer"]
    write(out / "reports/semantic_mapping_audit.json", {
        "schema_version": "semantic-mapping-final-audit/1.0",
        "generated_at": timestamp,
        "semantic_mapping_sha256": sha(semantic_mapping_path),
        "template_integrity_sha256": sha(compile_run / "reports/template_integrity_final_report.json"),
        "assignments": len(semantic_mapping["assignments"]),
        "render_nodes": len(plan["nodes"]),
        "visible_answer_nodes": len(answer_nodes),
        "visible_answer_nodes_mapped_to_final_pages": sum(node["render_node_id"] in node_page for node in answer_nodes),
        "toc_nodes": len(toc_nodes),
        "outline_nodes": len(outline),
        "heading_orphan_candidates": heading_orphans,
        "status": "passed_mechanically_pending_visual_risk_closure",
    })
    write(out / "reports/toc_page_number_audit.json", {
        "schema_version": "toc-page-number-audit/1.0",
        "generated_at": timestamp,
        "toc_nodes": len(toc_nodes),
        "outline_nodes": len(outline),
        "passed": sum(item["status"] == "passed" for item in toc_audit),
        "needs_review": sum(item["status"] != "passed" for item in toc_audit),
        "entries": toc_audit,
    })
    write(out / "reports/automated_anomalies.json", {
        "schema_version": "automated-anomalies/1.0",
        "generated_at": timestamp,
        "detector_config": {"low_density_threshold": args.low_density_threshold, "edge_threshold_px": 2, "text_anchor_min_normalized_length": 8},
        "summary": dict(Counter(item["candidate_severity"] for item in anomalies)),
        "excluded_body_leak_candidates": excluded_leaks,
        "heading_orphan_candidates": heading_orphans,
        "anomalies": anomalies,
    })

    page_review = {
        "schema_version": "page-review/1.0-diagnostic",
        "generated_at": timestamp,
        "spec_status": "needs_review",
        "acceptance_status": "not_ready",
        "source_pdf_sha256": sha(source_pdf),
        "final_pdf_sha256": sha(final_pdf),
        "build_id": build_manifest["build_id"],
        "ledger_snapshot_id": coverage_header["ledger_snapshot_id"],
        "page_count": page_count,
        "automatic_page_checks_complete": len(page_records) == page_count,
        "risk_pages": risk_pages,
        "source_pages_without_exact_anchor": source_pages_without_exact_anchor,
        "pages": page_records,
        "scope_limit": "Diagnostic review pack only; detected candidates are not yet human decisions and no final acceptance is claimed.",
    }
    write(out / "reports/page_review.json", page_review)

    queue_items: list[dict[str, Any]] = []
    for page in risk_pages:
        record = page_records[page - 1]
        queue_items.append({
            "review_id": f"FR-PAGE-{page:03d}",
            "type": "final_page_visual_and_mapping_review",
            "status": "open",
            "final_pdf_page": page,
            "page_label": labels[page - 1],
            "source_pdf_pages": record["mapped_source_pages"],
            "candidate_findings": record["automatic_findings"] + (["no_unique_visible_text_anchor"] if not any(pair[1] == page for pair in exact_pairs) else []),
            "final_raster_ref": record["raster_ref"],
        })
    for source_page in source_pages_without_exact_anchor:
        queue_items.append({
            "review_id": f"FR-SOURCE-{source_page:03d}",
            "type": "source_page_mapping_review",
            "status": "open",
            "source_pdf_page": source_page,
            "final_pdf_pages": source_pages[source_page]["final_pdf_pages"],
            "candidate_findings": ["source_page_has_no_unique_visible_text_anchor"],
            "source_raster_ref": source_pages[source_page]["source_raster_ref"],
        })
    if excluded_leaks:
        queue_items.append({"review_id": "FR-EXCLUDED-LEAK", "type": "excluded_content_leak_review", "status": "open", "candidate_findings": excluded_leaks})
    if heading_orphans:
        queue_items.append({"review_id": "FR-HEADING-ORPHAN", "type": "heading_orphan_review", "status": "open", "candidate_findings": heading_orphans})
    toc_problems = [item for item in toc_audit if item["status"] != "passed"]
    if toc_problems:
        queue_items.append({"review_id": "FR-TOC-MISSING", "type": "toc_and_bookmark_review", "status": "open", "candidate_findings": toc_problems})
    queue_items.append({
        "review_id": "FR-SOURCE-REGION-PAGES",
        "type": "source_region_formula_table_visual_review",
        "status": "open",
        "final_pdf_pages": source_region_final_pages,
        "source_region_node_count": media_coverage["summary"]["source_region_image_nodes"],
        "candidate_findings": ["verify exact source-region representations remain legible and correctly anchored in final pages"],
    })
    write(out / "qa/human_review_queue.json", {
        "schema_version": "human-review-queue/1.0",
        "generated_at": timestamp,
        "spec_status": "needs_review",
        "open_count": len(queue_items),
        "items": queue_items,
    })

    contact_sheets = sorted((compile_run / "final_render_pack/contact_sheets").glob("sheet-*.jpg"))
    contact_images = [Image.open(path).convert("RGB") for path in contact_sheets]
    if not contact_images:
        page_paths = [compile_run / "final_render_pack" / item["raster_path"] for item in render_manifest["pages"]]
        for start in range(0, len(page_paths), 12):
            sheet = Image.new("RGB", (1000, 1080), "white")
            draw = ImageDraw.Draw(sheet)
            for offset, page_path in enumerate(page_paths[start:start + 12]):
                page_number = start + offset + 1
                with Image.open(page_path) as source_image:
                    thumb = source_image.convert("RGB")
                    thumb.thumbnail((220, 285))
                column = offset % 4
                row = offset // 4
                x = 20 + column * 245 + (220 - thumb.width) // 2
                y = 28 + row * 345
                sheet.paste(thumb, (x, y))
                draw.text((20 + column * 245, y + thumb.height + 6), f"Page {page_number}", fill="black")
            contact_images.append(sheet)
    contact_pdf_path = out / "review/page_contact_sheet.pdf"
    contact_images[0].save(contact_pdf_path, save_all=True, append_images=contact_images[1:], resolution=110)
    for image in contact_images:
        image.close()

    html_rows = []
    for page in page_records:
        source_links = " ".join(
            f'<a href="{html.escape(source_pages[source_page]["source_raster_ref"])}">S{source_page}</a>'
            for source_page in page["mapped_source_pages"]
        ) or "framework/unmapped"
        html_rows.append(
            "<tr>"
            f"<td>{page['physical_page']}</td><td>{html.escape(str(page['page_label']))}</td>"
            f"<td>{source_links}</td><td>{html.escape(', '.join(page['automatic_findings']) or 'none')}</td>"
            f"<td><a href=\"{html.escape(page['raster_ref'])}\"><img src=\"{html.escape(page['raster_ref'])}\"></a></td>"
            "</tr>"
        )
    (out / "review/page_review.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>Spec 06 page review</title>"
        "<style>body{font-family:sans-serif}table{border-collapse:collapse}td,th{border:1px solid #aaa;padding:4px;vertical-align:top}img{width:180px}</style>"
        f"<h1>Spec 06 diagnostic review pack</h1><p>Final PDF SHA-256: {sha(final_pdf)}</p>"
        "<table><thead><tr><th>Final page</th><th>Label</th><th>Source pages</th><th>Findings</th><th>Raster</th></tr></thead><tbody>"
        + "".join(html_rows) + "</tbody></table>", encoding="utf-8"
    )

    manifest = {
        "schema_version": "spec06-review-pack-manifest/1.0",
        "generated_at": timestamp,
        "run_id": args.output_run,
        "status": "needs_review",
        "source_pdf_sha256": sha(source_pdf),
        "final_pdf_sha256": sha(final_pdf),
        "build_id": build_manifest["build_id"],
        "ledger_snapshot_id": coverage_header["ledger_snapshot_id"],
        "inputs": {
            "render_manifest": {"path": rel(out, render_manifest_path), "sha256": sha(render_manifest_path)},
            "render_coverage_ledger": {"path": rel(out, coverage_run / "ledgers/canonical_block_ledger.jsonl"), "sha256": sha(coverage_run / "ledgers/canonical_block_ledger.jsonl")},
            "source_render_ledger": {"path": rel(out, source_render_ledger_path), "sha256": sha(source_render_ledger_path)},
            "compile_report": {"path": rel(out, compile_run / "reports/compile_report.json"), "sha256": sha(compile_run / "reports/compile_report.json")},
            "template_integrity": {"path": rel(out, compile_run / "reports/template_integrity_final_report.json"), "sha256": sha(compile_run / "reports/template_integrity_final_report.json")},
        },
        "summary": {
            "final_pages": page_count,
            "page_records": len(page_records),
            "included_source_pages": len(source_page_sequence),
            "covered_source_pages": sum(item["status"] == "covered" for item in source_page_sequence),
            "included_source_blocks": len(source_blocks),
            "covered_source_blocks": sum(item["status"] == "covered" for item in source_blocks),
            "unique_visible_node_anchors": len(exact_anchor),
            "anchor_order_inversions": len(inversions),
            "risk_pages": len(risk_pages),
            "open_human_reviews": len(queue_items),
        },
        "files": [
            {"path": path.relative_to(out).as_posix(), "sha256": sha(path), "size": path.stat().st_size}
            for path in sorted(out.rglob("*")) if path.is_file()
        ],
    }
    write(out / "manifests/review_pack_manifest.json", manifest)
    print(json.dumps({"run": str(out), "status": "needs_review", "summary": manifest["summary"], "excluded_leaks": len(excluded_leaks), "heading_orphans": len(heading_orphans)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
