#!/usr/bin/env python3
"""Validate release samples without mutating accepted immutable snapshots."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    matrix = load(args.matrix)
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "passed" if condition else "failed", "detail": detail})

    check("schema", matrix.get("schema_version") == "release-regression-matrix/1.0", matrix.get("schema_version"))
    template = workspace / matrix["fixed_template"]["path"]
    check("fixed_template", template.is_file() and sha256(template) == matrix["fixed_template"]["sha256"], matrix["fixed_template"])
    registry_path = workspace / matrix["registry"]["path"]
    registry_ok = registry_path.is_file() and sha256(registry_path) == matrix["registry"]["sha256"]
    check("registry_hash", registry_ok, matrix["registry"])
    registry = load(registry_path) if registry_ok else {}

    sample_summaries = []
    for sample in matrix.get("samples", []):
        sample_id = sample["sample_id"]
        acceptance_path = workspace / sample["acceptance"]["path"]
        acceptance_hash_ok = acceptance_path.is_file() and sha256(acceptance_path) == sample["acceptance"]["sha256"]
        check(f"{sample_id}:acceptance_hash", acceptance_hash_ok, sample["acceptance"])
        if not acceptance_hash_ok:
            continue
        acceptance = load(acceptance_path)
        expected = sample["expected"]
        status_ok = (
            acceptance.get("spec_status") == "passed"
            and acceptance.get("acceptance_status") == expected["acceptance_status"]
            and acceptance.get("human_accepted") is expected["human_accepted"]
        )
        check(f"{sample_id}:acceptance_boundary", status_ok, {key: acceptance.get(key) for key in ("spec_status", "acceptance_status", "human_accepted")})
        if expected["human_accepted"]:
            check(f"{sample_id}:user_record", isinstance(acceptance.get("user_acceptance_record"), dict), acceptance.get("user_acceptance_record"))
        else:
            check(f"{sample_id}:no_fake_user_record", acceptance.get("user_acceptance_record") is None, acceptance.get("user_acceptance_record"))

        live_artifacts = {}
        for kind in ("source_pdf", "final_pdf", "final_zip"):
            artifact = sample[kind]
            path = workspace / artifact["path"]
            actual = sha256(path) if path.is_file() else None
            field = f"{kind}_sha256"
            expected_hash = artifact["sha256"]
            ok = actual == expected_hash == acceptance.get(field)
            check(f"{sample_id}:{kind}", ok, {"path": artifact["path"], "expected": expected_hash, "actual": actual, "acceptance": acceptance.get(field)})
            live_artifacts[kind] = actual

        refs_ok = True
        ref_details = []
        for key in ("decision_index_D", "final_verified_ledger_L", "render_manifest"):
            item = acceptance.get(key)
            if not isinstance(item, dict):
                refs_ok = False
                ref_details.append({"key": key, "error": "missing"})
                continue
            path = (acceptance_path.parent / item["path"]).resolve()
            actual = sha256(path) if path.is_file() else None
            ok = actual == item.get("sha256")
            refs_ok = refs_ok and ok
            ref_details.append({"key": key, "path": str(path), "expected": item.get("sha256"), "actual": actual})
        check(f"{sample_id}:D_L_render_refs", refs_ok, ref_details)

        lineage = sample.get("active_promotion")
        if lineage:
            active = registry.get("active_promotions", {}).get(lineage["lineage_key"])
            promotion_ok = isinstance(active, dict) and all(active.get(key) == lineage[key] for key in ("promotion_id", "manifest_sha256", "promotion_class"))
            check(f"{sample_id}:active_promotion", promotion_ok, {"expected": lineage, "active": active})
        sample_summaries.append({"sample_id": sample_id, "pipeline_class": sample["pipeline_class"], "acceptance_status": acceptance.get("acceptance_status"), "artifacts": live_artifacts})

    families = {(item["language"], item["family"], item["pipeline_class"]) for item in matrix.get("samples", [])}
    required = {
        ("zh", "textbook_or_teaching_aid", "migration_compatibility"),
        ("en", "textbook_or_teaching_aid", "formal_native"),
        ("en", "assessment_or_exam", "formal_native"),
        ("zh", "workbook_or_exercise_book", "formal_native"),
    }
    check("v1_sample_coverage", required <= families, sorted(families))

    failed = [item["name"] for item in checks if item["status"] == "failed"]
    report = {
        "schema_version": "release-regression-validation/1.0",
        "status": "passed" if not failed else "failed",
        "matrix_sha256": sha256(args.matrix),
        "checks": checks,
        "samples": sample_summaries,
        "summary": {"passed": len(checks) - len(failed), "failed": len(failed), "failed_checks": failed},
        "claim_boundary": "This proves live hash-bound regression of accepted/qualified artifacts; it does not retroactively rebuild or re-accept historical products.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
