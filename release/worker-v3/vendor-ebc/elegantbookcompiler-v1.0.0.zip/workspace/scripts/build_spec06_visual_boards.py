#!/usr/bin/env python3
"""Build readable visual boards for a diagnostic Spec 06 review queue."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_font(size: int) -> ImageFont.ImageFont:
    candidates = [
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/System/Library/Fonts/Helvetica.ttc",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()


def make_board(items: list[tuple[str, Path]], output: Path, columns: int = 2, cell_width: int = 760, cell_height: int = 1080) -> None:
    rows = (len(items) + columns - 1) // columns
    label_height = 42
    board = Image.new("RGB", (columns * cell_width, rows * (cell_height + label_height)), "#d8d8d8")
    draw = ImageDraw.Draw(board)
    font = load_font(24)
    for index, (label, path) in enumerate(items):
        row, column = divmod(index, columns)
        x, y = column * cell_width, row * (cell_height + label_height)
        with Image.open(path) as image:
            image = image.convert("RGB")
            image.thumbnail((cell_width - 12, cell_height - 12), Image.Resampling.LANCZOS)
            px = x + (cell_width - image.width) // 2
            py = y + label_height + (cell_height - image.height) // 2
            board.paste(image, (px, py))
        draw.rectangle((x, y, x + cell_width, y + label_height), fill="white")
        draw.text((x + 10, y + 6), label, fill="black", font=font)
    output.parent.mkdir(parents=True, exist_ok=True)
    board.save(output, quality=92, subsampling=0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-dir", required=True, type=Path)
    parser.add_argument("--intake-run", required=True)
    parser.add_argument("--source-run")
    parser.add_argument("--structure-run")
    parser.add_argument("--compile-run", required=True)
    parser.add_argument("--diagnostic-run", required=True)
    parser.add_argument("--review-config", type=Path)
    parser.add_argument("--output-run", required=True)
    args = parser.parse_args()

    sample = args.sample_dir.resolve()
    intake = sample / "runs" / args.intake_run
    source = sample / "runs" / args.source_run if args.source_run else intake
    structure = sample / "runs" / args.structure_run if args.structure_run else None
    compile_run = sample / "runs" / args.compile_run
    diagnostic = sample / "runs" / args.diagnostic_run
    out = sample / "runs" / args.output_run
    if out.exists():
        raise SystemExit(f"immutable output already exists: {out}")
    (out / "all_pages").mkdir(parents=True)
    (out / "risk_pages").mkdir(parents=True)
    (out / "source_mapping").mkdir(parents=True)

    page_review = read(diagnostic / "reports/page_review.json")
    source_coverage = read(diagnostic / "reports/source_page_coverage.json")
    corrections: dict[int, dict[str, Any]] = {}
    review_config: dict[str, Any] = {}
    if args.review_config:
        review_config = read(args.review_config.resolve())
        corrections = {
            int(item["source_pdf_page"]): item
            for item in review_config.get("source_page_mapping_corrections", [])
        }
    source_by_page = {item["source_pdf_page"]: item for item in source_coverage["pages"]}
    final_by_page = {item["physical_page"]: item for item in page_review["pages"]}
    risk_pages = page_review["risk_pages"]
    created: list[Path] = []

    all_final_pages = sorted(final_by_page)
    for offset in range(0, len(all_final_pages), 4):
        pages = all_final_pages[offset:offset + 4]
        items = [
            (
                f"Final {page} label {final_by_page[page]['page_label']} | source {','.join(map(str, final_by_page[page]['mapped_source_pages'])) or 'framework'}",
                (diagnostic / final_by_page[page]["raster_ref"]).resolve(),
            )
            for page in pages
        ]
        target = out / "all_pages" / f"pages-{pages[0]:03d}-{pages[-1]:03d}.jpg"
        make_board(items, target)
        created.append(target)

    for offset in range(0, len(risk_pages), 4):
        pages = risk_pages[offset:offset + 4]
        items = [
            (
                f"Final {page} label {final_by_page[page]['page_label']} | source {','.join(map(str, final_by_page[page]['mapped_source_pages']))}",
                (diagnostic / final_by_page[page]["raster_ref"]).resolve(),
            )
            for page in pages
        ]
        target = out / "risk_pages" / f"risk-{offset // 4 + 1:02d}-p{pages[0]:03d}-p{pages[-1]:03d}.jpg"
        make_board(items, target)
        created.append(target)

    for source_page in page_review["source_pages_without_exact_anchor"]:
        source_item = dict(source_by_page[source_page])
        correction = corrections.get(source_page)
        if correction:
            source_item["final_pdf_pages"] = correction["final_pdf_pages"]
        items = [(f"Source PDF page {source_page}", (diagnostic / source_item["source_raster_ref"]).resolve())]
        for final_page in source_item["final_pdf_pages"]:
            items.append((f"Final PDF page {final_page} label {final_by_page[final_page]['page_label']}", (diagnostic / final_by_page[final_page]["raster_ref"]).resolve()))
        target = out / "source_mapping" / f"source-{source_page:03d}-final-mapping.jpg"
        make_board(items, target)
        created.append(target)

    confirmed_visual_defects = [
        item
        for item in review_config.get("confirmed_defects", [])
        if item.get("type") in {
            "source_visual_region_missing",
            "media_crop_contamination",
            "composite_media_reading_order_violation",
        }
    ]
    for defect in confirmed_visual_defects:
        items: list[tuple[str, Path]] = []
        for source_page in defect["source_pdf_pages"]:
            source_item = source_by_page[source_page]
            items.append(
                (
                    f"Source PDF page {source_page} | {defect['defect_id']}",
                    (diagnostic / source_item["source_raster_ref"]).resolve(),
                )
            )
        for final_page in defect["final_pdf_pages"]:
            items.append(
                (
                    f"Final PDF page {final_page} label {final_by_page[final_page]['page_label']}",
                    (diagnostic / final_by_page[final_page]["raster_ref"]).resolve(),
                )
            )
        target = out / "source_mapping" / f"defect-{defect['defect_id'].lower()}.jpg"
        make_board(items, target)
        created.append(target)

    outline_evidence: list[dict[str, Any]] = []
    if structure:
        outline_ledger_path = structure / "structure/source_outline_ledger.json"
        if not outline_ledger_path.is_file():
            raise SystemExit(f"missing Spec 04-A source outline ledger: {outline_ledger_path}")
        outline_ledger = read(outline_ledger_path)
        outline_evidence = outline_ledger.get("source_outline_evidence", [])
        if not outline_evidence:
            raise SystemExit(f"Spec 04-A source outline ledger has no source_outline_evidence: {outline_ledger_path}")

        toc_items: list[tuple[str, Path]] = []
        for item in outline_evidence:
            evidence_path = Path(item["path"]).resolve()
            if not evidence_path.is_file():
                raise SystemExit(f"missing source outline evidence: {evidence_path}")
            expected_sha = item.get("sha256")
            if expected_sha and sha(evidence_path) != expected_sha:
                raise SystemExit(f"source outline evidence hash mismatch: {evidence_path}")
            toc_items.append(
                (
                    f"Source structure evidence page {item['pdf_physical_page']} ({item['evidence_id']})",
                    evidence_path,
                )
            )
        toc_items.extend(
            [
                ("Final TOC page 2", compile_run / "final_render_pack/pages/page-002.png"),
                ("Final TOC page 3", compile_run / "final_render_pack/pages/page-003.png"),
            ]
        )
        toc_target = out / "source_mapping/toc-source-vs-final.jpg"
        make_board(toc_items, toc_target)
        created.append(toc_target)

    manifest = {
        "schema_version": "spec06-visual-boards/1.1",
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "diagnostic_run": args.diagnostic_run,
        "diagnostic_manifest_sha256": sha(diagnostic / "manifests/review_pack_manifest.json"),
        "risk_page_count": len(risk_pages),
        "all_page_board_count": len(list((out / "all_pages").glob("*.jpg"))),
        "risk_board_count": len(list((out / "risk_pages").glob("*.jpg"))),
        "source_mapping_pages": page_review["source_pages_without_exact_anchor"],
        "structure_run": args.structure_run,
        "source_outline_evidence": [
            {
                "evidence_id": item["evidence_id"],
                "pdf_physical_page": item["pdf_physical_page"],
                "path": item["path"],
                "sha256": item["sha256"],
            }
            for item in outline_evidence
        ],
        "review_config": ({"path": str(args.review_config.resolve()), "sha256": sha(args.review_config.resolve())} if args.review_config else None),
        "source_page_mapping_corrections": sorted(corrections),
        "confirmed_visual_defect_ids": [item["defect_id"] for item in confirmed_visual_defects],
        "files": [{"path": path.relative_to(out).as_posix(), "sha256": sha(path), "size": path.stat().st_size} for path in created],
    }
    manifest_path = out / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run": str(out), "all_page_boards": manifest["all_page_board_count"], "risk_pages": len(risk_pages), "risk_boards": manifest["risk_board_count"], "mapping_boards": len(list((out / "source_mapping").glob("*.jpg")))}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
