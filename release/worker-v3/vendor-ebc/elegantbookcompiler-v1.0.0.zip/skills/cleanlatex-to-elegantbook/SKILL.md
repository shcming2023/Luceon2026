---
name: cleanlatex-to-elegantbook
description: Mechanically render a closed canonical ledger and frozen render_plan into a user-supplied frozen ElegantBook template. Use for Spec 05 generation when semantic roles, target constructs, parameters, source assets, decision index, capability manifest, and template_contract are already fixed and must not be re-decided during LaTeX generation.
---

# CleanLaTeX to ElegantBook

## Formal Role

Despite its historical name, the approved production path is now a deterministic Spec 05 renderer. It consumes decisions made upstream and is forbidden from choosing headings, boxes, image representations, answer visibility, wording, or layout parameters.

Required immutable inputs:

- `canonical_block_ledger.jsonl` at a closed semantic checkpoint;
- closed `canonical_decision_index.json`;
- frozen `render_plan.json`;
- byte-bound `template_capability_manifest.json`;
- authoritative frozen `template_contract.json`;
- the exact user-supplied template directory;
- referenced assets and, when planned crops exist, the source PDF and bound page rasters.

For render plans using the media-source-representation v1 boundary, first run
the orchestrator's `validate-render-binding` check. The render node's
`media_binding` is execution evidence: this renderer verifies live source asset
bytes and regenerated crop bytes against it and never substitutes another
candidate.

Older accepted plans that predate `media_binding` remain reproducible and are
reported as `legacy_unbound`; this compatibility path must not be used for a new
formal plan. Do not retrofit or mutate an already accepted immutable plan merely
to make it look like it used the new contract.

The shared contract validator is owned by `luceon-popo-to-refined-elegantbook`. Read that skill before a formal run.

## Freeze the Template Contract

Spec 05 must first create the authoritative contract from the exact read-only template, its source ZIP, the Spec 04 capability manifest, source-grounded metadata, and an explicit body boundary:

```bash
python3 /Users/concm/.codex/skills/cleanlatex-to-elegantbook/scripts/freeze_template_contract.py \
  --template-dir /path/to/template/unpacked \
  --template-zip /path/to/template.zip \
  --capability-manifest /path/to/template_capability_manifest.json \
  --metadata-config /path/to/spec05_metadata.json \
  --presentation-config /path/to/spec05_presentation_config.json \
  --body-marker 'exact marker copied from the template' \
  --output /new/run/contracts/template_contract.json \
  --validation-report /new/run/reports/template_capability_validation_report.json
```

The freezer is read-only over the template. It inventories every non-entry template file as immutable, binds the class, packages, custom API, metadata surface, body boundary, compile policy, source ZIP, and capability manifest, and refuses metadata without source-hash evidence. New formal-native runs must also supply an approved `spec05-presentation-config/1.0`; this creates `template-contract/2.0`. Historical calls without that input remain `template-contract/1.0` compatibility only.

The presentation config declares exactly `cover` and `logo`. Each uses one explicit mode: `template_default`, `source_region_asset`, or `approved_static_asset`. Every choice needs a unique closed decision and approved compatibility assertion. Source-region assets bind the source PDF, page raster, pixel bbox, exact crop bytes, fit policy, and—when applicable—the source-scope ledger. Source cover/title pages may support output presentation while remaining excluded from body coverage. Configured assets are added under distinct project paths; the original template cover/logo bytes remain frozen and only the existing `\cover{}` and `\logo{}` values may change. The renderer never infers a choice from language, filename, subject words, sample ids, pages, or known hashes.

The marker is explicit input because a universal marker string would be template-specific hardcoding.

## Mechanical Render

```bash
python3 /Users/concm/.codex/skills/cleanlatex-to-elegantbook/scripts/render_frozen_plan.py \
  --template-dir /path/to/template/unpacked \
  --template-contract /path/to/template_contract.json \
  --ledger /path/to/canonical_block_ledger.jsonl \
  --decision-index /path/to/canonical_decision_index.json \
  --render-plan /path/to/render_plan.json \
  --capability-manifest /path/to/template_capability_manifest.json \
  --asset-root /path/to/mineru \
  --asset-root /path/to/minerupopo \
  --source-pdf /path/to/source.pdf \
  --source-page-dir /path/to/source-page-rasters \
  --media-evidence-ledger /path/to/media_evidence_ledger.json \
  --media-representation-plan /path/to/media_representation_plan.json \
  --out-dir /new/isolated/render-run
```

The renderer refuses to overwrite an output directory. A plan containing any
`media_binding` requires both media contract files. Before writing, the renderer
validates the canonical ledger, decision index, render plan, template contract,
capability manifest, media representation closure, and exact render binding.
It then copies the full template, changes only allowlisted metadata values and
the exact body insertion region, materializes only planned assets/crops, emits
a deterministic body and ZIP, and writes integrity/coverage reports.

## Formal-native Spec 05 Execution

For a new formal run, prefer `produce_native_spec05.py` over manually stitching
the freezer, renderer, Docker compile, warning review, and raster steps. The
producer accepts only the registry-selected `formal_native` Spec 04-D
promotion whose `full_spec04_status=passed`. A Spec 03-only or bounded media
fixture is not an eligible parent.

The producer captures its executable capability before build decisions,
freezes the template contract, invokes the renderer above, packages the final
ZIP before compilation, compiles a fresh extraction of those exact bytes,
and creates a hash-bound page raster for every PDF page with the renderer named
by the approved build policy. `pdftoppm` and `pdftocairo` are supported; select
`pdftocairo` when renderer parity evidence shows that `pdftoppm` drops embedded
CJK glyphs. Its commit
order is `E -> build evidence B -> decision index D -> stage/build commit M`:
compile-warning decisions may cite only already-existing log, PDF, ZIP, and
render-pack evidence, avoiding a D/M hash cycle.

Before compilation, the producer must execute `TP-H14` against the exact
generated `rendered_body.tex`. The bound `template_capability_manifest.json`
is the sole inventory of template-local custom commands and environments; any
definition or call blocks the build. Standard LaTeX constructs and declared
`tcolorbox` styles remain legal. The producer writes
`reports/template_local_api_usage_report.json`, and formal promotion must
independently rescan the same bound bytes rather than trust this self-report.

Formal-native promotion requires `template-contract/2.0`, exact cover/logo bytes in the delivery ZIP, four presentation hard gates, and one closed `CP-R04` decision. A missing, open, hash-drifted, body-scope-conflicting, or silently inferred presentation choice blocks promotion.

All environment choices belong in an approved
`spec05-build-policy/1.0` document. Source-supported cover values belong in an
approved `spec05-metadata/1.0` document. C2 warning closures, when required,
belong in an exact-fingerprint `spec05-warning-review/1.0` document and must
cite rendered page numbers. The core contains no book names, sample ids,
fixed pages, or warning-message exemptions.

```bash
python3 scripts/produce_native_spec05.py \
  --run-dir /new/immutable/spec05-run \
  --run-id material-spec05-v1 \
  --promotion-registry /promotions/registry.json \
  --parent-promotion /promotions/spec04d.promotion.json \
  --parent-lineage-key material/spec04d-render-plan \
  --template-zip /inputs/template.zip \
  --template-intake /contracts/template_intake.json \
  --capability-manifest /spec04c/template_capability_manifest.json \
  --metadata-config /configs/spec05_metadata.json \
  --presentation-config /configs/spec05_presentation_config.json \
  --body-marker 'exact marker copied from the template' \
  --media-evidence-ledger /spec03/media_evidence_ledger.json \
  --media-representation-plan /spec03/media_representation_plan.json \
  --asset-root /inputs/mineru/images \
  --source-pdf /inputs/source.pdf \
  --source-page-dir /evidence/source_pages \
  --build-policy /configs/spec05_build_policy.json
```

The resulting `passed` status proves only `compile_pass` and a complete
`final_render_pack`. Run Spec 03 render coverage and Spec 06 separately; this
producer must not claim or perform them.

## Hard Failures

Fail and return to the owning stage when any of these occurs:

- open or invalidated decisions, open ledger reviews, or non-passed contract status;
- ledger/payload/hash mismatch, missing/duplicate logical coverage, or non-deterministic plan hash;
- a construct/style absent from the bound capability manifest;
- an unsupported target construct or parameter shape;
- missing assets, different-byte basename collisions, unknown crop coordinates, or source PDF hash mismatch;
- a source asset whose live bytes differ from the frozen payload/media
  representation hash, or a regenerated crop whose bytes differ from the
  hash-bound reviewed crop;
- template/class/package/API/masked-scaffold drift;
- any definition or call of a template-local custom command or environment in
  the generated body (`TP-H14`);
- any body-side macro definition, package/input injection, placeholder, fallback, or semantic choice.

Do not delete content, switch boxes, resize by heuristics, add packages/macros, or generate a fallback document to obtain a pass.

## Outputs and Scope

The renderer creates:

- `project/` and deterministic `delivery/elegantbook-project.zip`;
- `render/rendered_body.tex`;
- `reports/intermediate_contract_validation.json`;
- `reports/media_contract_validation.json` and
  `reports/media_render_binding_validation.json` for a media-bound plan;
- `reports/render_execution_report.json`;
- `reports/asset_materialization_report.json`;
- `reports/template_integrity_report.{json,md}`;
- `reports/template_local_api_usage_report.json`;
- `manifests/mechanical_render_manifest.json`.

`ready_to_compile` proves only deterministic generation and template integrity. Compilation, full-page review, source fidelity, and user acceptance remain separate gates.

## Legacy Compatibility

`clean_to_elegantbook.py` and `semantic_markdown_to_cleanlatex.py` remain available only for historical or diagnostic workflows. They generate their own template/preamble and may infer mappings, so they are `diagnostic_only` and must not be used for an approved frozen-template product run. Do not extend their heuristic rules in this refactor round; upstream cleaning is explicitly outside scope.
