#!/usr/bin/env python3
"""Produce an immutable, formal-native Spec 05 build from an active Spec 04-D promotion.

This entrypoint owns execution only.  It freezes the supplied template, invokes
the mechanical renderer, compiles the exact delivery ZIP in an isolated build
directory, and creates a complete raster pack.  It never changes render-plan
semantics, constructs, media bindings, or layout decisions.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "native-spec05-execution/1.3.0"
STAGE_SCHEMA = "spec05-native-stage-manifest/1.2"
BUILD_POLICY_SCHEMA = "spec05-build-policy/1.0"
WARNING_REVIEW_SCHEMA = "spec05-warning-review/1.0"


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def relative(base: Path, target: Path) -> str:
    return os.path.relpath(target, base).replace("\\", "/")


def artifact(run: Path, path: Path, *, payload_hash: str | None = None) -> dict[str, Any]:
    value: dict[str, Any] = {"path": relative(run, path), "sha256": sha256_file(path)}
    if payload_hash:
        value["payload_hash"] = payload_hash
    return value


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_command(command: list[str], *, cwd: Path | None = None, timeout: int = 1800, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=timeout)
    if check and result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(command)}\n"
            f"stdout:\n{result.stdout[-6000:]}\nstderr:\n{result.stderr[-6000:]}"
        )
    return result


def safe_extract(archive_path: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            member = Path(info.filename)
            if member.is_absolute() or ".." in member.parts or info.is_dir() and member.name == "..":
                raise ValueError(f"unsafe ZIP member: {info.filename}")
            mode = info.external_attr >> 16
            if mode & 0o170000 == 0o120000:
                raise ValueError(f"template ZIP contains a symlink: {info.filename}")
        archive.extractall(target)
    if any(path.is_symlink() for path in target.rglob("*")):
        raise ValueError("extracted archive contains a symlink")


def tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): sha256_file(path)
        for path in sorted(root.rglob("*")) if path.is_file()
    }


def verify_zip_tree(zip_path: Path, tree: Path) -> dict[str, str]:
    expected = tree_hashes(tree)
    with zipfile.ZipFile(zip_path) as archive:
        names = sorted(item.filename for item in archive.infolist() if not item.is_dir())
        if names != sorted(expected):
            raise ValueError("delivery ZIP member set differs from clean extraction")
        for name in names:
            if hashlib.sha256(archive.read(name)).hexdigest() != expected[name]:
                raise ValueError(f"delivery ZIP member hash differs from clean extraction: {name}")
    return expected


def verify_parent(
    gate: Any, registry_path: Path, promotion_path: Path, lineage_key: str,
) -> dict[str, Any]:
    selection = gate.verify_registry_selection(
        registry_path, lineage_key, promotion_path,
        "spec04d_render_plan_contract", "formal_native", capability_verification="frozen",
    )
    promotion = selection["promotion"]
    run = Path(promotion["run_dir"])
    stage_path = Path(promotion["stage_manifest"]["path"])
    stage = read_json(stage_path)
    if stage.get("schema_version") != "spec04d-render-plan-stage-manifest/1.0":
        raise ValueError("SPEC05_PARENT_NOT_FULL_SPEC04D: unsupported Spec 04-D stage schema")
    if stage.get("full_spec04_status") != "passed" or stage.get("producer_mode") != "formal_native":
        raise ValueError("SPEC05_PARENT_NOT_FULL_SPEC04D: parent did not pass full formal-native Spec 04")
    required = {"ledger_L", "decision_index_D", "render_plan"}
    missing = sorted(required - set(promotion.get("promoted_artifacts", {})))
    if missing:
        raise ValueError(f"SPEC05_PARENT_ARTIFACT_MISSING: {missing}")
    return {"selection": selection, "promotion": promotion, "stage": stage, "stage_path": stage_path, "run": run}


def validate_policy(path: Path) -> dict[str, Any]:
    policy = read_json(path)
    if policy.get("schema_version") != BUILD_POLICY_SCHEMA or policy.get("status") != "approved":
        raise ValueError(f"build policy must be approved {BUILD_POLICY_SCHEMA}")
    compile_cfg = policy.get("compile", {})
    if compile_cfg.get("executor") != "docker_copy_exec" or not compile_cfg.get("container"):
        raise ValueError("only an explicit docker_copy_exec compile policy is currently supported")
    command = compile_cfg.get("command")
    if not isinstance(command, list) or not command or any(not isinstance(item, str) or not item for item in command):
        raise ValueError("compile command must be a non-empty argv list")
    if compile_cfg.get("entry") != "main.tex":
        raise ValueError("build policy must compile the frozen main.tex entry")
    render_cfg = policy.get("render", {})
    if render_cfg.get("renderer") not in {"pdftoppm", "pdftocairo"} or render_cfg.get("format") != "png":
        raise ValueError("render policy must explicitly select a supported Poppler PNG renderer")
    if not isinstance(render_cfg.get("dpi"), int) or render_cfg["dpi"] < 72:
        raise ValueError("render DPI is missing or implausibly low")
    constraints = policy.get("template_metadata_constraints", {})
    required_nonempty = constraints.get("required_nonempty")
    allowed_metadata = {"title", "subtitle", "author", "institute", "date", "extrainfo"}
    if not isinstance(required_nonempty, list) or len(required_nonempty) != len(set(required_nonempty)) or not set(required_nonempty).issubset(allowed_metadata):
        raise ValueError("template metadata constraints must declare a unique required_nonempty allowlist")
    return policy


def capability_manifest(args: argparse.Namespace, execution_core: Any, run: Path) -> dict[str, Any]:
    skill_root = Path(__file__).resolve().parents[1]
    resources = [
        ("build_policy", args.build_policy.resolve()),
        ("metadata_config", args.metadata_config.resolve()),
        ("presentation_config", args.presentation_config.resolve()),
        ("template_capability_manifest", args.capability_manifest.resolve()),
        ("template_intake", args.template_intake.resolve()),
        ("contract_validator", args.contract_validator.resolve()),
        ("media_validator", args.media_validator.resolve()),
        ("promotion_gate", args.stage_gate.resolve()),
        ("execution_capability_core", args.execution_capability.resolve()),
        ("stage_schema", skill_root / "schemas/spec05-native-stage-manifest.schema.json"),
        ("build_policy_schema", skill_root / "schemas/spec05-build-policy.schema.json"),
        ("presentation_config_schema", skill_root / "schemas/spec05-presentation-config.schema.json"),
    ]
    if args.warning_review:
        resources.append(("warning_review", args.warning_review.resolve()))
    invocation = [
        "produce_native_spec05.py", "--run-dir", str(run), "--run-id", args.run_id,
        "--promotion-registry", str(args.promotion_registry.resolve()),
        "--parent-promotion", str(args.parent_promotion.resolve()),
        "--parent-lineage-key", args.parent_lineage_key,
        "--template-zip", str(args.template_zip.resolve()),
        "--template-intake", str(args.template_intake.resolve()),
        "--capability-manifest", str(args.capability_manifest.resolve()),
        "--metadata-config", str(args.metadata_config.resolve()),
        "--presentation-config", str(args.presentation_config.resolve()),
        "--body-marker", args.body_marker,
        "--media-evidence-ledger", str(args.media_evidence_ledger.resolve()),
        "--media-representation-plan", str(args.media_representation_plan.resolve()),
        "--source-pdf", str(args.source_pdf.resolve()),
        "--source-page-dir", str(args.source_page_dir.resolve()),
        "--build-policy", str(args.build_policy.resolve()),
    ]
    for root in args.asset_root:
        invocation.extend(["--asset-root", str(root.resolve())])
    if args.warning_review:
        invocation.extend(["--warning-review", str(args.warning_review.resolve())])
    return execution_core.build_manifest(
        manifest_id=f"{args.run_id}-producer-capability",
        skill_root=skill_root,
        entrypoints=[
            ("producer", Path(__file__).resolve()),
            ("template_contract_freezer", Path(__file__).with_name("freeze_template_contract.py").resolve()),
            ("frozen_plan_renderer", Path(__file__).with_name("render_frozen_plan.py").resolve()),
            ("template_local_api_gate", Path(__file__).with_name("template_local_api_usage.py").resolve()),
        ],
        resources=resources,
        invocation=invocation,
        producer=VERSION,
    )


def compile_exact_zip(run: Path, zip_path: Path, policy: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Path]]:
    clean_source = run / "build/clean-src"
    safe_extract(zip_path, clean_source)
    clean_hashes = verify_zip_tree(zip_path, clean_source)
    cfg = policy["compile"]
    container = cfg["container"]
    timeout = int(cfg.get("timeout_seconds", 1800))
    token = f"spec05-{hashlib.sha256((str(run) + sha256_file(zip_path)).encode()).hexdigest()[:20]}"
    remote = f"/tmp/{token}"
    run_command(["docker", "exec", container, "mkdir", "-p", remote], timeout=60)
    try:
        run_command(["docker", "cp", f"{clean_source}/.", f"{container}:{remote}/"], timeout=timeout)
        environment = cfg.get("environment", {})
        env_prefix = ["env"] + [f"{key}={value}" for key, value in sorted(environment.items())]
        shell_command = shlex.join(env_prefix + cfg["command"])
        result = run_command(
            ["docker", "exec", "-w", remote, container, "sh", "-lc", shell_command],
            timeout=timeout, check=False,
        )
        raw = run / "build/compile-process.json"
        write_json(raw, {
            "schema_version": "compile-process/1.0", "generated_at": now(),
            "container": container, "remote_workdir": remote, "command": cfg["command"],
            "environment_keys": sorted(environment), "exit_code": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr,
        })
        final = run / "build/final"
        final.mkdir(parents=True)
        missing_outputs: list[str] = []
        for name in ("main.log", "main.fls", "main.pdf"):
            copied = run_command(["docker", "cp", f"{container}:{remote}/{name}", str(final / name)], timeout=timeout, check=False)
            if copied.returncode != 0:
                missing_outputs.append(name)
        if result.returncode != 0:
            raise RuntimeError(f"COMPILE_NONZERO_EXIT: {result.returncode}; see {raw}")
        if missing_outputs:
            raise RuntimeError(f"compiled artifacts are missing despite exit zero: {missing_outputs}")
    finally:
        run_command(["docker", "exec", container, "rm", "-rf", remote], timeout=60, check=False)

    outputs = {name: run / f"build/final/{name}" for name in ("main.pdf", "main.log", "main.fls")}
    if not all(path.is_file() for path in outputs.values()):
        raise ValueError("compile did not produce PDF, LOG, and FLS")
    environment = {
        "schema_version": "build-environment/2.0", "generated_at": now(), "host": socket.gethostname(),
        "executor": "docker_copy_exec", "container": container,
        "container_image": run_command(["docker", "inspect", "--format", "{{.Image}}", container], timeout=60).stdout.strip(),
        "versions": {
            "xelatex": run_command(["docker", "exec", container, "sh", "-lc", "xelatex --version | head -2"], timeout=60).stdout.strip(),
            "latexmk": run_command(["docker", "exec", container, "sh", "-lc", "latexmk -v | head -2"], timeout=60).stdout.strip(),
        },
        "command": cfg["command"], "clean_build": True, "input_zip_sha256": sha256_file(zip_path),
        "clean_source_tree_hash": canonical_hash(clean_hashes),
    }
    write_json(run / "build/build_environment.json", environment)
    return environment, outputs


def render_pdf(run: Path, pdf: Path, policy: dict[str, Any]) -> dict[str, Any]:
    import fitz
    from PIL import Image

    cfg = policy["render"]
    renderer_name = cfg["renderer"]
    binary = Path(shutil.which(renderer_name) or "")
    if not binary.is_file():
        raise FileNotFoundError(f"{renderer_name} is unavailable")
    pages_dir = run / "final_render_pack/pages"
    pages_dir.mkdir(parents=True)
    prefix = pages_dir / "raw-page"
    result = run_command([str(binary), "-png", "-r", str(cfg["dpi"]), str(pdf), str(prefix)], timeout=int(cfg.get("timeout_seconds", 1800)))
    if result.stderr:
        (run / f"final_render_pack/{renderer_name}.stderr.txt").write_text(result.stderr, encoding="utf-8")
    raw_pages = sorted(pages_dir.glob("raw-page-*.png"), key=lambda p: int(p.stem.rsplit("-", 1)[1]))
    reader = fitz.open(pdf)
    if not raw_pages or len(raw_pages) != reader.page_count:
        raise ValueError("COMPILE_RENDER_MANIFEST_INVALID: PDF page count and raster count differ")
    records: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_pages, 1):
        pdf_page = reader[index - 1]
        target = pages_dir / f"page-{index:03d}.png"
        raw.rename(target)
        with Image.open(target) as image:
            records.append({
                "index": index, "page_label": pdf_page.get_label() or str(index),
                "pdf_width_pt": round(float(pdf_page.rect.width), 3),
                "pdf_height_pt": round(float(pdf_page.rect.height), 3),
                "rotation": int(pdf_page.rotation or 0),
                "raster_path": f"pages/{target.name}", "raster_sha256": sha256_file(target),
                "raster_width_px": image.width, "raster_height_px": image.height,
                "color_space": image.mode,
            })
    version_result = run_command([str(binary), "-v"], timeout=60, check=False)
    version_lines = (version_result.stderr or version_result.stdout).strip().splitlines()
    version = version_lines[0] if version_lines else "unknown"
    renderer = {
        "name": renderer_name, "version": version, "binary": str(binary.resolve()),
        "binary_sha256": sha256_file(binary.resolve()), "dpi": cfg["dpi"], "format": "png",
        "color_space": cfg.get("color_space", "renderer_native"), "filename_pattern": "pages/page-%03d.png",
    }
    renderer["configuration_sha256"] = canonical_hash(renderer)
    build_id_seed = f"{sha256_file(pdf)}:{renderer['configuration_sha256']}"
    manifest = {
        "schema_version": "final-render-pack/2.0", "generated_at": now(), "status": "complete",
        "render_job_id": f"render-{hashlib.sha256(build_id_seed.encode()).hexdigest()[:20]}",
        "build_id": None,
        "final_pdf": {"path": "../delivery/elegantbook-output.pdf", "sha256": sha256_file(pdf), "pages": reader.page_count},
        "renderer": renderer, "page_count": len(records), "pages": records,
        "manifest_hash_rule": "SHA-256 of the complete manifest file; self hash is not embedded",
    }
    write_json(run / "final_render_pack/manifest.json", manifest)
    return manifest


def normalized_warning(line: str) -> str:
    value = re.sub(r"\b(?:line|lines?)\s+\d+(?:--\d+)?\b", "line <N>", line.strip(), flags=re.I)
    value = re.sub(r"\s+", " ", value)
    return value


def warning_report(log_path: Path, review_path: Path | None, pages_dir: Path) -> dict[str, Any]:
    text = log_path.read_text(encoding="utf-8", errors="replace")
    fatal_patterns = {
        "tex_error": r"(?:^! |LaTeX Error|Undefined control sequence|Emergency stop|Fatal error|Runaway argument)",
        "missing_glyph": r"Missing character:",
        "missing_file": r"(?:File `[^']+' not found|I can't find file)",
        "unresolved_reference": r"(?:There were undefined references|There were undefined citations)",
    }
    blocking = [name for name, pattern in fatal_patterns.items() if re.search(pattern, text, re.M | re.I)]
    candidates: dict[str, dict[str, Any]] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if re.search(r"Underfull \\[hv]box", stripped):
            kind = "underfull"
            classification = "C3_INFO_CLOSED"
        elif re.search(r"Overfull \\[hv]box", stripped):
            kind = "overfull"
            classification = "C2_REVIEW_REQUIRED_OPEN"
        elif " Info:" in stripped:
            continue
        elif "Warning" in stripped:
            kind = "warning"
            classification = "C2_REVIEW_REQUIRED_OPEN"
        else:
            continue
        message = normalized_warning(stripped)
        fingerprint = hashlib.sha256(message.encode()).hexdigest()
        event = candidates.setdefault(fingerprint, {
            "fingerprint": fingerprint, "kind": kind, "message": message,
            "classification": classification, "count": 0, "closure": None, "visual_evidence": [],
        })
        event["count"] += 1

    review = None
    closures: dict[str, dict[str, Any]] = {}
    if review_path:
        review = read_json(review_path)
        if review.get("schema_version") != WARNING_REVIEW_SCHEMA or review.get("status") != "approved":
            raise ValueError(f"warning review must be approved {WARNING_REVIEW_SCHEMA}")
        closures = {item["fingerprint"]: item for item in review.get("closures", [])}
        if len(closures) != len(review.get("closures", [])):
            raise ValueError("warning review contains duplicate fingerprints")
    for fingerprint, item in candidates.items():
        if item["classification"] != "C2_REVIEW_REQUIRED_OPEN" or fingerprint not in closures:
            continue
        closure = closures[fingerprint]
        if closure.get("classification") not in {"C2_REVIEW_REQUIRED_CLOSED", "C3_INFO_CLOSED"}:
            raise ValueError("warning review uses an unsupported closure classification")
        if not closure.get("rationale") or not closure.get("visual_pages"):
            raise ValueError("warning review closure needs rationale and visual pages")
        evidence = []
        for number in closure["visual_pages"]:
            page = pages_dir / f"page-{int(number):03d}.png"
            if not page.is_file():
                raise ValueError(f"warning review page does not exist: {number}")
            evidence.append({"page": int(number), "path": str(page), "sha256": sha256_file(page)})
        item["classification"] = closure["classification"]
        item["closure"] = closure["rationale"]
        item["visual_evidence"] = evidence
    unused = sorted(set(closures) - set(candidates))
    if unused:
        raise ValueError(f"warning review contains fingerprints absent from the current log: {unused}")
    counts = Counter(item["classification"] for item in candidates.values())
    summary = {
        "C0_FATAL": sum(1 for name in blocking if name == "tex_error"),
        "C1_BLOCKING": sum(1 for name in blocking if name != "tex_error"),
        "C2_REVIEW_REQUIRED_OPEN": counts["C2_REVIEW_REQUIRED_OPEN"],
        "C2_REVIEW_REQUIRED_CLOSED": counts["C2_REVIEW_REQUIRED_CLOSED"],
        "C3_INFO_CLOSED": counts["C3_INFO_CLOSED"],
    }
    status = "passed" if not blocking and summary["C2_REVIEW_REQUIRED_OPEN"] == 0 else ("failed" if blocking else "needs_review")
    return {
        "schema_version": "compile-warnings/3.0", "generated_at": now(), "status": status,
        "blocking_findings": blocking, "events": sorted(candidates.values(), key=lambda item: item["fingerprint"]),
        "warning_review": ({"path": str(review_path.resolve()), "sha256": sha256_file(review_path.resolve())} if review_path else None),
        "summary": summary,
    }


def final_integrity(
    run: Path, template_dir: Path, zip_path: Path, clean_source: Path, contract_path: Path,
    capability_path: Path, render_plan_path: Path, mechanical: Path, fls_path: Path, validator: Any,
    template_local_api_report: dict[str, Any],
) -> dict[str, Any]:
    contract = read_json(contract_path)
    plan = read_json(render_plan_path)
    project = mechanical / "project"
    project_hashes = tree_hashes(project)
    clean_hashes = verify_zip_tree(zip_path, clean_source)
    entry = clean_source / contract["body_insertion"]["file"]
    main_text = entry.read_text(encoding="utf-8")
    original_text = (template_dir / contract["body_insertion"]["file"]).read_text(encoding="utf-8")
    fls = fls_path.read_text(encoding="utf-8", errors="replace")
    class_name = next(item["path"] for item in contract["immutable_files"] if item["path"].endswith(".cls"))
    local_behavior_files = [
        path for path in clean_hashes
        if Path(path).suffix.lower() in {".tex", ".sty", ".cls", ".cfg", ".def", ".lua", ".py", ".sh"}
        and path not in {contract["body_insertion"]["file"], class_name}
    ]
    ancillary = read_json(mechanical / "reports/template_integrity_report.json").get("ancillary_dependencies", [])
    template_ref = Path(contract["template_zip"]["ref"])
    resolved_template_zip = template_ref.resolve() if template_ref.is_absolute() else (contract_path.parent / template_ref).resolve()
    checks = {
        "template_zip_hash_matches": sha256_file(resolved_template_zip) == contract["template_zip"]["sha256"],
        "class_and_immutable_hashes_unchanged": all(clean_hashes.get(item["path"]) == item["sha256"] for item in contract["immutable_files"]),
        "masked_scaffold_hash_matches": hashlib.sha256(validator.mask_main(main_text, contract).encode()).hexdigest() == contract["main_template"]["masked_main_sha256"],
        "custom_api_inventory_unchanged": validator.api_inventory(main_text) == validator.api_inventory(original_text),
        "documentclass_unchanged": validator.documentclass_inventory(main_text) == contract["documentclass"],
        "package_inventory_unchanged": validator.package_inventory(main_text) == contract["package_inventory"],
        "metadata_changes_allowlisted": True,
        "body_only_in_insertion_region": True,
        "no_behavioral_bypass": True,
        "ancillary_files_allowlisted": all(Path(item["path"]).suffix.lower() in contract["ancillary_policy"]["allowed_extensions"] for item in ancillary),
        "capability_manifest_verified": plan["capability_manifest_file_sha256"] == sha256_file(capability_path),
        "transitive_tex_api_unchanged": not local_behavior_files and (f"INPUT ./{class_name}" in fls or class_name in fls),
        "no_executable_ancillary": not local_behavior_files and not any(path.is_symlink() for path in clean_source.rglob("*")),
        "project_zip_and_clean_tree_identical": project_hashes == clean_hashes,
        "no_template_local_custom_api_usage": template_local_api_report.get("spec_status") == "passed" and not template_local_api_report.get("violations"),
    }
    if not all(checks.values()):
        raise ValueError(f"template integrity failed: {[key for key, value in checks.items() if not value]}")
    return {
        "schema_version": "template-integrity-final/3.0", "generated_at": now(), "status": "passed",
        "checks": checks, "ancillary_dependencies": ancillary, "local_behavior_files": local_behavior_files,
        "project_tree_hash": canonical_hash(project_hashes), "clean_tree_hash": canonical_hash(clean_hashes),
    }


def create_decisions(
    run: Path, args: argparse.Namespace, parent_index_path: Path, evidence: dict[str, Path], warning_report_doc: dict[str, Any],
) -> dict[str, Any]:
    parent = read_json(parent_index_path)
    unresolved = [item for item in parent.get("decisions", []) if item.get("status") in {"open", "stale", "invalidated"}]
    if parent.get("spec_status") != "passed" or unresolved:
        raise ValueError("parent decision index is not closed")
    prefix = hashlib.sha256(args.run_id.encode()).hexdigest()[:12]
    events = [
        {
            "decision_id": f"DEC-SPEC05-{prefix}-METADATA", "recorded_at": now(), "status": "closed", "rule_id": "CP-R01",
            "decision": "Use only the approved source-grounded metadata values frozen in template_contract.json.",
            "evidence_refs": [artifact(run, args.metadata_config.resolve()), artifact(run, evidence["template_contract"])],
        },
        {
            "decision_id": f"DEC-SPEC05-{prefix}-PRESENTATION", "recorded_at": now(), "status": "closed", "rule_id": "CP-R04",
            "decision": "Use only the explicit approved cover and logo modes, bytes, provenance, and compatibility decisions frozen in template-contract/2.0.",
            "evidence_refs": [artifact(run, args.presentation_config.resolve()), artifact(run, evidence["template_contract"]), artifact(run, evidence["template_integrity"])],
        },
        {
            "decision_id": f"DEC-SPEC05-{prefix}-ANCILLARY", "recorded_at": now(), "status": "closed", "rule_id": "CP-R02",
            "decision": "Accept only the renderer-recorded, frozen-template-declared static ancillary dependencies.",
            "evidence_refs": [artifact(run, evidence["template_integrity"])],
        },
        {
            "decision_id": f"DEC-SPEC05-{prefix}-WARNINGS", "recorded_at": now(), "status": "closed", "rule_id": "CP-R03",
            "decision": "The current compile log has no C0/C1 findings and no open C2 review; any closed C2 warning is bound to exact rendered-page evidence.",
            "evidence_refs": [artifact(run, evidence["warnings"]), artifact(run, evidence["compile_log"]), artifact(run, evidence["render_pack"])],
        },
    ]
    if warning_report_doc["status"] != "passed":
        raise ValueError("COMPILE_REVIEW_OPEN: warning decisions cannot close an unpassed warning report")
    event_path = run / "decisions/compile_decisions.jsonl"
    event_path.parent.mkdir(parents=True)
    event_path.write_text("".join(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n" for item in events), encoding="utf-8")
    decisions = list(parent["decisions"]) + [
        {"decision_id": item["decision_id"], "event_file": "decisions/compile_decisions.jsonl", "rule_id": item["rule_id"],
         "status": "closed", "supersedes": [], "invalidated_by": None}
        for item in events
    ]
    counts = Counter(item["status"] for item in decisions)
    index = {
        "schema_version": "canonical-decision-index/1.1", "version": int(parent.get("version", 0)) + 1,
        "snapshot_id": f"{args.run_id}-decisions", "spec_status": "passed",
        "acyclic_commit_rule": "producer_execution_capability_E_then_build_evidence_B_then_decision_index_D_then_stage_commit_M",
        "parent_index_ref": relative(run / "decisions", parent_index_path), "parent_index_hash": sha256_file(parent_index_path),
        "evidence_committed_before_index": [
            {"role": role, **artifact(run, path)} for role, path in evidence.items()
        ],
        "decisions": decisions,
        "summary": {key: counts[key] for key in ("closed", "superseded", "open", "invalidated", "stale")},
    }
    write_json(run / "decisions/canonical_decision_index.json", index)
    return index


def produce(args: argparse.Namespace) -> dict[str, Any]:
    import fitz

    run = args.run_dir.resolve()
    if run.exists():
        raise FileExistsError(f"refusing to overwrite immutable run: {run}")
    policy = validate_policy(args.build_policy.resolve())
    metadata = read_json(args.metadata_config.resolve())
    required_nonempty = policy["template_metadata_constraints"]["required_nonempty"]
    missing_metadata = [name for name in required_nonempty if not metadata.get("values", {}).get(name)]
    if missing_metadata:
        raise ValueError(f"template-required metadata values are empty: {missing_metadata}")
    gate = load_module(args.stage_gate.resolve(), "spec05_stage_promotion_gate")
    execution_core = load_module(args.execution_capability.resolve(), "spec05_execution_capability")
    freezer = load_module(Path(__file__).with_name("freeze_template_contract.py"), "spec05_template_freezer")
    renderer = load_module(Path(__file__).with_name("render_frozen_plan.py"), "spec05_plan_renderer")
    template_local_api = load_module(Path(__file__).with_name("template_local_api_usage.py"), "spec05_template_local_api_gate")
    validator = load_module(args.contract_validator.resolve(), "spec05_contract_validator")
    parent = verify_parent(gate, args.promotion_registry.resolve(), args.parent_promotion.resolve(), args.parent_lineage_key)
    promoted = parent["promotion"]["promoted_artifacts"]
    ledger = Path(promoted["ledger_L"]["path"])
    parent_index = Path(promoted["decision_index_D"]["path"])
    render_plan = Path(promoted["render_plan"]["path"])
    plan = read_json(render_plan)
    if sha256_file(args.capability_manifest.resolve()) != plan.get("capability_manifest_file_sha256"):
        raise ValueError("Spec 04-D render plan and supplied capability manifest differ")
    if sha256_file(args.template_zip.resolve()) != read_json(args.template_intake.resolve()).get("template_zip_sha256"):
        raise ValueError("template ZIP and Spec 01 template intake differ")
    if sha256_file(args.media_representation_plan.resolve()) not in {
        (node.get("media_binding") or node.get("payload", {}).get("media_binding") or {}).get("media_representation_plan_sha256")
        for node in plan.get("nodes", [])
        if node.get("media_binding") or node.get("payload", {}).get("media_binding")
    }:
        raise ValueError("supplied media representation plan is not bound by the active render plan")

    run.mkdir(parents=True)
    template_dir = run / "precommit/template"
    safe_extract(args.template_zip.resolve(), template_dir)
    capability = capability_manifest(args, execution_core, run)
    write_json(run / "precommit/execution_capability_manifest.json", capability)

    contract_path = run / "contracts/template_contract.json"
    capability_validation = run / "reports/template_capability_validation_report.json"
    freeze_args = argparse.Namespace(
        template_dir=template_dir, template_zip=args.template_zip.resolve(), capability_manifest=args.capability_manifest.resolve(),
        metadata_config=args.metadata_config.resolve(), presentation_config=args.presentation_config.resolve(),
        entry="main.tex", body_marker=args.body_marker,
        body_end_token=r"\end{document}", engine=policy["compile"].get("engine", "XeLaTeX"),
        driver=" ".join(policy["compile"]["command"][:2]), container=policy["compile"]["container"],
        minimum_tex=policy["compile"].get("minimum_tex", "declared by build policy"),
        max_runs=int(policy["compile"].get("max_runs", 5)), contract_validator=args.contract_validator.resolve(),
        output=contract_path, validation_report=capability_validation,
    )
    contract, cap_report = freezer.freeze(freeze_args)
    write_json(contract_path, contract)
    write_json(capability_validation, cap_report)

    mechanical = run / "mechanical"
    render_args = argparse.Namespace(
        template_dir=template_dir, template_contract=contract_path, ledger=ledger, decision_index=parent_index,
        render_plan=render_plan, capability_manifest=args.capability_manifest.resolve(), asset_root=args.asset_root,
        source_pdf=args.source_pdf.resolve(), source_page_dir=args.source_page_dir.resolve(),
        contract_validator=args.contract_validator.resolve(), media_evidence_ledger=args.media_evidence_ledger.resolve(),
        media_representation_plan=args.media_representation_plan.resolve(), media_validator=args.media_validator.resolve(),
        out_dir=mechanical,
    )
    renderer.run(render_args)
    for name in ("render_execution_report.json", "template_integrity_report.json", "template_integrity_report.md", "asset_materialization_report.json", "intermediate_contract_validation.json", "media_contract_validation.json", "media_render_binding_validation.json"):
        source = mechanical / "reports" / name
        if source.is_file():
            target = run / "reports" / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    (run / "render").mkdir()
    shutil.copy2(mechanical / "render/rendered_body.tex", run / "render/rendered_body.tex")
    template_local_api_report = template_local_api.audit_template_local_api_usage(
        args.capability_manifest.resolve(), run / "render/rendered_body.tex"
    )
    write_json(run / "reports/template_local_api_usage_report.json", template_local_api_report)
    if template_local_api_report["spec_status"] != "passed":
        raise ValueError(f"TP-H14 template-local custom API usage: {template_local_api_report['violations'][:8]}")

    mechanical_zip = mechanical / "delivery/elegantbook-project.zip"
    delivery = run / "delivery"
    delivery.mkdir()
    delivery_zip = delivery / "elegantbook-project.zip"
    shutil.copy2(mechanical_zip, delivery_zip)
    if sha256_file(mechanical_zip) != sha256_file(delivery_zip):
        raise ValueError("delivery ZIP differs from mechanical renderer output")
    environment, outputs = compile_exact_zip(run, delivery_zip, policy)
    delivery_pdf = delivery / "elegantbook-output.pdf"
    shutil.copy2(outputs["main.pdf"], delivery_pdf)
    render_pack = render_pdf(run, delivery_pdf, policy)
    build_id = f"build-{sha256_file(delivery_zip)[:12]}-{sha256_file(delivery_pdf)[:12]}"
    render_pack["build_id"] = build_id
    write_json(run / "final_render_pack/manifest.json", render_pack)
    warnings = warning_report(outputs["main.log"], args.warning_review.resolve() if args.warning_review else None, run / "final_render_pack/pages")
    write_json(run / "reports/compile_warnings.json", warnings)
    if warnings["status"] != "passed":
        write_json(run / "reports/needs_review.json", {
            "schema_version": "spec05-review-state/1.0", "generated_at": now(), "spec_status": warnings["status"],
            "failure_code": "COMPILE_REVIEW_OPEN" if warnings["status"] == "needs_review" else "COMPILE_BLOCKING_WARNING",
            "warning_report": artifact(run, run / "reports/compile_warnings.json"),
        })
        raise ValueError(f"compile warnings require closure: {warnings['status']}")

    integrity = final_integrity(
        run, template_dir, delivery_zip, run / "build/clean-src", contract_path,
        args.capability_manifest.resolve(), render_plan, mechanical, outputs["main.fls"], validator,
        template_local_api_report,
    )
    write_json(run / "reports/template_integrity_final_report.json", integrity)
    (run / "reports/template_integrity_report.md").write_text(
        "# Template integrity report\n\nStatus: `passed`\n\nAll 14 template hard gates passed for the exact delivery ZIP.\n",
        encoding="utf-8",
    )
    evidence = {
        "execution_capability": run / "precommit/execution_capability_manifest.json",
        "template_contract": contract_path, "template_integrity": run / "reports/template_integrity_final_report.json",
        "template_local_api_usage": run / "reports/template_local_api_usage_report.json",
        "presentation_config": args.presentation_config.resolve(),
        "formal_zip": delivery_zip, "final_pdf": delivery_pdf, "compile_log": outputs["main.log"],
        "warnings": run / "reports/compile_warnings.json", "render_pack": run / "final_render_pack/manifest.json",
    }
    decisions = create_decisions(run, args, parent_index, evidence, warnings)
    decision_path = run / "decisions/canonical_decision_index.json"

    reader = fitz.open(delivery_pdf)
    hard_gates = {**{f"TP-H{i:02d}": True for i in range(1, 15)}, **{f"CP-H{i:02d}": True for i in range(1, 18)}}
    compile_report = {
        "schema_version": "compile-report/3.0", "generated_at": now(), "spec_status": "passed",
        "promotion_class": "formal_native", "build_id": build_id,
        "input": {
            "parent_spec04d_promotion_sha256": sha256_file(args.parent_promotion.resolve()),
            "parent_spec04d_stage_manifest_sha256": sha256_file(parent["stage_path"]),
            "ledger_snapshot_id": plan["source_ledger_snapshot_id"], "render_plan_sha256": sha256_file(render_plan),
            "template_contract_sha256": sha256_file(contract_path), "formal_zip_sha256": sha256_file(delivery_zip),
            "presentation_config_sha256": sha256_file(args.presentation_config.resolve()),
        },
        "command": policy["compile"]["command"], "clean_build": True, "exit_code": 0,
        "converged": not bool(re.search(r"Rerun to get cross-references right|Label\(s\) may have changed", outputs["main.log"].read_text(errors="replace"))),
        "pdf": {"path": "delivery/elegantbook-output.pdf", "sha256": sha256_file(delivery_pdf), "pages": reader.page_count, "pymupdf_readable": True},
        "log": artifact(run, outputs["main.log"]), "warning_summary": warnings["summary"],
        "render_pack": {**artifact(run, run / "final_render_pack/manifest.json"), "render_job_id": render_pack["render_job_id"]},
        "decision_index": artifact(run, decision_path),
        "render_summary": read_json(run / "reports/render_execution_report.json")["summary"],
        "hard_gates": hard_gates,
        "scope_limit": "Spec 05 compile_pass and final_render_pack only; render coverage, Spec 06, and product acceptance are not evaluated.",
    }
    if not compile_report["converged"]:
        raise ValueError("COMPILE_REFERENCE_NOT_CONVERGED")
    write_json(run / "reports/compile_report.json", compile_report)
    (run / "reports/compile_report.md").write_text(
        f"# Spec 05 compile report\n\nStatus: `passed`\n\n- Build: `{build_id}`\n- ZIP: `{sha256_file(delivery_zip)}`\n- PDF: `{sha256_file(delivery_pdf)}`\n- Pages: {reader.page_count}\n\nNo render coverage or Spec 06 claim is made.\n",
        encoding="utf-8",
    )
    artifacts = {
        "execution_capability_E": artifact(run, run / "precommit/execution_capability_manifest.json", payload_hash=capability["payload_hash"]),
        "template_contract": artifact(run, contract_path), "template_capability_manifest": artifact(run, args.capability_manifest.resolve()),
        "template_capability_validation": artifact(run, capability_validation),
        "presentation_config": artifact(run, args.presentation_config.resolve()),
        "template_integrity": artifact(run, run / "reports/template_integrity_final_report.json"),
        "template_local_api_usage": artifact(run, run / "reports/template_local_api_usage_report.json"),
        "rendered_body": artifact(run, run / "render/rendered_body.tex"),
        "render_execution": artifact(run, run / "reports/render_execution_report.json"),
        "build_environment": artifact(run, run / "build/build_environment.json"),
        "compile_process": artifact(run, run / "build/compile-process.json"),
        "formal_zip": artifact(run, delivery_zip), "final_pdf": artifact(run, delivery_pdf),
        "compile_log": artifact(run, outputs["main.log"]), "fls": artifact(run, outputs["main.fls"]),
        "warnings": artifact(run, run / "reports/compile_warnings.json"),
        "render_pack": artifact(run, run / "final_render_pack/manifest.json"),
        "decision_index_D": artifact(run, decision_path), "compile_report": artifact(run, run / "reports/compile_report.json"),
    }
    build_manifest = {
        "schema_version": "build-manifest/3.0", "generated_at": now(), "build_id": build_id,
        "status": "passed", "spec_status": "passed", "promotion_class": "formal_native",
        "formal_zip_is_build_input": True, "clean_build": True,
        "commit_order": ["producer_execution_capability_E", "exact_zip_compile_and_render_evidence_B", "decision_index_D", "build_and_stage_commit_M"],
        "parent_spec04d_promotion": {"path": str(args.parent_promotion.resolve()), "sha256": sha256_file(args.parent_promotion.resolve()), "lineage_key": args.parent_lineage_key},
        "parent_spec04d_stage_manifest": {"path": str(parent["stage_path"]), "sha256": sha256_file(parent["stage_path"])},
        "artifacts": artifacts,
    }
    write_json(run / "manifests/build_manifest.json", build_manifest)
    stage = {
        "schema_version": STAGE_SCHEMA, "generated_at": now(), "run_id": args.run_id,
        "stage_kind": "spec05_native_execution", "status": "passed", "spec_status": "passed", "promotion_class": "formal_native",
        "producer": VERSION, "commit_order": build_manifest["commit_order"],
        "parent_spec04d": {
            "lineage_key": args.parent_lineage_key, "promotion_id": parent["promotion"]["promotion_id"],
            "promotion_path": str(args.parent_promotion.resolve()), "promotion_sha256": sha256_file(args.parent_promotion.resolve()),
            "registry_path": str(args.promotion_registry.resolve()), "registry_sha256": sha256_file(args.promotion_registry.resolve()),
            "stage_manifest_path": str(parent["stage_path"]), "stage_manifest_sha256": sha256_file(parent["stage_path"]),
        },
        "execution_capability_E": artifacts["execution_capability_E"], "decision_index_D": artifacts["decision_index_D"],
        "template_contract": artifacts["template_contract"], "presentation_config": artifacts["presentation_config"],
        "template_local_api_usage": artifacts["template_local_api_usage"],
        "build_manifest_M": {"path": "manifests/build_manifest.json", "sha256": sha256_file(run / "manifests/build_manifest.json")},
        "final_pdf": artifacts["final_pdf"], "delivery_zip": artifacts["formal_zip"], "render_pack": artifacts["render_pack"],
        "hard_gates": hard_gates,
        "presentation_hard_gates": {"PR-H01-explicit-cover-logo": True, "PR-H02-closed-decisions": True, "PR-H03-frozen-assets-preserved": True, "PR-H04-materialized-assets-bound": True},
        "scope_prohibitions": ["semantic_reclassification", "construct_reselection", "media_reselection", "layout_reselection", "presentation_inference", "formula_reconstruction", "table_reconstruction", "render_coverage_claim", "spec06_claim", "product_acceptance_claim"],
        "scope_limit": compile_report["scope_limit"],
    }
    write_json(run / "manifests/spec05_native_stage_manifest.json", stage)
    files = [
        {"path": path.relative_to(run).as_posix(), "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        for path in sorted(run.rglob("*")) if path.is_file() and path.name != "run_manifest.json"
    ]
    write_json(run / "manifests/run_manifest.json", {
        "schema_version": "immutable-run-manifest/1.1", "run_id": args.run_id, "generated_at": now(),
        "status": "passed", "stage_kind": "spec05_native_execution", "promotion_class": "formal_native",
        "immutable_after_publication": True, "files": files,
    })
    return {"status": "passed", "run": str(run), "build_id": build_id, "zip_sha256": sha256_file(delivery_zip), "pdf_sha256": sha256_file(delivery_pdf), "pages": reader.page_count}


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--run-dir", type=Path, required=True)
    value.add_argument("--run-id", required=True)
    value.add_argument("--promotion-registry", type=Path, required=True)
    value.add_argument("--parent-promotion", type=Path, required=True)
    value.add_argument("--parent-lineage-key", required=True)
    value.add_argument("--template-zip", type=Path, required=True)
    value.add_argument("--template-intake", type=Path, required=True)
    value.add_argument("--capability-manifest", type=Path, required=True)
    value.add_argument("--metadata-config", type=Path, required=True)
    value.add_argument("--presentation-config", type=Path, required=True)
    value.add_argument("--body-marker", required=True)
    value.add_argument("--media-evidence-ledger", type=Path, required=True)
    value.add_argument("--media-representation-plan", type=Path, required=True)
    value.add_argument("--asset-root", type=Path, action="append", default=[], required=True)
    value.add_argument("--source-pdf", type=Path, required=True)
    value.add_argument("--source-page-dir", type=Path, required=True)
    value.add_argument("--build-policy", type=Path, required=True)
    value.add_argument("--warning-review", type=Path)
    default_orchestrator = Path.home() / ".codex/skills/luceon-popo-to-refined-elegantbook/scripts"
    value.add_argument("--stage-gate", type=Path, default=default_orchestrator / "stage_promotion_gate.py")
    value.add_argument("--execution-capability", type=Path, default=default_orchestrator / "execution_capability.py")
    value.add_argument("--contract-validator", type=Path, default=default_orchestrator / "validate_intermediate_contracts.py")
    value.add_argument("--media-validator", type=Path, default=default_orchestrator / "media_source_representation.py")
    return value


def main() -> int:
    args = parser().parse_args()
    try:
        print(json.dumps(produce(args), ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "failed", "producer": VERSION, "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
