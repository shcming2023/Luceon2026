import importlib.util
import json
from pathlib import Path


SCRIPT = Path(__file__).parents[1] / "scripts/produce_native_spec05.py"
SPEC = importlib.util.spec_from_file_location("native_spec05", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(MODULE)

API_SCRIPT = Path(__file__).parents[1] / "scripts/template_local_api_usage.py"
API_SPEC = importlib.util.spec_from_file_location("template_local_api_usage", API_SCRIPT)
API = importlib.util.module_from_spec(API_SPEC)
assert API_SPEC.loader
API_SPEC.loader.exec_module(API)


def test_warning_report_requires_exact_c2_closure(tmp_path: Path) -> None:
    log = tmp_path / "main.log"
    pages = tmp_path / "pages"
    pages.mkdir()
    (pages / "page-001.png").write_bytes(b"visual-evidence")
    log.write_text("Overfull \\hbox (3.0pt too wide) in paragraph at lines 10--11\n", encoding="utf-8")
    first = MODULE.warning_report(log, None, pages)
    assert first["status"] == "needs_review"
    event = first["events"][0]
    review = tmp_path / "review.json"
    review.write_text(json.dumps({
        "schema_version": "spec05-warning-review/1.0",
        "status": "approved",
        "closures": [{
            "fingerprint": event["fingerprint"],
            "classification": "C2_REVIEW_REQUIRED_CLOSED",
            "rationale": "Exact rendered page inspection shows no clipping or lost content.",
            "visual_pages": [1],
        }],
    }), encoding="utf-8")
    closed = MODULE.warning_report(log, review, pages)
    assert closed["status"] == "passed"
    assert closed["summary"]["C2_REVIEW_REQUIRED_CLOSED"] == 1
    assert closed["events"][0]["visual_evidence"][0]["sha256"] == MODULE.sha256_file(pages / "page-001.png")


def test_warning_report_never_allows_missing_glyph_review_override(tmp_path: Path) -> None:
    log = tmp_path / "main.log"
    pages = tmp_path / "pages"
    pages.mkdir()
    log.write_text("Missing character: There is no X in font nullfont!\n", encoding="utf-8")
    report = MODULE.warning_report(log, None, pages)
    assert report["status"] == "failed"
    assert report["summary"]["C1_BLOCKING"] == 1


def test_build_policy_accepts_both_supported_poppler_renderers(tmp_path: Path) -> None:
    base = {
        "schema_version": "spec05-build-policy/1.0",
        "status": "approved",
        "template_metadata_constraints": {"required_nonempty": ["title"]},
        "compile": {
            "executor": "docker_copy_exec", "container": "tex", "entry": "main.tex",
            "command": ["latexmk", "main.tex"],
        },
        "render": {"renderer": "pdftoppm", "format": "png", "dpi": 110},
    }
    policy = tmp_path / "policy.json"
    for renderer in ("pdftoppm", "pdftocairo"):
        base["render"]["renderer"] = renderer
        policy.write_text(json.dumps(base), encoding="utf-8")
        assert MODULE.validate_policy(policy)["render"]["renderer"] == renderer


def test_build_policy_rejects_unknown_renderer(tmp_path: Path) -> None:
    policy = tmp_path / "policy.json"
    policy.write_text(json.dumps({
        "schema_version": "spec05-build-policy/1.0",
        "status": "approved",
        "template_metadata_constraints": {"required_nonempty": ["title"]},
        "compile": {"executor": "docker_copy_exec", "container": "tex", "entry": "main.tex", "command": ["latexmk"]},
        "render": {"renderer": "sample-specific-renderer", "format": "png", "dpi": 110},
    }), encoding="utf-8")
    try:
        MODULE.validate_policy(policy)
    except ValueError as exc:
        assert "supported Poppler PNG renderer" in str(exc)
    else:
        raise AssertionError("unknown renderer must be rejected")


def test_package_info_substitution_is_not_misclassified_as_warning(tmp_path: Path) -> None:
    log = tmp_path / "main.log"
    pages = tmp_path / "pages"
    pages.mkdir()
    log.write_text("Package xcolor Info: Model `HTML' substituted by `rgb' on input line 9.\n", encoding="utf-8")
    report = MODULE.warning_report(log, None, pages)
    assert report["status"] == "passed"
    assert report["events"] == []


def test_tp_h14_allows_standard_tcolorbox_style_usage() -> None:
    body = "\\begin{tcolorbox}[featurebox,title={Source-backed}]\nBody\n\\end{tcolorbox}\n"
    assert API.scan_text(["activitynum"], ["answershow", "internalanswerbox"], body) == []


def test_tp_h14_rejects_template_local_command_and_environment() -> None:
    body = "\\activitynum{1}\n\\begin{answershow}x\\end{answershow}\n"
    violations = API.scan_text(["activitynum"], ["answershow"], body)
    assert {item["kind"] for item in violations} == {
        "template_local_command_call", "template_local_environment_call"
    }


def test_tp_h14_ignores_commented_calls() -> None:
    body = "% \\activitynum{1}\nText with escaped \\% sign.\n"
    assert API.scan_text(["activitynum"], ["answershow"], body) == []


def test_tp_h14_accepts_legacy_top_level_capability_inventory(tmp_path: Path) -> None:
    capability = tmp_path / "capability.json"
    body = tmp_path / "body.tex"
    capability.write_text(json.dumps({"custom_commands": ["activitynum"], "custom_environments": ["answershow"]}), encoding="utf-8")
    body.write_text("Ordinary text.\n", encoding="utf-8")
    assert API.audit_template_local_api_usage(capability, body)["spec_status"] == "passed"
