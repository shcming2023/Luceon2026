#!/usr/bin/env python3
"""Independent promotion evaluator for formal-native Spec 05 execution runs."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import zipfile
from pathlib import Path
from typing import Any, Callable


VERSION = "spec05-native-promotion-gate/1.2.0"

COMMAND_DEFINITION_PATTERNS = (
    re.compile(r"\\(?:newcommand|renewcommand|providecommand|DeclareRobustCommand|NewDocumentCommand|RenewDocumentCommand|ProvideDocumentCommand)\s*\{?\s*\\([A-Za-z@]+)"),
    re.compile(r"\\(?:def|gdef|edef|xdef)\s*\\([A-Za-z@]+)"),
)
ENVIRONMENT_DEFINITION_PATTERN = re.compile(
    r"\\(?:newenvironment|renewenvironment|provideenvironment|NewDocumentEnvironment|RenewDocumentEnvironment|ProvideDocumentEnvironment|DeclareDocumentEnvironment)\s*\{\s*([^{}\s]+)\s*\}"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resolve(run: Path, item: dict[str, Any]) -> Path:
    path = (run / item["path"]).resolve()
    if not path.is_file() or sha256_file(path) != item.get("sha256"):
        raise ValueError(f"missing or drifted Spec 05 artifact: {item.get('path')}")
    return path


def strip_tex_comments(text: str) -> str:
    cleaned: list[str] = []
    for line in text.splitlines(keepends=True):
        cut = len(line)
        for index, char in enumerate(line):
            if char != "%":
                continue
            cursor = index - 1
            backslashes = 0
            while cursor >= 0 and line[cursor] == "\\":
                backslashes += 1
                cursor -= 1
            if backslashes % 2 == 0:
                cut = index
                break
        suffix = "\n" if line.endswith("\n") else ""
        cleaned.append(line[:cut].rstrip("\r\n") + suffix)
    return "".join(cleaned)


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def independent_template_local_api_scan(capability_path: Path, body_path: Path) -> dict[str, Any]:
    capability = read_json(capability_path)
    constructs = capability.get("constructs")
    if not isinstance(constructs, dict):
        constructs = capability if {"custom_commands", "custom_environments"}.issubset(capability) else None
    if not isinstance(constructs, dict):
        raise ValueError("capability manifest lacks constructs inventory")
    commands = constructs.get("custom_commands")
    environments = constructs.get("custom_environments")
    if not isinstance(commands, list) or not isinstance(environments, list):
        raise ValueError("capability manifest lacks explicit template-local API inventories")
    inventory = [*commands, *environments]
    if any(not isinstance(name, str) or not name for name in inventory):
        raise ValueError("template-local API inventory contains an invalid name")
    if len(commands) != len(set(commands)) or len(environments) != len(set(environments)):
        raise ValueError("template-local API inventory contains duplicate names")
    scanned = strip_tex_comments(body_path.read_text(encoding="utf-8"))
    violations: list[dict[str, Any]] = []
    for pattern in COMMAND_DEFINITION_PATTERNS:
        for match in pattern.finditer(scanned):
            name = match.group(1)
            if name in commands:
                violations.append({"kind": "template_local_command_definition", "name": name, "line": line_number(scanned, match.start())})
    for match in ENVIRONMENT_DEFINITION_PATTERN.finditer(scanned):
        name = match.group(1)
        if name in environments:
            violations.append({"kind": "template_local_environment_definition", "name": name, "line": line_number(scanned, match.start())})
    for name in sorted(commands):
        for match in re.finditer(rf"\\{re.escape(name)}(?![A-Za-z@])", scanned):
            violations.append({"kind": "template_local_command_call", "name": name, "line": line_number(scanned, match.start())})
    for name in sorted(environments):
        for match in re.finditer(rf"\\(begin|end)\s*\{{\s*{re.escape(name)}\s*\}}", scanned):
            violations.append({"kind": "template_local_environment_call", "name": name, "line": line_number(scanned, match.start())})
    violations.sort(key=lambda item: (item["line"] or 0, item["kind"], item["name"]))
    return {
        "inventory": {
            "template_local_custom_commands": sorted(commands),
            "template_local_custom_environments": sorted(environments),
        },
        "violations": violations,
    }


class Gate:
    def __init__(self) -> None:
        self.checks: list[dict[str, Any]] = []

    def check(self, check_id: str, fn: Callable[[], Any]) -> None:
        try:
            self.checks.append({"check_id": check_id, "status": "passed", "evidence": fn()})
        except Exception as exc:
            self.checks.append({"check_id": check_id, "status": "failed", "detail": str(exc)})

    @property
    def passed(self) -> bool:
        return all(item["status"] == "passed" for item in self.checks)


def preflight_parent(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    """Emit evidence for Spec 05 parent eligibility without creating a build."""
    stage_gate = load_module(Path(__file__).with_name("stage_promotion_gate.py"), "spec05_parent_preflight_gate")
    registry_path = args.promotion_registry.resolve()
    promotion_path = args.parent_promotion.resolve()
    registry = read_json(registry_path)
    promotion = read_json(promotion_path)
    gate = Gate()

    def active_selection() -> dict[str, Any]:
        if registry.get("schema_version") != "promotion-registry/1.0":
            raise ValueError("unsupported promotion registry")
        computed = stage_gate.canonical_hash({key: value for key, value in registry.items() if key not in {"generated_at", "payload_hash"}})
        if computed != registry.get("payload_hash"):
            raise ValueError("promotion registry payload hash mismatch")
        active = registry.get("active_promotions", {}).get(args.parent_lineage_key)
        if not active:
            raise ValueError("registry has no active selection for the supplied lineage")
        if Path(active["manifest_path"]).resolve() != promotion_path or active["manifest_sha256"] != sha256_file(promotion_path):
            raise ValueError("supplied promotion is not the registry active selection")
        if active["promotion_id"] != promotion.get("promotion_id"):
            raise ValueError("registry and promotion identities differ")
        return {"promotion_id": active["promotion_id"], "lineage_key": args.parent_lineage_key}

    def full_formal_spec04d() -> dict[str, Any]:
        if promotion.get("disposition") != "promoted" or promotion.get("promotion_class") != "formal_native":
            raise ValueError("SPEC05_PARENT_NOT_FORMAL_NATIVE")
        if promotion.get("stage_kind") != "spec04d_render_plan_contract":
            raise ValueError(f"SPEC05_PARENT_NOT_FULL_SPEC04D: got {promotion.get('stage_kind')}")
        verified = stage_gate.verify_promotion_manifest(
            promotion_path, "spec04d_render_plan_contract", "formal_native", capability_verification="frozen"
        )
        stage = read_json(Path(verified["stage_manifest"]["path"]))
        if stage.get("full_spec04_status") != "passed" or stage.get("producer_mode") != "formal_native":
            raise ValueError("SPEC05_PARENT_NOT_FULL_SPEC04D: full Spec 04 status is not passed")
        return {"full_spec04_status": "passed", "producer_mode": "formal_native"}

    gate.check("S5-ELIG-H01-active-registry-selection", active_selection)
    gate.check("S5-ELIG-H02-full-formal-spec04d", full_formal_spec04d)
    eligible = gate.passed
    report = {
        "schema_version": "spec05-parent-eligibility/1.0", "evaluated_at": stage_gate.now(),
        "eligible": eligible, "promotion_registry": {"path": str(registry_path), "sha256": sha256_file(registry_path)},
        "parent_promotion": {"path": str(promotion_path), "sha256": sha256_file(promotion_path)},
        "parent_lineage_key": args.parent_lineage_key, "checks": gate.checks,
        "failure_code": None if eligible else "SPEC05_PARENT_NOT_FULL_SPEC04D",
        "scope_limit": "Parent eligibility only; no Spec 05 build or compile claim.",
    }
    stage_gate.write_json(args.output.resolve(), report)
    return report, 0 if eligible else 4


def evaluate_promotion(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    run = args.run_dir.resolve()
    output = args.output.resolve()
    stage_gate = load_module(Path(__file__).with_name("stage_promotion_gate.py"), "spec05_parent_gate")
    execution = load_module(Path(__file__).with_name("execution_capability.py"), "spec05_execution_capability_gate")
    stage_path = run / "manifests/spec05_native_stage_manifest.json"
    if not stage_path.is_file():
        raise FileNotFoundError(stage_path)
    stage = read_json(stage_path)
    skill_root = Path(__file__).resolve().parents[1]
    evaluator_path = (
        args.evaluator_capability_output.resolve()
        if getattr(args, "evaluator_capability_output", None)
        else output.with_suffix(".evaluator-capability.json")
    )
    evaluator = execution.build_manifest(
        manifest_id=f"{args.promotion_id}-evaluator-capability",
        skill_root=skill_root,
        entrypoints=[
            ("promotion_router", Path(__file__).with_name("stage_promotion_gate.py").resolve()),
            ("spec05_evaluator", Path(__file__).resolve()),
            ("execution_capability_core", Path(__file__).with_name("execution_capability.py").resolve()),
        ],
        resources=[
            ("stage_schema", Path.home() / ".codex/skills/cleanlatex-to-elegantbook/schemas/spec05-native-stage-manifest.schema.json"),
            ("promotion_schema", skill_root / "schemas/stage-promotion-manifest.schema.json"),
            ("registry_schema", skill_root / "schemas/promotion-registry.schema.json"),
        ],
        invocation=[
            "stage_promotion_gate.py", "evaluate-spec05-build", "--run-dir", str(run),
            "--promotion-id", args.promotion_id, "--lineage-key", args.lineage_key,
            "--evaluator-capability-output", str(evaluator_path), "--output", str(output),
        ],
        producer=VERSION,
    )
    stage_gate.write_json(evaluator_path, evaluator)
    gate = Gate()
    context: dict[str, Any] = {}
    artifacts: dict[str, dict[str, Any]] = {}

    def stage_shape() -> dict[str, Any]:
        if stage.get("schema_version") != "spec05-native-stage-manifest/1.2" or stage.get("stage_kind") != "spec05_native_execution":
            raise ValueError("unsupported Spec 05 native stage manifest")
        if stage.get("status") != "passed" or stage.get("spec_status") != "passed" or stage.get("promotion_class") != "formal_native":
            raise ValueError("Spec 05 run did not self-report a formal-native pass")
        required = {"execution_capability_E", "decision_index_D", "build_manifest_M", "final_pdf", "delivery_zip", "render_pack", "parent_spec04d", "template_contract", "presentation_config", "presentation_hard_gates", "template_local_api_usage"}
        missing = sorted(required - set(stage))
        if missing:
            raise ValueError(f"stage manifest lacks required fields: {missing}")
        return {"run_id": stage["run_id"], "promotion_class": stage["promotion_class"]}

    def artifact_hashes() -> dict[str, Any]:
        for name in ("execution_capability_E", "decision_index_D", "build_manifest_M", "final_pdf", "delivery_zip", "render_pack", "template_contract", "presentation_config", "template_local_api_usage"):
            path = resolve(run, stage[name])
            artifacts[name] = {"path": str(path), "sha256": sha256_file(path)}
        artifacts["producer_execution_capability"] = dict(artifacts["execution_capability_E"])
        build = read_json(Path(artifacts["build_manifest_M"]["path"]))
        for name, item in build.get("artifacts", {}).items():
            path = resolve(run, item)
            artifacts.setdefault(name, {"path": str(path), "sha256": sha256_file(path)})
        required_build = {"template_capability_manifest", "rendered_body", "template_local_api_usage", "template_integrity", "compile_report"}
        missing = sorted(required_build - set(artifacts))
        if missing:
            raise ValueError(f"build manifest lacks TP-H14 evidence: {missing}")
        context["build"] = build
        return {"artifacts": len(artifacts)}

    def active_parent() -> dict[str, Any]:
        parent = stage["parent_spec04d"]
        registry = Path(parent["registry_path"])
        promotion = Path(parent["promotion_path"])
        if sha256_file(registry) != parent["registry_sha256"] or sha256_file(promotion) != parent["promotion_sha256"]:
            raise ValueError("Spec 04-D registry or promotion binding drifted")
        selected = stage_gate.verify_registry_selection(
            registry, parent["lineage_key"], promotion,
            "spec04d_render_plan_contract", "formal_native", capability_verification="frozen",
        )
        if selected["promotion"]["promotion_id"] != parent["promotion_id"]:
            raise ValueError("active Spec 04-D promotion identity differs")
        return {"promotion_id": parent["promotion_id"], "lineage_key": parent["lineage_key"]}

    def template_gates() -> dict[str, Any]:
        report = read_json(Path(artifacts["template_integrity"]["path"]))
        hard = stage.get("hard_gates", {})
        failed = [f"TP-H{index:02d}" for index in range(1, 15) if hard.get(f"TP-H{index:02d}") is not True]
        if report.get("status") != "passed" or failed:
            raise ValueError(f"template gates failed: {failed}")
        checks = report.get("checks", {})
        if not checks or not all(checks.values()):
            raise ValueError("template integrity report contains a failed check")
        return {"hard_gates": 14, "integrity_checks": len(checks)}

    def template_local_api_usage() -> dict[str, Any]:
        capability_path = Path(artifacts["template_capability_manifest"]["path"])
        body_path = Path(artifacts["rendered_body"]["path"])
        report_path = Path(artifacts["template_local_api_usage"]["path"])
        report = read_json(report_path)
        independent = independent_template_local_api_scan(capability_path, body_path)
        expected_inputs = report.get("inputs", {})
        if expected_inputs.get("capability_manifest", {}).get("sha256") != sha256_file(capability_path):
            raise ValueError("producer TP-H14 report is not bound to the promoted capability manifest")
        if expected_inputs.get("rendered_body", {}).get("sha256") != sha256_file(body_path):
            raise ValueError("producer TP-H14 report is not bound to the promoted rendered body")
        if report.get("schema_version") != "spec05-template-local-api-usage/1.0":
            raise ValueError("unsupported producer TP-H14 report schema")
        if report.get("inventory") != independent["inventory"] or report.get("violations") != independent["violations"]:
            raise ValueError("producer TP-H14 report differs from independent evaluator rescan")
        if report.get("spec_status") != "passed" or report.get("gate") != {"gate_id": "TP-H14", "status": "passed"}:
            raise ValueError("producer TP-H14 report did not pass")
        if independent["violations"]:
            raise ValueError(f"template-local custom API usage found: {independent['violations'][:8]}")
        return {
            "capability_manifest_sha256": sha256_file(capability_path),
            "rendered_body_sha256": sha256_file(body_path),
            "producer_report_sha256": sha256_file(report_path),
            "inventory": independent["inventory"],
            "violations": 0,
        }

    def compile_gates() -> dict[str, Any]:
        report = read_json(Path(artifacts["compile_report"]["path"]))
        hard = report.get("hard_gates", {})
        failed = [f"CP-H{index:02d}" for index in range(1, 18) if hard.get(f"CP-H{index:02d}") is not True]
        if report.get("spec_status") != "passed" or report.get("exit_code") != 0 or failed:
            raise ValueError(f"compile gates failed: {failed}")
        if report.get("scope_limit") != "Spec 05 compile_pass and final_render_pack only; render coverage, Spec 06, and product acceptance are not evaluated.":
            raise ValueError("Spec 05 compile report claims an unapproved scope")
        return {"hard_gates": 17, "pages": report["pdf"]["pages"]}

    def decision_closure() -> dict[str, Any]:
        index = read_json(Path(artifacts["decision_index_D"]["path"]))
        unresolved = [item.get("decision_id") for item in index.get("decisions", []) if item.get("status") in {"open", "stale", "invalidated"}]
        if index.get("spec_status") != "passed" or unresolved or index.get("summary", {}).get("open") != 0:
            raise ValueError(f"Spec 05 decision index is unresolved: {unresolved[:8]}")
        return {"decisions": len(index.get("decisions", [])), "open": 0}

    def presentation_contract() -> dict[str, Any]:
        contract_path = Path(artifacts["template_contract"]["path"])
        config_path = Path(artifacts["presentation_config"]["path"])
        contract = read_json(contract_path)
        config = read_json(config_path)
        if contract.get("schema_version") != "template-contract/2.0" or contract.get("status") != "frozen":
            raise ValueError("formal-native Spec 05 requires template-contract/2.0")
        binding = contract.get("presentation_config", {})
        bound_ref = Path(binding.get("ref", ""))
        bound_path = bound_ref if bound_ref.is_absolute() else (contract_path.parent / bound_ref).resolve()
        if bound_path != config_path.resolve() or binding.get("sha256") != sha256_file(config_path):
            raise ValueError("template contract and presentation config binding differ")
        if config.get("schema_version") != "spec05-presentation-config/1.0" or config.get("status") != "approved":
            raise ValueError("presentation config is not approved")
        if config.get("template_zip_sha256") != contract.get("template_zip", {}).get("sha256"):
            raise ValueError("presentation config and template ZIP binding differ")
        assets = contract.get("selected_presentation", {}).get("assets")
        if not isinstance(assets, dict) or set(assets) != {"cover", "logo"}:
            raise ValueError("presentation contract does not bind exact cover and logo")
        hard = stage.get("presentation_hard_gates", {})
        if set(hard) != {"PR-H01-explicit-cover-logo", "PR-H02-closed-decisions", "PR-H03-frozen-assets-preserved", "PR-H04-materialized-assets-bound"} or not all(hard.values()):
            raise ValueError("presentation hard gates are incomplete")
        index = read_json(Path(artifacts["decision_index_D"]["path"]))
        presentation_decisions = [item for item in index.get("decisions", []) if item.get("rule_id") == "CP-R04"]
        if len(presentation_decisions) != 1 or presentation_decisions[0].get("status") != "closed":
            raise ValueError("Spec 05 presentation decision is missing or unresolved")
        with zipfile.ZipFile(Path(artifacts["delivery_zip"]["path"])) as archive:
            names = set(archive.namelist())
            for name, item in assets.items():
                if item.get("decision", {}).get("status") != "closed" or item.get("compatibility", {}).get("status") != "approved":
                    raise ValueError(f"presentation {name} is not closed and approved")
                member = item.get("template_member") if item.get("mode") == "template_default" else item.get("project_path")
                if member not in names or hashlib.sha256(archive.read(member)).hexdigest() != item.get("asset_sha256"):
                    raise ValueError(f"presentation {name} asset is absent or drifted in the delivery ZIP")
        return {"assets": {name: assets[name]["mode"] for name in sorted(assets)}, "hard_gates": len(hard)}

    def commit_order() -> dict[str, Any]:
        expected = ["producer_execution_capability_E", "exact_zip_compile_and_render_evidence_B", "decision_index_D", "build_and_stage_commit_M"]
        if stage.get("commit_order") != expected or context["build"].get("commit_order") != expected:
            raise ValueError("Spec 05 E-to-B-to-D-to-M commit order is invalid")
        index = read_json(Path(artifacts["decision_index_D"]["path"]))
        if index.get("acyclic_commit_rule") != "producer_execution_capability_E_then_build_evidence_B_then_decision_index_D_then_stage_commit_M":
            raise ValueError("decision index has an invalid acyclic commit rule")
        return {"commit_order": expected}

    def exact_build_and_render_pack() -> dict[str, Any]:
        build = context["build"]
        if build.get("formal_zip_is_build_input") is not True or build.get("clean_build") is not True:
            raise ValueError("final ZIP was not the clean build input")
        pdf = Path(artifacts["final_pdf"]["path"])
        manifest = read_json(Path(artifacts["render_pack"]["path"]))
        if manifest.get("status") != "complete" or manifest.get("final_pdf", {}).get("sha256") != sha256_file(pdf):
            raise ValueError("final render pack is not bound to the final PDF")
        pages = manifest.get("pages", [])
        if len(pages) != manifest.get("page_count") or [item.get("index") for item in pages] != list(range(1, len(pages) + 1)):
            raise ValueError("final render pack page sequence is incomplete")
        for item in pages:
            path = Path(artifacts["render_pack"]["path"]).parent / item["raster_path"]
            if not path.is_file() or sha256_file(path) != item["raster_sha256"]:
                raise ValueError(f"rendered page is missing or drifted: {item.get('index')}")
        return {"pages": len(pages), "pdf_sha256": sha256_file(pdf)}

    def producer_capability() -> dict[str, Any]:
        path = Path(artifacts["execution_capability_E"]["path"])
        result = execution.validate_manifest(path)
        stored = read_json(path)
        if stage["execution_capability_E"].get("payload_hash") != stored.get("payload_hash"):
            raise ValueError("stage and producer capability payload hashes differ")
        context["producer_capability"] = result
        return result

    def evaluator_capability() -> dict[str, Any]:
        result = execution.validate_manifest(evaluator_path)
        artifacts["evaluator_execution_capability"] = {"path": str(evaluator_path), "sha256": sha256_file(evaluator_path)}
        return result

    def immutable_run() -> dict[str, Any]:
        path = run / "manifests/run_manifest.json"
        manifest = read_json(path)
        if manifest.get("status") != "passed" or manifest.get("stage_kind") != "spec05_native_execution" or manifest.get("immutable_after_publication") is not True:
            raise ValueError("run manifest is not an immutable Spec 05 pass")
        for item in manifest.get("files", []):
            target = run / item["path"]
            if not target.is_file() or sha256_file(target) != item["sha256"]:
                raise ValueError(f"immutable run file drifted: {item.get('path')}")
        artifacts["run_manifest"] = {"path": str(path), "sha256": sha256_file(path)}
        return {"files": len(manifest.get("files", []))}

    def scope_boundary() -> dict[str, Any]:
        prohibited = set(stage.get("scope_prohibitions", []))
        required = {"semantic_reclassification", "construct_reselection", "media_reselection", "layout_reselection", "presentation_inference", "render_coverage_claim", "spec06_claim", "product_acceptance_claim"}
        if not required.issubset(prohibited):
            raise ValueError("Spec 05 scope prohibitions are incomplete")
        return {"prohibitions": len(prohibited)}

    gate.check("S5-PG-H01-formal-native-stage-shape", stage_shape)
    gate.check("S5-PG-H02-stage-and-build-artifact-hashes", artifact_hashes)
    gate.check("S5-PG-H03-active-full-formal-spec04d-parent", active_parent)
    gate.check("S5-PG-H04-template-hard-gates", template_gates)
    gate.check("S5-PG-H14-template-local-custom-api-usage", template_local_api_usage)
    gate.check("S5-PG-H05-compile-hard-gates", compile_gates)
    gate.check("S5-PG-H06-decision-closure", decision_closure)
    gate.check("S5-PG-H13-presentation-contract", presentation_contract)
    gate.check("S5-PG-H07-E-to-B-to-D-to-M-acyclicity", commit_order)
    gate.check("S5-PG-H08-exact-zip-build-and-render-pack", exact_build_and_render_pack)
    gate.check("S5-PG-H09-live-producer-execution-capability", producer_capability)
    gate.check("S5-PG-H10-live-evaluator-execution-capability", evaluator_capability)
    gate.check("S5-PG-H11-immutable-run-files", immutable_run)
    gate.check("S5-PG-H12-scope-boundary", scope_boundary)
    disposition = "promoted" if gate.passed else "rejected"
    manifest = {
        "schema_version": "stage-promotion-manifest/1.1", "promotion_id": args.promotion_id,
        "lineage_key": args.lineage_key, "evaluated_at": stage_gate.now(), "evaluator": VERSION,
        "stage_kind": "spec05_native_execution", "run_dir": str(run),
        "stage_manifest": {"path": str(stage_path), "sha256": sha256_file(stage_path)},
        "disposition": disposition, "promotion_class": "formal_native",
        "producer_execution_provenance": "live_verified" if gate.passed else "unverified",
        "evaluator_capability": {"path": str(evaluator_path), "sha256": sha256_file(evaluator_path), "payload_hash": evaluator["payload_hash"]},
        "checks": gate.checks,
        "summary": {"checks": len(gate.checks), "passed": sum(item["status"] == "passed" for item in gate.checks), "failed": sum(item["status"] == "failed" for item in gate.checks)},
        "promoted_artifacts": artifacts if disposition == "promoted" else {},
        "consumer_rule": "Spec 03 render coverage may consume only this exact promoted ZIP, PDF, decision index, compile report, and final render pack.",
        "scope_limit": "Spec 05 compile_pass and final_render_pack only; render coverage, Spec 06, reusable capability maturity, and product acceptance are not evaluated.",
    }
    stage_gate.write_json(output, manifest)
    return manifest, 0 if disposition == "promoted" else 4
