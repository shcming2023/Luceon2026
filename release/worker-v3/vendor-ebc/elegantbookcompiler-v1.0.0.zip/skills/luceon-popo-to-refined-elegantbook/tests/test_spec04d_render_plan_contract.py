import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).parents[1] / "scripts/spec04d_render_plan_contract.py"
SPEC = importlib.util.spec_from_file_location("spec04d_contract", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class Spec04DRenderPlanTests(unittest.TestCase):
    def policy(self):
        return {
            "schema_version": "spec04d-render-policy/1.1", "policy_id": "test", "ownership_layer": "profile",
            "review": {"status": "closed", "decision_refs": ["R1"], "basis": "test"},
            "structure_level_constructs": {"0": "chapter*"}, "local_heading_construct": "subsubsection*",
            "toc_representation": {
                "ownership_layer": "core", "semantic_level_to_entry_type": {"0": "chapter", "1": "section", "2": "subsection"},
                "overflow_strategy": "localized_depth_override", "decision_refs": ["R-TOC"],
            },
            "plain_body_construct": "paragraph",
            "safe_textual_fragile_types": ["image_caption", "image_footnote", "page_footnote", "table_caption"],
            "fragile_types_requiring_media_representation": ["chart", "equation", "image", "table"],
            "media_constructs": {"source_asset_image": "source_asset_image", "source_region_image": "source_region_image", "structured_formula": "display_math"},
            "source_image_layout": {"minimum_width_fraction": 0.25, "maximum_width_fraction": 0.9, "max_height_fraction": 0.72, "alignment": "center"},
            "unsupported_representation_types": ["structured_chart", "structured_table", "structured_vector"],
            "structure_media_collision_rule": "virtual_source_supported_structure_node_and_single_media_atom_output",
            "structure_source_role_overrides": [],
            "prohibitions": ["semantic_reclassification", "construct_reselection", "content_rewriting", "formula_reconstruction", "table_reconstruction", "latex_generation"],
        }

    def record(self, block_id, order, source_type="text", disposition="plain_body", raw=None):
        raw = raw or block_id
        return {
            "block_id": block_id, "scope_status": "included", "candidate_final_order": order,
            "pdf_physical_page": 1, "page_local_order": order, "source_type": source_type,
            "semantic_disposition": disposition, "raw_content": raw,
            "raw_content_sha256": MODULE.canonical_hash(raw), "bbox": [0.1, 0.1, 0.5, 0.2],
            "semantic_disposition_decision_refs": ["S4B"],
        }

    def toc_capability(self, effective_depth=1):
        return {
            "entry_type_depths": {"chapter": 0, "section": 1, "subsection": 2, "subsubsection": 3},
            "effective_tocdepth": effective_depth,
            "effective_tocdepth_status": "explicitly_declared",
            "native_visible_entry_types": [name for name, depth in {"chapter": 0, "section": 1, "subsection": 2, "subsubsection": 3}.items() if depth <= effective_depth],
            "serialization_strategies": {
                "native": {"supported": True, "preserves_entry_type": True},
                "localized_depth_override": {
                    "supported": True, "preserves_entry_type": True, "preserves_pdf_outline_level": True,
                    "adds_template_api": False, "modifies_template_preamble_or_class": False,
                },
            },
        }

    def test_preflight_rejects_unrepresented_fragile_atom(self):
        records = [self.record("e1", 1, "equation", "fragile_or_media")]
        report = MODULE.preflight_data(records, {"representations": []}, self.policy())
        self.assertEqual(report["status"], "failed")
        self.assertEqual(report["unsafe_unrepresented_fragile_atoms"], 1)
        self.assertEqual(report["issues"][0]["issue_code"], "UNSAFE_FRAGILE_ATOM_LACKS_CLOSED_SPEC03_REPRESENTATION")

    def test_builds_exact_partition_and_preserves_multifragment_media(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            asset = root / "asset.bin"
            asset.write_bytes(b"source-image")
            artifact_hash = MODULE.sha256_file(asset)
            records = [
                self.record("s1", 1, source_type="title", disposition="book_structure", raw="Unit One"),
                self.record("m1", 2, disposition="teaching_column", raw="NOTE"),
                self.record("b1", 3, disposition="teaching_column", raw="Body"),
                self.record("i1", 4, "image", "fragile_or_media"),
                self.record("i2", 5, "image", "fragile_or_media"),
                self.record("p1", 6, disposition="plain_body", raw="Paragraph"),
            ]
            outline = {"body_hierarchy": [{
                "node_id": "unit-1", "anchor_block_id": "s1", "heading_evidence_block_ids": ["s1"],
                "level": 0, "parent_node_id": None, "role": "unit", "source_order_start": 1,
                "source_order_end": 6, "pdf_physical_page_start": 1, "source_outline_evidence_ids": ["page-1"],
                "final_toc": {"title": "Unit One", "include": True, "level": 0},
            }]}
            bindings = {"bindings": [{
                "binding_id": "binding-1", "object_kind": "teaching_group", "semantic_role": "note",
                "source_block_ids": ["m1", "b1"], "target_construct": "tcolorbox",
                "construct_parameters": {"style": "notebox", "title_source_block_id": "m1"},
                "source_evidence_ids": ["page-1"],
            }]}
            rep = {
                "media_id": "media-1", "representation_id": "rep-1", "status": "closed",
                "representation_type": "source_asset_image", "selected_candidate_id": "candidate-1",
                "artifact_sha256": artifact_hash, "source_block_ids": ["i1", "i2"], "decision_refs": ["M1"],
            }
            media_path = root / "media_plan.json"
            media_path.write_text(json.dumps({"representations": [rep]}), encoding="utf-8")
            media_plan = {"representations": [rep], "_path": str(media_path)}
            evidence = {"atoms": [{"media_id": "media-1", "candidates": [{
                "candidate_id": "candidate-1", "artifact_sha256": artifact_hash,
                "representation_type": "source_asset_image", "resolved_path": str(asset),
            }]}]}
            capability = {
                "capability_payload_hash": "a" * 64,
                "constructs": {"sectioning": ["chapter*", "subsubsection*"], "standard_serialization": {"paragraph": {}, "source_asset_image": {}, "source_region_image": {}, "display_math": {}}},
                "toc_capability": self.toc_capability(),
            }
            nodes = MODULE.build_render_nodes(records, outline, bindings, evidence, media_plan, capability, self.policy(), ["D1"])
            covered = [block_id for node in nodes for block_id in node["source_block_ids"]]
            self.assertEqual(set(covered), {item["block_id"] for item in records})
            self.assertEqual(len(covered), len(set(covered)))
            media = next(node for node in nodes if node["node_kind"] == "media")
            self.assertEqual(media["source_block_ids"], ["i1", "i2"])
            box = next(node for node in nodes if node["target_construct"] == "tcolorbox")
            self.assertEqual(box["payload"]["title"], "NOTE")
            self.assertEqual(box["payload"]["body"][0]["raw_content"], "Body")

    def test_structure_media_collision_uses_virtual_structure_and_one_media_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            asset = root / "image.bin"
            asset.write_bytes(b"image")
            digest = MODULE.sha256_file(asset)
            records = [self.record("i1", 1, "image", "book_structure")]
            outline = {"body_hierarchy": [{
                "node_id": "unit-image", "anchor_block_id": "i1", "heading_evidence_block_ids": ["i1"],
                "level": 0, "parent_node_id": None, "role": "unit", "source_order_start": 1,
                "source_order_end": 1, "pdf_physical_page_start": 1, "source_outline_evidence_ids": ["toc-1"],
                "final_toc": {"title": "Unit From Source", "include": True, "level": 0},
            }]}
            rep = {"media_id": "m", "representation_id": "r", "status": "closed", "representation_type": "source_asset_image", "selected_candidate_id": "c", "artifact_sha256": digest, "source_block_ids": ["i1"], "decision_refs": []}
            media_path = root / "plan.json"
            media_path.write_text(json.dumps({"representations": [rep]}), encoding="utf-8")
            evidence = {"atoms": [{"media_id": "m", "candidates": [{"candidate_id": "c", "artifact_sha256": digest, "resolved_path": str(asset)}]}]}
            capability = {"capability_payload_hash": "b" * 64, "constructs": {"sectioning": ["chapter*"], "standard_serialization": {"paragraph": {}, "source_asset_image": {}}}, "toc_capability": self.toc_capability()}
            nodes = MODULE.build_render_nodes(records, outline, {"bindings": []}, evidence, {"representations": [rep], "_path": str(media_path)}, capability, self.policy(), ["D"])
            structure = next(node for node in nodes if node["node_kind"] == "book_structure")
            media = next(node for node in nodes if node["node_kind"] == "media")
            self.assertTrue(structure["virtual_source_supported"])
            self.assertEqual(structure["source_block_ids"], [])
            self.assertEqual(media["source_block_ids"], ["i1"])

    def test_level_above_template_tocdepth_uses_localized_preserving_strategy(self):
        records = [self.record("s1", 1, source_type="title", disposition="book_structure", raw="Sublesson")]
        outline = {"body_hierarchy": [{
            "node_id": "sublesson-1", "anchor_block_id": "s1", "heading_evidence_block_ids": ["s1"],
            "level": 2, "parent_node_id": "lesson-1", "role": "sublesson", "source_order_start": 1,
            "source_order_end": 1, "pdf_physical_page_start": 1, "source_outline_evidence_ids": ["toc-1"],
            "final_toc": {"title": "Sublesson", "include": True, "level": 2},
        }]}
        policy = self.policy()
        policy["structure_level_constructs"]["2"] = "subsection*"
        capability = {
            "capability_payload_hash": "c" * 64,
            "constructs": {"sectioning": ["subsection*"], "standard_serialization": {"paragraph": {}}},
            "toc_capability": self.toc_capability(effective_depth=1),
        }
        nodes = MODULE.build_render_nodes(records, outline, {"bindings": []}, {"atoms": []}, {"representations": [], "_path": __file__}, capability, policy, ["D"])
        params = nodes[0]["construct_parameters"]
        self.assertEqual(params["toc_entry_level"], "subsection")
        self.assertEqual(params["toc_visibility_strategy"], "localized_depth_override")
        self.assertEqual(params["toc_depth_override"], 2)

    def test_unpreserved_toc_overflow_fails_closed(self):
        binding = MODULE.toc_capability_binding({"capability_payload_hash": "d" * 64, "toc_capability": self.toc_capability(1)})
        node = {
            "render_node_id": "render::bad", "node_kind": "book_structure", "target_construct": "subsection*",
            "construct_parameters": {"toc": True, "level": 2, "toc_entry_level": "section", "toc_visibility_strategy": "native"},
        }
        with self.assertRaisesRegex(ValueError, "MAPPING_TOC_LEVEL_UNRENDERABLE"):
            MODULE.validate_toc_renderability([node], binding)

    def test_non_title_structure_anchor_requires_explicit_source_role(self):
        records = [self.record("q1", 1, disposition="book_structure", raw="1. What is the value?")]
        outline = {"body_hierarchy": [{
            "node_id": "assessment-1", "anchor_block_id": "q1", "heading_evidence_block_ids": ["q1"],
            "level": 0, "parent_node_id": None, "role": "assessment", "source_order_start": 1,
            "source_order_end": 1, "pdf_physical_page_start": 1, "source_outline_evidence_ids": ["page-1"],
            "final_toc": {"title": "Assessment", "include": True, "level": 0},
        }]}
        capability = {
            "capability_payload_hash": "e" * 64,
            "constructs": {"sectioning": ["chapter*"], "standard_serialization": {"paragraph": {}}},
            "toc_capability": self.toc_capability(),
        }
        with self.assertRaisesRegex(ValueError, "AMBIGUOUS_STRUCTURE_SOURCE_ROLE"):
            MODULE.build_render_nodes(records, outline, {"bindings": []}, {"atoms": []}, {"representations": [], "_path": __file__}, capability, self.policy(), ["D"])

    def test_reviewed_non_title_anchor_is_emitted_once_as_separate_body(self):
        records = [self.record("q1", 1, disposition="book_structure", raw="1. What is the value?")]
        outline = {"body_hierarchy": [{
            "node_id": "assessment-1", "anchor_block_id": "q1", "heading_evidence_block_ids": ["q1"],
            "level": 0, "parent_node_id": None, "role": "assessment", "source_order_start": 1,
            "source_order_end": 1, "pdf_physical_page_start": 1, "source_outline_evidence_ids": ["page-1"],
            "final_toc": {"title": "Assessment", "include": True, "level": 0},
        }]}
        capability = {
            "capability_payload_hash": "f" * 64,
            "constructs": {"sectioning": ["chapter*"], "standard_serialization": {"paragraph": {}}},
            "toc_capability": self.toc_capability(),
        }
        policy = self.policy()
        policy["structure_source_role_overrides"] = [{
            "structure_node_id": "assessment-1", "block_id": "q1", "role": "post_heading_body",
            "decision_refs": ["REVIEW-Q1"], "reason": "The atom is the first problem body, not title text.",
        }]
        nodes = MODULE.build_render_nodes(records, outline, {"bindings": []}, {"atoms": []}, {"representations": [], "_path": __file__}, capability, policy, ["D"])
        structure = next(node for node in nodes if node["node_kind"] == "book_structure")
        body = next(node for node in nodes if node["node_kind"] == "structure_body")
        self.assertTrue(structure["virtual_source_supported"])
        self.assertEqual(structure["source_block_ids"], [])
        self.assertEqual(structure["payload"]["title_source_fragments"], [])
        self.assertEqual(structure["payload"]["separate_body_block_ids"], ["q1"])
        self.assertEqual(body["source_block_ids"], ["q1"])
        self.assertEqual(body["target_construct"], "paragraph")
        self.assertEqual(body["payload"]["raw_content"], "1. What is the value?")
        self.assertEqual(MODULE.validate_structure_source_integrity(nodes, outline, records, policy)["post_heading_body_atoms"], 1)


if __name__ == "__main__":
    unittest.main()
