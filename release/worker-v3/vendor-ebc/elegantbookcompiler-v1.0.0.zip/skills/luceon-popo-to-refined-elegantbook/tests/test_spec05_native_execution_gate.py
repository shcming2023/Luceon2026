import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).parents[1]
CORE_PATH = ROOT / "scripts/spec05_native_execution_gate.py"
SPEC = importlib.util.spec_from_file_location("spec05_gate", CORE_PATH)
CORE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(CORE)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")


def registry(path: Path, lineage: str, promotion: Path, promotion_id: str) -> None:
    gate_spec = importlib.util.spec_from_file_location("router", ROOT / "scripts/stage_promotion_gate.py")
    gate = importlib.util.module_from_spec(gate_spec)
    assert gate_spec.loader
    gate_spec.loader.exec_module(gate)
    document = {
        "schema_version": "promotion-registry/1.0", "registry_id": "test", "snapshot_id": "test-v1",
        "version": 1, "generated_at": "ignored", "parent_registry_ref": None, "parent_registry_sha256": None,
        "entries": [],
        "active_promotions": {lineage: {"promotion_id": promotion_id, "manifest_path": str(promotion), "manifest_sha256": sha(promotion), "promotion_class": "formal_native"}},
        "selection_rule": "test", "payload_hash": "",
    }
    document["payload_hash"] = gate.canonical_hash({key: value for key, value in document.items() if key not in {"generated_at", "payload_hash"}})
    write(path, document)


def promotion_fixture(tmp_path: Path, stage_kind: str) -> tuple[Path, str, Path]:
    stage = tmp_path / "run/stage.json"
    write(stage, {"full_spec04_status": "passed", "producer_mode": "formal_native"})
    evaluator = tmp_path / "evaluator.json"
    producer = tmp_path / "producer.json"
    write(evaluator, {"frozen": True})
    write(producer, {"frozen": True})
    promotion_id = "promotion-v1"
    promotion = tmp_path / "promotion.json"
    write(promotion, {
        "schema_version": "stage-promotion-manifest/1.1", "promotion_id": promotion_id,
        "lineage_key": "material/spec04d", "disposition": "promoted", "promotion_class": "formal_native",
        "producer_execution_provenance": "live_verified", "stage_kind": stage_kind,
        "stage_manifest": {"path": str(stage), "sha256": sha(stage)},
        "evaluator_capability": {"path": str(evaluator), "sha256": sha(evaluator)},
        "promoted_artifacts": {"producer_execution_capability": {"path": str(producer), "sha256": sha(producer)}},
    })
    registry_path = tmp_path / "registry.json"
    registry(registry_path, "material/spec04d", promotion, promotion_id)
    return registry_path, promotion_id, promotion


def test_full_formal_spec04d_is_eligible(tmp_path: Path) -> None:
    registry_path, _, promotion = promotion_fixture(tmp_path, "spec04d_render_plan_contract")
    output = tmp_path / "eligible.json"
    report, code = CORE.preflight_parent(argparse.Namespace(
        promotion_registry=registry_path, parent_promotion=promotion,
        parent_lineage_key="material/spec04d", output=output,
    ))
    assert code == 0
    assert report["eligible"] is True


def test_spec03_media_promotion_is_exact_negative_control(tmp_path: Path) -> None:
    registry_path, _, promotion = promotion_fixture(tmp_path, "spec03_media_contract")
    output = tmp_path / "rejected.json"
    report, code = CORE.preflight_parent(argparse.Namespace(
        promotion_registry=registry_path, parent_promotion=promotion,
        parent_lineage_key="material/spec04d", output=output,
    ))
    assert code == 4
    assert report["eligible"] is False
    assert report["failure_code"] == "SPEC05_PARENT_NOT_FULL_SPEC04D"


def test_independent_tp_h14_allows_declared_tcolorbox_style(tmp_path: Path) -> None:
    capability = tmp_path / "capability.json"
    body = tmp_path / "body.tex"
    write(capability, {"constructs": {"custom_commands": ["activitynum"], "custom_environments": ["answershow"]}})
    body.write_text("\\begin{tcolorbox}[featurebox]\nText\n\\end{tcolorbox}\n", encoding="utf-8")
    result = CORE.independent_template_local_api_scan(capability, body)
    assert result["violations"] == []


def test_independent_tp_h14_rejects_custom_api_calls(tmp_path: Path) -> None:
    capability = tmp_path / "capability.json"
    body = tmp_path / "body.tex"
    write(capability, {"constructs": {"custom_commands": ["activitynum"], "custom_environments": ["answershow"]}})
    body.write_text("\\activitynum{2}\n\\begin{answershow}x\\end{answershow}\n", encoding="utf-8")
    result = CORE.independent_template_local_api_scan(capability, body)
    assert {item["kind"] for item in result["violations"]} == {
        "template_local_command_call", "template_local_environment_call"
    }
